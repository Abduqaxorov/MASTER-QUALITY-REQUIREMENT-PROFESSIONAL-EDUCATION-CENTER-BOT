from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from keyboards.buttons import (
    # Admin
    BTN_NEW_GROUP, BTN_GROUP_ANALYSIS, BTN_DEBT, BTN_MONTHLY,
    BTN_PUBLIC_UPLOAD, BTN_PUBLIC_TEST, BTN_DEBTORS_EXCEL,
    BTN_PAYMENT_CARDS, BTN_STUDENTS_REPORT, BTN_IDS_EXCEL, BTN_FIX_LINK,
    BTN_TEACHER_EDIT, BTN_TEACHER_ADD, BTN_TEACHER_ASSIGN,
    BTN_ADMIN_CONTACT_TEACHER, BTN_TICKETS, BTN_ANON_FEEDBACK,
    # Admin bo'limlar
    BTN_SEC_GROUPS, BTN_SEC_FINANCE, BTN_SEC_REPORTS,
    BTN_SEC_TEACHERS, BTN_SEC_ANNOUNCE, BTN_SEC_TICKETS, BTN_BACK,
    # Teacher
    BTN_T_ADD_STUDENT, BTN_T_EXCEL_UPLOAD, BTN_T_STUDENT_LIST,
    BTN_T_ATTENDANCE, BTN_T_TESTS, BTN_T_SCHEDULE, BTN_T_CONTACT_ADMIN,
    BTN_T_STUDENTS,
    # User
    BTN_CHECK_BALANCE, BTN_PAY, BTN_RATING, BTN_HISTORY, BTN_FILES,
    BTN_TEST_ARCHIVE, BTN_CONTACT_ADMIN, BTN_MY_SCHEDULE,
    BTN_CONTACT_TEACHER, BTN_ANON_FEEDBACK_USER,
)


def admin_menu() -> ReplyKeyboardMarkup:
    """Asosiy admin menyu — ixcham, 6 ta bo'lim."""
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=BTN_SEC_GROUPS), KeyboardButton(text=BTN_SEC_FINANCE)],
            [KeyboardButton(text=BTN_SEC_REPORTS), KeyboardButton(text=BTN_SEC_TEACHERS)],
            [KeyboardButton(text=BTN_SEC_ANNOUNCE), KeyboardButton(text=BTN_SEC_TICKETS)],
        ],
        resize_keyboard=True,
    )


# ───────────── Admin submenyu bo'limlari ─────────────

def admin_groups_menu() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=BTN_NEW_GROUP), KeyboardButton(text=BTN_GROUP_ANALYSIS)],
            [KeyboardButton(text=BTN_BACK)],
        ],
        resize_keyboard=True,
    )


def admin_finance_menu() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=BTN_DEBT), KeyboardButton(text=BTN_MONTHLY)],
            [KeyboardButton(text=BTN_PAYMENT_CARDS)],
            [KeyboardButton(text=BTN_BACK)],
        ],
        resize_keyboard=True,
    )


def admin_reports_menu() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=BTN_DEBTORS_EXCEL), KeyboardButton(text=BTN_STUDENTS_REPORT)],
            [KeyboardButton(text=BTN_IDS_EXCEL)],
            [KeyboardButton(text=BTN_BACK)],
        ],
        resize_keyboard=True,
    )


def admin_teachers_menu() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=BTN_TEACHER_ADD), KeyboardButton(text=BTN_TEACHER_ASSIGN)],
            [KeyboardButton(text=BTN_TEACHER_EDIT), KeyboardButton(text=BTN_ADMIN_CONTACT_TEACHER)],
            [KeyboardButton(text=BTN_BACK)],
        ],
        resize_keyboard=True,
    )


def admin_announce_menu() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=BTN_PUBLIC_UPLOAD), KeyboardButton(text=BTN_PUBLIC_TEST)],
            [KeyboardButton(text=BTN_BACK)],
        ],
        resize_keyboard=True,
    )


def admin_tickets_menu() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=BTN_TICKETS), KeyboardButton(text=BTN_ANON_FEEDBACK)],
            [KeyboardButton(text=BTN_FIX_LINK)],
            [KeyboardButton(text=BTN_BACK)],
        ],
        resize_keyboard=True,
    )


def teacher_menu() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=BTN_T_ADD_STUDENT), KeyboardButton(text=BTN_T_EXCEL_UPLOAD)],
            [KeyboardButton(text=BTN_T_STUDENT_LIST), KeyboardButton(text=BTN_T_STUDENTS)],
            [KeyboardButton(text=BTN_T_ATTENDANCE), KeyboardButton(text=BTN_T_TESTS)],
            [KeyboardButton(text=BTN_T_SCHEDULE)],
            [KeyboardButton(text=BTN_T_CONTACT_ADMIN)],
        ],
        resize_keyboard=True,
    )


def user_menu() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=BTN_CHECK_BALANCE), KeyboardButton(text=BTN_PAY)],
            [KeyboardButton(text=BTN_RATING), KeyboardButton(text=BTN_HISTORY)],
            [KeyboardButton(text=BTN_TEST_ARCHIVE), KeyboardButton(text=BTN_FILES)],
            [KeyboardButton(text=BTN_MY_SCHEDULE), KeyboardButton(text=BTN_CONTACT_TEACHER)],
            [KeyboardButton(text=BTN_ANON_FEEDBACK_USER)],
            [KeyboardButton(text=BTN_CONTACT_ADMIN)],
        ],
        resize_keyboard=True,
    )
