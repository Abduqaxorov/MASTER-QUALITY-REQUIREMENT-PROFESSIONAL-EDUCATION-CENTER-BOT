from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


def groups_kb(groups, prefix="grp") -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for g in groups:
        b.button(text=f"{g.name} [{g.year}] ({g.monthly_price:,.0f})",
                 callback_data=f"{prefix}:{g.id}")
    b.adjust(1)
    return b.as_markup()


def student_remove_kb(student_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ Remove", callback_data=f"remove:{student_id}")]
    ])


def student_remove_confirm_kb(student_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Ha, o'chirilsin", callback_data=f"delok:{student_id}"),
         InlineKeyboardButton(text="🔙 Yo'q", callback_data=f"delno:{student_id}")]
    ])


def students_select_kb(students, prefix="pick") -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for s in students:
        links = getattr(s, "group_links", None) or []
        names = [l.group.name for l in links if l.group]
        extra = f" • {', '.join(names)}" if names else " • (guruhsiz)"
        b.button(text=f"{s.name} {s.last_name}{extra}",
                 callback_data=f"{prefix}:{s.id}")
    b.adjust(1)
    return b.as_markup()


def pay_now_kb(student_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💳 To'lov qilish", callback_data=f"paynow:{student_id}")]
    ])


def payment_decision_kb(req_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Tasdiqlash", callback_data=f"confirm:{req_id}"),
         InlineKeyboardButton(text="❌ Rad etish", callback_data=f"reject:{req_id}")]
    ])


def monthly_confirm_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Ha, hammaga yozilsin", callback_data="monthly_yes"),
         InlineKeyboardButton(text="❌ Bekor qilish", callback_data="monthly_no")]
    ])


def monthly_final_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Ha, aniq yozilsin", callback_data="monthly_final_yes"),
         InlineKeyboardButton(text="❌ Bekor qilish", callback_data="monthly_final_no")]
    ])


# ───────────── DAVOMAT ─────────────
def attendance_mode_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="👤 Bittalab belgilash", callback_data="att_mode:one")],
        [InlineKeyboardButton(text="📥 Excel orqali", callback_data="att_mode:excel")],
    ])


def attendance_marking_kb(students, absent_ids) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for s in students:
        mark = "❌" if s.id in absent_ids else "✅"
        b.button(text=f"{mark} {s.name} {s.last_name}",
                 callback_data=f"att_toggle:{s.id}")
    b.adjust(1)
    b.row(InlineKeyboardButton(text="💾 Saqlash", callback_data="att_save"))
    b.row(InlineKeyboardButton(text="🚫 Bekor qilish", callback_data="att_cancel"))
    return b.as_markup()


def attendance_confirm_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Ha, saqlansin", callback_data="att_confirm_yes"),
         InlineKeyboardButton(text="❌ Yo'q", callback_data="att_confirm_no")]
    ])


# ───────────── TO'LOV KARTALARI ─────────────
def cards_manage_kb(cards) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for c in cards:
        b.button(text=f"🗑 {c.name} • {c.card}", callback_data=f"card_del:{c.id}")
    b.adjust(1)
    if len(cards) < 4:
        b.row(InlineKeyboardButton(text="➕ Yangi karta qo'shish", callback_data="card_add"))
    return b.as_markup()


def card_del_confirm_kb(card_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Ha, o'chirilsin", callback_data=f"card_delok:{card_id}"),
         InlineKeyboardButton(text="🔙 Yo'q", callback_data=f"card_delno:{card_id}")]
    ])


# ───────────── GURUH TAHLIL ─────────────
def group_analysis_kb(groups) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for g in groups:
        b.button(text=f"{g.name} [{g.year}]", callback_data=f"ganalyze:{g.id}")
    b.adjust(1)
    return b.as_markup()


def group_actions_kb(group_id: int, can_delete: bool) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    b.button(text="✏️ Nomini o'zgartirish", callback_data=f"grename:{group_id}")
    if can_delete:
        b.button(text="🗑 Guruhni o'chirish", callback_data=f"gdelete:{group_id}")
    b.button(text="🔙 Orqaga", callback_data="gback")
    b.adjust(1)
    return b.as_markup()


def group_delete_confirm_kb(group_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Ha, o'chirilsin", callback_data=f"gdelok:{group_id}"),
         InlineKeyboardButton(text="🔙 Yo'q", callback_data=f"gdelno:{group_id}")]
    ])


# ───────────── BOG'LANISH SO'ROVI ─────────────
def link_decision_kb(req_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Tasdiqlash", callback_data=f"linkok:{req_id}"),
         InlineKeyboardButton(text="❌ Rad etish", callback_data=f"linkno:{req_id}")]
    ])


# ───────────── O'QITUVCHI TANLASH ─────────────
def teachers_kb(teachers, prefix="tch") -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for t in teachers:
        b.button(text=f"👨‍🏫 {t.full_name}", callback_data=f"{prefix}:{t.id}")
    b.adjust(1)
    return b.as_markup()


# ───────────── TICKET QAROR ─────────────
def ticket_decision_kb(ticket_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Tasdiqlash (keyingisiga o'tish)",
                              callback_data=f"ticketok:{ticket_id}"),
         InlineKeyboardButton(text="❌ Rad etish",
                              callback_data=f"ticketno:{ticket_id}")]
    ])


# ───────────── FEEDBACK O'QITUVCHILAR ─────────────
def feedback_teachers_kb(teachers_with_feedback) -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for t, count in teachers_with_feedback:
        b.button(text=f"👨‍🏫 {t.full_name} ({count} ta)",
                 callback_data=f"fbtch:{t.id}")
    b.adjust(1)
    return b.as_markup()


# ───────────── USTOZNI TAHRIRLASH ─────────────
def teachers_with_groups_kb(teachers) -> InlineKeyboardMarkup:
    """Admin uchun o'qituvchilar ro'yxati (tahrirlash)."""
    b = InlineKeyboardBuilder()
    for t in teachers:
        b.button(text=f"👨‍🏫 {t.full_name}", callback_data=f"tedit:{t.id}")
    b.adjust(1)
    return b.as_markup()


def teacher_groups_manage_kb(teacher_id: int, groups) -> InlineKeyboardMarkup:
    """O'qituvchining guruhlarini boshqarish."""
    b = InlineKeyboardBuilder()
    for g in groups:
        b.button(text=f"📁 {g.name} [{g.year}]", callback_data=f"tgrm:{teacher_id}:{g.id}")
    b.adjust(1)
    if groups:
        b.row(InlineKeyboardButton(
            text="🔄 Guruhni boshqa ustozga o'tkazish",
            callback_data=f"treassign:{teacher_id}"))
    b.row(InlineKeyboardButton(text="🗑 Ustozni o'chirish", callback_data=f"tdel:{teacher_id}"))
    b.row(InlineKeyboardButton(text="🔙 Orqaga", callback_data="tback"))
    return b.as_markup()


def teacher_remove_group_confirm_kb(teacher_id: int, group_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Ha, olib tashlansin",
                              callback_data=f"tgrmok:{teacher_id}:{group_id}"),
         InlineKeyboardButton(text="🔙 Yo'q",
                              callback_data=f"tgrmno:{teacher_id}:{group_id}")]
    ])


def teacher_delete_confirm_kb(teacher_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Ha, o'chirilsin", callback_data=f"tdelok:{teacher_id}"),
         InlineKeyboardButton(text="🔙 Yo'q", callback_data=f"tdelno:{teacher_id}")]
    ])


# ───────────── GURUHNI BOSHQA USTOZGA O'TKAZISH ─────────────
def teacher_reassign_groups_kb(groups) -> InlineKeyboardMarkup:
    """Ustozdan boshqasiga o'tkaziladigan guruhni tanlash."""
    b = InlineKeyboardBuilder()
    for g in groups:
        b.button(text=f"📁 {g.name} [{g.year}]", callback_data=f"treasg:{g.id}")
    b.adjust(1)
    b.row(InlineKeyboardButton(text="🔙 Orqaga", callback_data="tback"))
    return b.as_markup()


def teacher_reassign_pick_kb(teachers, group_id: int) -> InlineKeyboardMarkup:
    """Guruh o'tkaziladigan yangi ustozni tanlash."""
    b = InlineKeyboardBuilder()
    for t in teachers:
        b.button(text=f"👨‍🏫 {t.full_name}", callback_data=f"treasgt:{group_id}:{t.id}")
    b.adjust(1)
    b.row(InlineKeyboardButton(text="🔙 Orqaga", callback_data="tback"))
    return b.as_markup()


# ───────────── DARS JADVALI ─────────────
def schedule_days_kb() -> InlineKeyboardMarkup:
    """Hafta kunlari."""
    days = [
        ("Dushanba", "Monday"),
        ("Seshanba", "Tuesday"),
        ("Chorshanba", "Wednesday"),
        ("Payshanba", "Thursday"),
        ("Juma", "Friday"),
        ("Shanba", "Saturday"),
        ("Yakshanba", "Sunday"),
    ]
    b = InlineKeyboardBuilder()
    for label, value in days:
        b.button(text=label, callback_data=f"sday:{value}")
    b.adjust(2)
    return b.as_markup()


def teacher_schedules_kb(schedules) -> InlineKeyboardMarkup:
    """O'qituvchi dars jadvali ro'yxati."""
    b = InlineKeyboardBuilder()
    days_short = {
        "Monday": "Dsh", "Tuesday": "Ssh", "Wednesday": "Chr",
        "Thursday": "Pay", "Friday": "Jum", "Saturday": "Sha", "Sunday": "Yak",
    }
    for sch in schedules:
        day = days_short.get(sch.day_of_week, sch.day_of_week[:3])
        b.button(
            text=f"🗓 {day} | {sch.start_time}-{sch.end_time} | {sch.group.name if sch.group else '—'}",
            callback_data=f"sdeld:{sch.id}"
        )
    b.button(text="➕ Yangi dars qo'shish", callback_data="sadd")
    b.adjust(1)
    return b.as_markup()


def student_exists_kb(student_id: int, group_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Ha, guruhga qo'shish",
                              callback_data=f"st_add_existing:{student_id}:{group_id}")],
        [InlineKeyboardButton(text="❌ Yo'q", callback_data="st_add_cancel")]
    ])


def student_groups_select_kb(groups, prefix="st_grp") -> InlineKeyboardMarkup:
    b = InlineKeyboardBuilder()
    for g in groups:
        b.button(text=f"📁 {g.name} [{g.year}]", callback_data=f"{prefix}:{g.id}")
    b.adjust(1)
    return b.as_markup()
