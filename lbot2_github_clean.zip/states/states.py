from aiogram.fsm.state import State, StatesGroup


class GroupFSM(StatesGroup):
    name = State(); year = State(); price = State()


class StudentFSM(StatesGroup):
    name = State(); last_name = State(); tel = State(); group_id = State()


class DebtFSM(StatesGroup):
    search = State(); select = State(); amount = State()


class WarningFSM(StatesGroup):
    text = State()


class UserCheckFSM(StatesGroup):
    search = State()


class PaymentFSM(StatesGroup):
    search = State(); select = State(); check = State()


class ConfirmFSM(StatesGroup):
    amount = State()


class YearFSM(StatesGroup):
    year = State()


class ExcelFSM(StatesGroup):
    file = State()


class TestFSM(StatesGroup):
    group = State()
    year = State()
    file = State()


class PublicUploadFSM(StatesGroup):
    file = State(); caption = State()


class PublicTestFSM(StatesGroup):
    file = State(); caption = State()


class RatingFSM(StatesGroup):
    search = State()


class HistoryFSM(StatesGroup):
    search = State()


class ContactFSM(StatesGroup):
    text = State()
    ask_extra = State()
    extra = State()


class MonthlyFSM(StatesGroup):
    confirm = State()


class AttendanceFSM(StatesGroup):
    year = State()
    group = State()
    mode = State()
    marking = State()
    confirm = State()
    file = State()


class CardFSM(StatesGroup):
    name = State()
    card = State()
    tel = State()


class LinkFSM(StatesGroup):
    search = State()
    phone = State()


class AdminFixLinkFSM(StatesGroup):
    user_id = State()
    search = State()


class GroupRenameFSM(StatesGroup):
    name = State()


# ───────────── O'QITUVCHI (admin qo'shadi) ─────────────
class TeacherFSM(StatesGroup):
    tg_id = State()
    full_name = State()
    phone = State()


class TeacherAssignFSM(StatesGroup):
    group = State()
    teacher = State()


# ───────────── GURUHNI BOSHQA USTOZGA O'TKAZISH ─────────────
class TeacherReassignFSM(StatesGroup):
    teacher = State()
    group = State()
    new_teacher = State()


# ───────────── ANONIM FEEDBACK (user) ─────────────
class AnonFeedbackFSM(StatesGroup):
    text = State()


# ───────────── TICKET / MUROJAAT (user → admin) ─────────────
class TicketFSM(StatesGroup):
    text = State()
    ask_extra = State()


# ───────────── USER → O'QITUVCHI ─────────────
class ContactTeacherFSM(StatesGroup):
    text = State()


# ───────────── ADMIN → O'QITUVCHI ─────────────
class AdminContactTeacherFSM(StatesGroup):
    teacher = State()
    text = State()


# ───────────── DARS JADVALI (teacher) ─────────────
class TeacherScheduleFSM(StatesGroup):
    group = State()
    day = State()
    start_time = State()
    end_time = State()


# ───────────── USTOZNI TAHRIRLASH ─────────────
class TeacherEditFSM(StatesGroup):
    confirm_remove_group = State()


# ───────────── TEACHER: O'QUVCHI QO'SHISH (alohida, konfliktsiz) ─────────────
class TeacherStudentFSM(StatesGroup):
    name = State()
    last_name = State()
    tel = State()
    group_id = State()


# ───────────── TEACHER: TEST YUKLASH (alohida) ─────────────
class TeacherTestFSM(StatesGroup):
    year = State()
    file = State()


# ───────────── TEACHER: EXCEL YUKLASH (alohida) ─────────────
class TeacherExcelFSM(StatesGroup):
    file = State()


# ───────────── TEACHER: DAVOMAT (alohida) ─────────────
class TeacherAttendanceFSM(StatesGroup):
    group = State()
    mode = State()
    marking = State()
    confirm = State()
    file = State()


# ───────────── TEACHER: ADMIN BILAN BOG'LANISH (alohida) ─────────────
class TeacherTicketFSM(StatesGroup):
    text = State()
