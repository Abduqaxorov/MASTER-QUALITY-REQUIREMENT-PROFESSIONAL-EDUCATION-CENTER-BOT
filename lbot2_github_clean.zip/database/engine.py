from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession

from config import DATABASE_URL
from database.models import Base

engine = create_async_engine(
    DATABASE_URL, echo=False, pool_pre_ping=True,
    pool_size=20, max_overflow=50, pool_recycle=1800,
)

async_session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

        # ── Ticket raqamlari uchun atomar sequence ──
        # nextval() bir vaqtda 1000 ta so'rov kelsa ham har biriga
        # alohida raqam beradi — to'qnashuv bo'lishi mumkin emas.
        await conn.execute(text("CREATE SEQUENCE IF NOT EXISTS ticket_number_seq"))

        # Sequence'ni mavjud eng katta ticket raqamiga moslaymiz
        # (backup'dan tiklangandan keyin ham to'g'ri ishlashi uchun)
        max_num = (await conn.execute(text("""
            SELECT GREATEST(
                COALESCE((SELECT MAX(ticket_number) FROM contact_tickets), 0),
                COALESCE((SELECT MAX(ticket_number) FROM link_requests), 0)
            )
        """))).scalar() or 0
        if max_num > 0:
            await conn.execute(
                text(f"SELECT setval('ticket_number_seq', {max_num}, true)")
            )
