from datetime import datetime, timezone, date
from sqlalchemy import (
    BigInteger, Integer, String, Float, DateTime, Date, ForeignKey, Text,
    UniqueConstraint, Boolean,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


def _utcnow() -> datetime:
    """UTC vaqtni naive (timezone'siz) qaytaradi.
    PostgreSQL'da TIMESTAMP WITHOUT TIME ZONE ustunlari uchun shart —
    asyncpg offset-aware datetime'ni qabul qilmaydi."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


class Base(DeclarativeBase):
    pass


class Group(Base):
    __tablename__ = "groups"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    monthly_price: Mapped[float] = mapped_column(Float, default=0.0)
    year: Mapped[int] = mapped_column(Integer, nullable=False, default=2025)
    student_links: Mapped[list["StudentGroup"]] = relationship(
        back_populates="group", cascade="all, delete-orphan"
    )
    teacher_links: Mapped[list["TeacherGroup"]] = relationship(
        back_populates="group", cascade="all, delete-orphan"
    )
    schedules: Mapped[list["TeacherSchedule"]] = relationship(
        back_populates="group", cascade="all, delete-orphan"
    )
    test_results: Mapped[list["TestResult"]] = relationship(
        back_populates="group", cascade="all, delete-orphan"
    )
    attendances: Mapped[list["Attendance"]] = relationship(
        back_populates="group", cascade="all, delete-orphan"
    )


class Student(Base):
    __tablename__ = "students"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    last_name: Mapped[str] = mapped_column(String(100), nullable=False)
    tel: Mapped[str] = mapped_column(String(20), nullable=True)
    tg_id: Mapped[int] = mapped_column(BigInteger, nullable=True)
    group_links: Mapped[list["StudentGroup"]] = relationship(
        back_populates="student", cascade="all, delete-orphan"
    )
    test_results: Mapped[list["TestResult"]] = relationship(
        back_populates="student", cascade="all, delete-orphan"
    )
    attendances: Mapped[list["Attendance"]] = relationship(
        back_populates="student", cascade="all, delete-orphan"
    )


class StudentGroup(Base):
    __tablename__ = "student_groups"
    __table_args__ = (
        UniqueConstraint("student_id", "group_id", name="uq_student_group"),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    student_id: Mapped[int] = mapped_column(
        ForeignKey("students.id", ondelete="CASCADE"), nullable=False
    )
    group_id: Mapped[int] = mapped_column(
        ForeignKey("groups.id", ondelete="CASCADE"), nullable=False
    )
    balance: Mapped[float] = mapped_column(Float, default=0.0)
    average_score: Mapped[float] = mapped_column(Float, default=0.0)
    student: Mapped["Student"] = relationship(back_populates="group_links")
    group: Mapped["Group"] = relationship(back_populates="student_links")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)


class TestResult(Base):
    __tablename__ = "test_results"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    student_id: Mapped[int] = mapped_column(
        ForeignKey("students.id", ondelete="CASCADE"), nullable=False
    )
    group_id: Mapped[int] = mapped_column(
        ForeignKey("groups.id", ondelete="CASCADE"), nullable=False
    )
    score: Mapped[float] = mapped_column(Float, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)
    student: Mapped["Student"] = relationship(back_populates="test_results")
    group: Mapped["Group"] = relationship(back_populates="test_results")


class BotUser(Base):
    __tablename__ = "bot_users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tg_id: Mapped[int] = mapped_column(BigInteger, unique=True, nullable=False)
    full_name: Mapped[str] = mapped_column(String(200), nullable=True)
    username: Mapped[str] = mapped_column(String(100), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)


# ───────────── O'QITUVCHI ─────────────
class Teacher(Base):
    __tablename__ = "teachers"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tg_id: Mapped[int] = mapped_column(BigInteger, unique=True, nullable=False)
    full_name: Mapped[str] = mapped_column(String(200), nullable=False)
    phone: Mapped[str] = mapped_column(String(30), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)
    group_links: Mapped[list["TeacherGroup"]] = relationship(
        back_populates="teacher", cascade="all, delete-orphan"
    )
    schedules: Mapped[list["TeacherSchedule"]] = relationship(
        back_populates="teacher", cascade="all, delete-orphan"
    )


# ───────────── O'QITUVCHI-GURUH ─────────────
class TeacherGroup(Base):
    __tablename__ = "teacher_groups"
    __table_args__ = (
        UniqueConstraint("group_id", name="uq_teacher_group_one"),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    teacher_id: Mapped[int] = mapped_column(
        ForeignKey("teachers.id", ondelete="CASCADE"), nullable=False
    )
    group_id: Mapped[int] = mapped_column(
        ForeignKey("groups.id", ondelete="CASCADE"), nullable=False
    )
    teacher: Mapped["Teacher"] = relationship(back_populates="group_links")
    group: Mapped["Group"] = relationship(back_populates="teacher_links")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)


# ───────────── DARS VAQTI (SCHEDULE) ─────────────
class TeacherSchedule(Base):
    __tablename__ = "teacher_schedules"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    teacher_id: Mapped[int] = mapped_column(
        ForeignKey("teachers.id", ondelete="CASCADE"), nullable=False
    )
    group_id: Mapped[int] = mapped_column(
        ForeignKey("groups.id", ondelete="CASCADE"), nullable=False
    )
    day_of_week: Mapped[str] = mapped_column(String(20), nullable=False)
    start_time: Mapped[str] = mapped_column(String(5), nullable=False)
    end_time: Mapped[str] = mapped_column(String(5), nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)
    teacher: Mapped["Teacher"] = relationship(back_populates="schedules")
    group: Mapped["Group"] = relationship(back_populates="schedules")


class UploadedFile(Base):
    __tablename__ = "uploaded_files"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    file_id: Mapped[str] = mapped_column(String(300), nullable=False)
    file_type: Mapped[str] = mapped_column(String(20), default="document")
    file_name: Mapped[str] = mapped_column(String(200), nullable=True)
    caption: Mapped[str] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)


class TestArchive(Base):
    __tablename__ = "test_archive"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    file_id: Mapped[str] = mapped_column(String(300), nullable=False)
    file_type: Mapped[str] = mapped_column(String(20), default="document")
    file_name: Mapped[str] = mapped_column(String(200), nullable=True)
    caption: Mapped[str] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)


class PaymentRequest(Base):
    __tablename__ = "payment_requests"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    student_id: Mapped[int] = mapped_column(Integer, nullable=False)
    group_id: Mapped[int] = mapped_column(Integer, nullable=True)
    user_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    status: Mapped[str] = mapped_column(String(20), default="pending")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)


class MonthlyBilling(Base):
    __tablename__ = "monthly_billings"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    period: Mapped[str] = mapped_column(String(7), nullable=False)
    group_id: Mapped[int] = mapped_column(Integer, nullable=True)
    students_count: Mapped[int] = mapped_column(Integer, default=0)
    total_amount: Mapped[float] = mapped_column(Float, default=0.0)
    created_by: Mapped[int] = mapped_column(BigInteger, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)


class Attendance(Base):
    __tablename__ = "attendances"
    __table_args__ = (
        UniqueConstraint("student_id", "group_id", "day", name="uq_attendance_student_group_day"),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    student_id: Mapped[int] = mapped_column(
        ForeignKey("students.id", ondelete="CASCADE"), nullable=False
    )
    group_id: Mapped[int] = mapped_column(
        ForeignKey("groups.id", ondelete="CASCADE"), nullable=False
    )
    day: Mapped[date] = mapped_column(Date, nullable=False)
    present: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)
    student: Mapped["Student"] = relationship(back_populates="attendances")
    group: Mapped["Group"] = relationship(back_populates="attendances")


class PaymentCard(Base):
    __tablename__ = "payment_cards"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    card: Mapped[str] = mapped_column(String(50), nullable=False)
    tel: Mapped[str] = mapped_column(String(30), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)


class StudentLink(Base):
    __tablename__ = "student_links"
    __table_args__ = (
        UniqueConstraint("tg_id", "student_id", name="uq_link_tg_student"),
    )
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tg_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    student_id: Mapped[int] = mapped_column(
        ForeignKey("students.id", ondelete="CASCADE"), nullable=False
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)


class LinkRequest(Base):
    __tablename__ = "link_requests"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    tg_id: Mapped[int] = mapped_column(BigInteger, nullable=False, index=True)
    student_id: Mapped[int] = mapped_column(
        ForeignKey("students.id", ondelete="CASCADE"), nullable=False
    )
    full_name: Mapped[str] = mapped_column(String(200), nullable=True)
    username: Mapped[str] = mapped_column(String(100), nullable=True)
    phone: Mapped[str] = mapped_column(String(30), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="pending")
    ticket_number: Mapped[int] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)


# ───────────── TICKET (MUROJAAT) ─────────────
class ContactTicket(Base):
    __tablename__ = "contact_tickets"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ticket_number: Mapped[int] = mapped_column(Integer, nullable=False, unique=True)
    from_user_id: Mapped[int] = mapped_column(BigInteger, nullable=False)
    from_role: Mapped[str] = mapped_column(String(20), nullable=False)
    from_name: Mapped[str] = mapped_column(String(200), nullable=True)
    target_user_id: Mapped[int] = mapped_column(BigInteger, nullable=True)
    target_role: Mapped[str] = mapped_column(String(20), nullable=True)
    target_name: Mapped[str] = mapped_column(String(200), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="pending")
    text: Mapped[str] = mapped_column(Text, nullable=True)
    admin_message_id: Mapped[int] = mapped_column(BigInteger, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)


# ───────────── ANONIM FEEDBACK ─────────────
class AnonymousFeedback(Base):
    __tablename__ = "anonymous_feedbacks"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    group_id: Mapped[int] = mapped_column(
        ForeignKey("groups.id", ondelete="SET NULL"), nullable=True
    )
    teacher_id: Mapped[int] = mapped_column(
        ForeignKey("teachers.id", ondelete="CASCADE"), nullable=False
    )
    from_user_id: Mapped[int] = mapped_column(BigInteger, nullable=True)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_utcnow)
