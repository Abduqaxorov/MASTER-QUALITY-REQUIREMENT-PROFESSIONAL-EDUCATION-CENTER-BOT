import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from utils.db_storage import CustomPostgresStorage
from config import BOT_TOKEN, ADMINS
from database.engine import init_db, async_session
from utils.throttling import ThrottlingMiddleware
from utils.menu_reset import MenuResetMiddleware
from handlers import common, fallback
from handlers.admin import (
    groups, debt, debtors_excel, monthly,
    public_files, public_tests, cards, fix_link, ids_excell,
    students_report, warning, teacher_edit, teacher, teacher_contact,
    tickets, anonymous_feedback as admin_feedback, student_delete,
    backup_cmd, sections,
)
from handlers.user import (
    balance, payment, rating, files, test_archieve, contact,
    schedule as user_schedule, contact_teacher,
    anonymous_feedback as user_feedback,
)
from handlers.teacher import (
    excel_upload, students as teacher_students,
    attendance as teacher_attendance, tests as teacher_tests,
    schedule as teacher_schedule, start as teacher_start,
    contact_admin as teacher_contact_admin, reply as teacher_reply,
)
from utils.scheduler import setup_scheduler

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)


async def on_startup(bot: Bot):
    await init_db()
    logger.info("✅ Database tayyor.")
    for admin_id in ADMINS:
        try:
            await bot.send_message(admin_id, "🟢 <b>Bot ishga tushdi!</b>")
        except Exception as e:
            logger.warning("Adminga xabar yuborilmadi (%s): %s", admin_id, e)
    scheduler = setup_scheduler(bot)
    scheduler.start()
    logger.info("⏰ Scheduler ishga tushdi.")


async def on_shutdown(bot: Bot):
    for admin_id in ADMINS:
        try:
            await bot.send_message(admin_id, "🔴 <b>Bot to'xtadi.</b>")
        except Exception:
            pass
    logger.info("Bot to'xtadi.")


async def main():
    bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    storage = CustomPostgresStorage(async_session)
    dp = Dispatcher(bot=bot, storage=storage)
    dp.update.outer_middleware(ThrottlingMiddleware(rate=0.5))
    dp.message.outer_middleware(MenuResetMiddleware())

    # ───────────── Common ─────────────
    dp.include_router(common.router)

    # ───────────── Admin ─────────────
    dp.include_router(sections.router)           # admin bo'limlar (submenyu)
    dp.include_router(groups.router)
    dp.include_router(debt.router)
    dp.include_router(debtors_excel.router)
    dp.include_router(monthly.router)
    dp.include_router(public_files.router)
    dp.include_router(public_tests.router)
    dp.include_router(cards.router)
    dp.include_router(fix_link.router)
    dp.include_router(ids_excell.router)
    dp.include_router(students_report.router)
    dp.include_router(student_delete.router)     # admin: /ochirish <id>
    dp.include_router(backup_cmd.router)          # admin: /backup
    dp.include_router(warning.router)
    dp.include_router(teacher.router)            # o'qituvchi qo'shish + guruhga biriktirish
    dp.include_router(teacher_edit.router)       # ustozni tahrirlash / guruhni o'tkazish
    dp.include_router(teacher_contact.router)    # admin → ustoz bilan bog'lanish
    dp.include_router(admin_feedback.router)     # anonim feedbacklar (PDF)

    # ───────────── User ─────────────
    dp.include_router(balance.router)
    dp.include_router(payment.router)
    dp.include_router(rating.router)
    dp.include_router(files.router)
    dp.include_router(test_archieve.router)
    dp.include_router(contact.router)            # user → admin murojaat
    dp.include_router(contact_teacher.router)    # user → ustoz bilan bog'lanish
    dp.include_router(user_feedback.router)      # user → anonim feedback
    dp.include_router(user_schedule.router)

    # ───────────── Teacher ─────────────
    dp.include_router(teacher_start.router)      # mening guruhlarim
    dp.include_router(teacher_students.router)   # o'quvchi qo'shish (bitta) + ro'yxat
    dp.include_router(excel_upload.router)       # Exceldan yuklash
    dp.include_router(teacher_attendance.router)
    dp.include_router(teacher_tests.router)
    dp.include_router(teacher_schedule.router)
    dp.include_router(teacher_contact_admin.router)  # ustoz → admin murojaat
    dp.include_router(teacher_reply.router)      # ustoz → user/admin reply javobi

    # ───────────── Ticket reply (admin) ─────────────
    dp.include_router(tickets.router)

    # ───────────── Fallback (eng oxirida!) ─────────────
    dp.include_router(fallback.router)

    await on_startup(bot)
    logger.info("🚀 Bot polling boshladi...")
    try:
        await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())
    finally:
        await on_shutdown(bot)
        await bot.session.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Bot to'xtatildi.")
