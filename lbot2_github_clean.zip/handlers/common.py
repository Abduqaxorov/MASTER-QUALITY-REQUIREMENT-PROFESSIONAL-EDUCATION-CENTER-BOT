from aiogram import Router
from aiogram.filters import CommandStart
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from sqlalchemy import select
from config import ADMINS
from database.engine import async_session
from database.models import BotUser, Teacher
from keyboards.reply import admin_menu, user_menu, teacher_menu

router = Router()

WELCOME_ADMIN = (
    "👋 <b>Admin panelga xush kelibsiz!</b>\n"
    "━━━━━━━━━━━━━━━━━━━━\n"
    "Quyidagi menyu tugmalari orqali boshqarasiz:\n"
    "📁 <b>Guruhlar</b> — yaratish, tahlil qilish.\n"
    "💸 <b>Moliya</b> — qarz, oylik hisob-kitob, qarzdorlar (Excel), kartalar.\n"
    "🆔 <b>ID lar</b> — o'quvchi va guruh ID lari (Excel).\n"
    "📗 <b>Hisobot</b> — o'quvchilar hisoboti (Excel).\n"
    "👨‍🏫 <b>Ustozlar</b> — qo'shish, guruhga biriktirish, tahrirlash.\n"
    "📨 <b>Murojaatlar</b> va 🕵️ <b>anonim feedbacklar</b>.\n"
    "📢 <b>E'lonlar</b> — ommaviy fayl va test natijalari.\n"
    "ℹ️ <code>/warning</code> — barcha userlarga e'lon.\n"
    "ℹ️ <code>/ochirish &lt;id&gt;</code> — o'quvchini o'chirish."
)

WELCOME_TEACHER = (
    "👋 <b>Ustoz, panelga xush kelibsiz!</b>\n"
    "━━━━━━━━━━━━━━━━━━━━\n"
    "Siz quyidagilarni qila olasiz:\n"
    "➕ <b>O'quvchi qo'shish</b> — bittalab yoki Exceldan\n"
    "📋 <b>O'quvchilar ro'yxati</b> — ID lari bilan\n"
    "👥 <b>Mening o'quvchilarim</b>\n"
    "🗓 <b>Davomat belgilash</b>\n"
    "📊 <b>Test yuklash</b>\n"
    "📅 <b>Dars jadvali</b>\n"
    "✉️ <b>Admin bilan bog'lanish</b>\n"
    "━━━━━━━━━━━━━━━━━━━━\n"
    "👇 Quyidagi menyu orqali boshqaring."
)

WELCOME_USER = (
    "👋 <b>Assalomu alaykum!</b>\n"
    "O'quv markazi rasmiy botiga xush kelibsiz 🎓\n"
    "━━━━━━━━━━━━━━━━━━━━\n"
    "📉 <b>To'lov va Qarzni tekshirish</b>\n"
    "💳 <b>To'lov qilish</b>\n"
    "🏆 <b>Reyting</b> • 📅 <b>Testlar tarixi</b>\n"
    "📂 <b>Fayllar</b> • 📊 <b>Test natijalari</b>\n"
    "📅 <b>Dars vaqtim</b>\n"
    "👨‍🏫 <b>Ustoz bilan bog'lanish</b>\n"
    "🕵️ <b>Anonim feedback</b>\n"
    "✉️ <b>Admin bilan bog'lanish</b>\n"
    "━━━━━━━━━━━━━━━━━━━━\n"
    "👇 Pastdagi menyu tugmasini tanlang."
)


async def _get_role(tg_id: int) -> str:
    if tg_id in ADMINS:
        return "admin"
    async with async_session() as session:
        teacher = await session.scalar(
            select(Teacher).where(Teacher.tg_id == tg_id, Teacher.is_active == True)
        )
        if teacher:
            return "teacher"
    return "user"


@router.message(CommandStart())
async def start(message: Message, state: FSMContext):
    await state.clear()
    try:
        async with async_session() as session:
            exists = await session.scalar(
                select(BotUser).where(BotUser.tg_id == message.from_user.id)
            )
            if not exists:
                session.add(BotUser(
                    tg_id=message.from_user.id,
                    full_name=message.from_user.full_name,
                    username=message.from_user.username,
                ))
                await session.commit()
    except Exception:
        pass

    role = await _get_role(message.from_user.id)

    if role == "admin":
        await message.answer(WELCOME_ADMIN, reply_markup=admin_menu())
    elif role == "teacher":
        await message.answer(WELCOME_TEACHER, reply_markup=teacher_menu())
    else:
        await message.answer(WELCOME_USER, reply_markup=user_menu())
