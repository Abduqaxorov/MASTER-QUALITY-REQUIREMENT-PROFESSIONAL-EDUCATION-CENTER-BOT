from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from sqlalchemy import select, delete
from config import ADMINS
from states.states import TeacherReassignFSM
from database.engine import async_session
from database.models import Teacher, TeacherGroup, Group
from keyboards.reply import admin_menu
from keyboards.inline import (
    teachers_with_groups_kb, teacher_groups_manage_kb,
    teacher_remove_group_confirm_kb, teacher_delete_confirm_kb,
    teacher_reassign_groups_kb, teacher_reassign_pick_kb,
)
from keyboards.buttons import BTN_TEACHER_EDIT

router = Router()


async def _load_teacher_groups(teacher_id: int):
    async with async_session() as session:
        teacher = await session.get(Teacher, teacher_id)
        links = (await session.scalars(
            select(TeacherGroup).where(TeacherGroup.teacher_id == teacher_id)
        )).all()
        groups = []
        for link in links:
            g = await session.get(Group, link.group_id)
            if g:
                groups.append(g)
    return teacher, groups


async def _show_teacher_card(target: Message, teacher_id: int):
    teacher, groups = await _load_teacher_groups(teacher_id)
    if not teacher:
        await target.answer("❌ Ustoz topilmadi.", reply_markup=admin_menu())
        return
    text = (
        f"👨‍🏫 <b>{teacher.full_name}</b>\n"
        f"📞 {teacher.phone or '—'}\n"
        f"📁 Guruhlar: {len(groups)} ta\n"
        "Guruhni olib tashlash, boshqa ustozga o'tkazish yoki ustozni o'chirish:"
    )
    try:
        await target.edit_text(text, reply_markup=teacher_groups_manage_kb(teacher_id, groups))
    except Exception:
        await target.answer(text, reply_markup=teacher_groups_manage_kb(teacher_id, groups))


@router.message(F.text == BTN_TEACHER_EDIT, F.from_user.id.in_(ADMINS))
async def teacher_edit_start(message: Message, state: FSMContext):
    await state.clear()
    async with async_session() as session:
        teachers = (await session.scalars(
            select(Teacher).where(Teacher.is_active == True)
        )).all()
    if not teachers:
        await message.answer("❌ Hozircha o'qituvchilar yo'q.", reply_markup=admin_menu())
        return
    await message.answer(
        "✏️ <b>Ustozlarni tahrirlash</b>\nTahrirlash uchun ustozni tanlang:",
        reply_markup=teachers_with_groups_kb(teachers)
    )


@router.callback_query(F.data.startswith("tedit:"), F.from_user.id.in_(ADMINS))
async def teacher_select(call: CallbackQuery):
    teacher_id = int(call.data.split(":")[1])
    await _show_teacher_card(call.message, teacher_id)
    await call.answer()


@router.callback_query(F.data == "tback", F.from_user.id.in_(ADMINS))
async def teacher_back(call: CallbackQuery, state: FSMContext):
    await state.clear()
    async with async_session() as session:
        teachers = (await session.scalars(
            select(Teacher).where(Teacher.is_active == True)
        )).all()
    try:
        await call.message.edit_text(
            "✏️ <b>Ustozlarni tahrirlash</b>\nTahrirlash uchun ustozni tanlang:",
            reply_markup=teachers_with_groups_kb(teachers)
        )
    except Exception:
        pass
    await call.answer()


# ───────────── Guruhni olib tashlash ─────────────

@router.callback_query(F.data.startswith("tgrm:"), F.from_user.id.in_(ADMINS))
async def remove_group_ask(call: CallbackQuery):
    parts = call.data.split(":")
    teacher_id, group_id = int(parts[1]), int(parts[2])
    async with async_session() as session:
        group = await session.get(Group, group_id)
    await call.message.edit_text(
        f"⚠️ Ushbu guruhni ustozdan olib tashlaysizmi?\n"
        f"📁 <b>{group.name if group else ''}</b>",
        reply_markup=teacher_remove_group_confirm_kb(teacher_id, group_id)
    )
    await call.answer()


@router.callback_query(F.data.startswith("tgrmok:"), F.from_user.id.in_(ADMINS))
async def remove_group_ok(call: CallbackQuery):
    parts = call.data.split(":")
    teacher_id, group_id = int(parts[1]), int(parts[2])
    async with async_session() as session:
        await session.execute(
            delete(TeacherGroup).where(
                TeacherGroup.teacher_id == teacher_id,
                TeacherGroup.group_id == group_id
            )
        )
        await session.commit()
    await call.answer("Olib tashlandi")
    await _show_teacher_card(call.message, teacher_id)


@router.callback_query(F.data.startswith("tgrmno:"), F.from_user.id.in_(ADMINS))
async def remove_group_no(call: CallbackQuery):
    teacher_id = int(call.data.split(":")[1])
    await _show_teacher_card(call.message, teacher_id)
    await call.answer()


# ───────────── Guruhni boshqa ustozga o'tkazish ─────────────

@router.callback_query(F.data.startswith("treassign:"), F.from_user.id.in_(ADMINS))
async def reassign_start(call: CallbackQuery, state: FSMContext):
    teacher_id = int(call.data.split(":")[1])
    teacher, groups = await _load_teacher_groups(teacher_id)
    if not groups:
        await call.answer("⚠️ Bu ustozda guruh yo'q.", show_alert=True)
        return
    await state.update_data(from_teacher_id=teacher_id)
    await call.message.edit_text(
        f"🔄 <b>{teacher.full_name}</b> dan qaysi guruhni o'tkazamiz?",
        reply_markup=teacher_reassign_groups_kb(groups)
    )
    await state.set_state(TeacherReassignFSM.group)
    await call.answer()


@router.callback_query(TeacherReassignFSM.group, F.data.startswith("treasg:"),
                       F.from_user.id.in_(ADMINS))
async def reassign_group(call: CallbackQuery, state: FSMContext):
    group_id = int(call.data.split(":")[1])
    data = await state.get_data()
    from_teacher_id = data["from_teacher_id"]
    async with async_session() as session:
        group = await session.get(Group, group_id)
        # o'zidan boshqa faol ustozlar
        teachers = (await session.scalars(
            select(Teacher).where(
                Teacher.is_active == True, Teacher.id != from_teacher_id)
        )).all()
    if not teachers:
        await call.answer("⚠️ Boshqa ustoz yo'q. Avval yangi ustoz qo'shing.",
                          show_alert=True)
        return
    await state.update_data(group_id=group_id)
    await call.message.edit_text(
        f"👨‍🏫 <b>{group.name if group else ''}</b> guruhini qaysi ustozga beramiz?",
        reply_markup=teacher_reassign_pick_kb(teachers, group_id)
    )
    await state.set_state(TeacherReassignFSM.new_teacher)
    await call.answer()


@router.callback_query(TeacherReassignFSM.new_teacher, F.data.startswith("treasgt:"),
                       F.from_user.id.in_(ADMINS))
async def reassign_finish(call: CallbackQuery, state: FSMContext):
    parts = call.data.split(":")
    group_id, new_teacher_id = int(parts[1]), int(parts[2])
    async with async_session() as session:
        # UniqueConstraint(group_id) — avval eski bog'lanishni o'chiramiz
        await session.execute(
            delete(TeacherGroup).where(TeacherGroup.group_id == group_id)
        )
        session.add(TeacherGroup(teacher_id=new_teacher_id, group_id=group_id))
        await session.commit()
        group = await session.get(Group, group_id)
        new_teacher = await session.get(Teacher, new_teacher_id)
    await call.message.edit_text(
        f"✅ <b>O'tkazildi!</b>\n"
        f"📁 Guruh: <b>{group.name} [{group.year}]</b>\n"
        f"👨‍🏫 Yangi ustoz: <b>{new_teacher.full_name}</b>"
    )
    await call.message.answer("Bosh menyu:", reply_markup=admin_menu())
    await state.clear()
    await call.answer()


# ───────────── Ustozni o'chirish (soft delete) ─────────────

@router.callback_query(F.data.startswith("tdel:"), F.from_user.id.in_(ADMINS))
async def delete_teacher_ask(call: CallbackQuery):
    teacher_id = int(call.data.split(":")[1])
    async with async_session() as session:
        teacher = await session.get(Teacher, teacher_id)
    await call.message.edit_text(
        f"⚠️ <b>{teacher.full_name if teacher else ''}</b> ni aniq o'chirasizmi?\n"
        "Bu amalni ortga qaytarib bo'lmaydi!",
        reply_markup=teacher_delete_confirm_kb(teacher_id)
    )
    await call.answer()


@router.callback_query(F.data.startswith("tdelok:"), F.from_user.id.in_(ADMINS))
async def delete_teacher_ok(call: CallbackQuery):
    teacher_id = int(call.data.split(":")[1])
    async with async_session() as session:
        teacher = await session.get(Teacher, teacher_id)
        if teacher:
            teacher.is_active = False
            # guruh bog'lanishlarini ham bo'shatamiz
            await session.execute(
                delete(TeacherGroup).where(TeacherGroup.teacher_id == teacher_id)
            )
            await session.commit()
    await call.message.edit_text("✅ Ustoz o'chirildi (guruhlari bo'shatildi).")
    await call.message.answer("Bosh menyu:", reply_markup=admin_menu())
    await call.answer()


@router.callback_query(F.data.startswith("tdelno:"), F.from_user.id.in_(ADMINS))
async def delete_teacher_no(call: CallbackQuery):
    teacher_id = int(call.data.split(":")[1])
    await _show_teacher_card(call.message, teacher_id)
    await call.answer()
