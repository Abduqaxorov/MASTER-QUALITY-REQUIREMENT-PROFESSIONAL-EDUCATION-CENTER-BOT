"""Admin uchun murojaatlar navbati (ticket tizimi)."""
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.filters import StateFilter
from aiogram.fsm.context import FSMContext
from sqlalchemy import select, func
from config import ADMINS
from database.engine import async_session
from database.models import ContactTicket
from keyboards.reply import admin_menu
from keyboards.inline import ticket_decision_kb
from keyboards.buttons import BTN_TICKETS

router = Router()

TAG_USER = "🆔 USER:"
TAG_TEACHER = "🆔 USTOZ:"
# Eski xabarlardagi teglar ham ishlashi uchun
ALL_TAGS = (TAG_USER, TAG_TEACHER, "🆔 User:")
NO_TEXT = "(matn yo'q)"


def _ticket_text(ticket: ContactTicket, new: bool = False) -> str:
    if ticket.from_role == "teacher":
        role_label = "👨‍🏫 <b>USTOZDAN</b>"
        tag = TAG_TEACHER
    else:
        role_label = "👨‍🎓 <b>O'QUVCHIDAN</b>"
        tag = TAG_USER

    target_info = ""
    if ticket.target_name:
        target_info = f"\n🎯 Bog'lanmoqchi: <b>{ticket.target_name}</b>"

    head = "YANGI MUROJAAT" if new else "MUROJAAT"
    return (
        f"📨 <b>{head} #{ticket.ticket_number}</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"{role_label}\n"
        f"👤 {ticket.from_name or '—'}\n"
        f"{tag} <code>{ticket.from_user_id}</code>"
        f"{target_info}\n"
        f"━━━━━━━━━━━━━━\n"
        f"💬 {ticket.text or NO_TEXT}\n"
        f"\n📅 {ticket.created_at.strftime('%Y-%m-%d %H:%M')}\n"
        f"\n<i>Javob berish uchun shu xabarga reply qiling.</i>"
    )


async def notify_admins_new_ticket(bot, ticket: ContactTicket):
    """Yangi murojaat kelganda barcha adminlarga DARROV yuboradi
    (hozir faqat USTOZ murojaatlari uchun ishlatiladi)."""
    text = _ticket_text(ticket, new=True)
    for admin_id in ADMINS:
        try:
            await bot.send_message(admin_id, text,
                                   reply_markup=ticket_decision_kb(ticket.id))
        except Exception:
            pass


async def _send_next_pending(bot, admin_id: int):
    """Keyingi pending (user) ticketni adminga yuboradi."""
    async with async_session() as session:
        ticket = await session.scalar(
            select(ContactTicket)
            .where(ContactTicket.status == "pending")
            .order_by(ContactTicket.ticket_number)
            .limit(1)
        )
        if not ticket:
            await bot.send_message(admin_id, "✅ Hozircha boshqa murojaat yo'q.")
            return None

        msg = await bot.send_message(admin_id, _ticket_text(ticket),
                                     reply_markup=ticket_decision_kb(ticket.id))
        ticket.admin_message_id = msg.message_id
        await session.commit()
        return ticket


@router.message(F.text == BTN_TICKETS, F.from_user.id.in_(ADMINS))
async def tickets_start(message: Message, state: FSMContext):
    await state.clear()
    async with async_session() as session:
        pending = await session.scalar(
            select(func.count(ContactTicket.id))
            .where(ContactTicket.status == "pending")
        ) or 0

    await message.answer(
        f"📨 <b>Murojaatlar navbati</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"⏳ Navbatda (userlar): <b>{pending}</b> ta\n"
        f"ℹ️ Ustoz murojaatlari sizga darhol yuboriladi.\n"
        f"\nKeyingi murojaatni yuboraman..."
    )
    await _send_next_pending(message.bot, message.from_user.id)


@router.callback_query(F.data.startswith("ticketok:"), F.from_user.id.in_(ADMINS))
async def ticket_approve(call: CallbackQuery):
    ticket_id = int(call.data.split(":")[1])
    async with async_session() as session:
        ticket = await session.get(ContactTicket, ticket_id)
        if not ticket or ticket.status not in ["pending", "active"]:
            await call.answer("⚠️ Bu murojaat allaqachon ko'rib chiqilgan.", show_alert=True)
            return
        was_pending = ticket.status == "pending"
        ticket.status = "closed"
        await session.commit()
        from_user_id = ticket.from_user_id
        tnum = ticket.ticket_number

    try:
        await call.bot.send_message(
            from_user_id,
            f"✅ <b>Murojaatingiz #{tnum} ko'rib chiqildi.</b>"
        )
    except Exception:
        pass
    try:
        await call.message.edit_text(call.message.html_text + "\n\n✅ <b>TASDIQLANDI</b>")
    except Exception:
        pass
    await call.answer("Tasdiqlandi")
    # Faqat navbatdagi (user) ticket yopilganda keyingisini ko'rsatamiz
    if was_pending:
        await _send_next_pending(call.bot, call.from_user.id)


@router.callback_query(F.data.startswith("ticketno:"), F.from_user.id.in_(ADMINS))
async def ticket_reject(call: CallbackQuery):
    ticket_id = int(call.data.split(":")[1])
    async with async_session() as session:
        ticket = await session.get(ContactTicket, ticket_id)
        if not ticket or ticket.status not in ["pending", "active"]:
            await call.answer("⚠️ Allaqachon ko'rib chiqilgan.", show_alert=True)
            return
        was_pending = ticket.status == "pending"
        ticket.status = "rejected"
        await session.commit()
        from_user_id = ticket.from_user_id
        tnum = ticket.ticket_number

    try:
        await call.bot.send_message(
            from_user_id,
            f"❌ <b>Murojaatingiz #{tnum} rad etildi.</b>"
        )
    except Exception:
        pass
    try:
        await call.message.edit_text(call.message.html_text + "\n\n❌ <b>RAD ETILDI</b>")
    except Exception:
        pass
    await call.answer("Rad etildi")
    if was_pending:
        await _send_next_pending(call.bot, call.from_user.id)


@router.message(
    StateFilter(None),
    F.from_user.id.in_(ADMINS),
    F.reply_to_message,
)
async def admin_reply_to_ticket(message: Message):
    """Admin har qanday teg'li xabarga (murojaat, link so'rovi, to'lov cheki)
    reply qilsa — javob o'sha odamga boradi."""
    replied = message.reply_to_message
    text = replied.text or replied.caption or ""

    uid = None
    for tag in ALL_TAGS:
        if tag in text:
            try:
                after = text.split(tag, 1)[1].strip()
                uid = int(after.split()[0])
            except (IndexError, ValueError):
                uid = None
            break

    # "🆔 TG:" tegi (to'lov cheklari) uchun ham
    if uid is None and "🆔 TG:" in text:
        try:
            after = text.split("🆔 TG:", 1)[1].strip()
            uid = int(after.split()[0])
        except (IndexError, ValueError):
            uid = None

    if uid is None:
        return

    try:
        await message.bot.send_message(uid, "📬 <b>Admin javobi:</b>\n━━━━━━━━━━━━━━")
        await message.copy_to(uid)
        await message.answer("✅ Javob yuborildi.")
    except Exception:
        await message.answer("❌ Yuborib bo'lmadi (user botni bloklagan bo'lishi mumkin).")
