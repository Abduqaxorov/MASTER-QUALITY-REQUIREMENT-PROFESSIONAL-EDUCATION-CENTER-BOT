"""Admin o'qituvchi bilan bog'lanishi."""
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from sqlalchemy import select
from config import ADMINS
from database.engine import async_session
from database.models import Teacher
from keyboards.inline import teachers_kb
from keyboards.reply import admin_menu
from states.states import AdminContactTeacherFSM
from keyboards.buttons import BTN_ADMIN_CONTACT_TEACHER

router = Router()


@router.message(F.text == BTN_ADMIN_CONTACT_TEACHER, F.from_user.id.in_(ADMINS))
async def admin_contact_teacher_start(message: Message, state: FSMContext):
    await state.clear()
    async with async_session() as session:
        teachers = (await session.scalars(
            select(Teacher).where(Teacher.is_active == True)
        )).all()

    if not teachers:
        await message.answer("❌ Hozircha o'qituvchilar yo'q. Avval qo'shing.")
        return

    await message.answer(
        "👨‍🏫 <b>Ustoz bilan bog'lanish</b>\n"
        "━━━━━━━━━━━━━━\n"
        "Qaysi ustozga xabar yubormoqchisiz?",
        reply_markup=teachers_kb(teachers, prefix="admintch")
    )
    await state.set_state(AdminContactTeacherFSM.teacher)


@router.callback_query(AdminContactTeacherFSM.teacher, F.data.startswith("admintch:"))
async def admin_contact_teacher_pick(call: CallbackQuery, state: FSMContext):
    teacher_id = int(call.data.split(":")[1])
    async with async_session() as session:
        teacher = await session.get(Teacher, teacher_id)
        if not teacher:
            await call.answer("❌ Ustoz topilmadi", show_alert=True)
            return

    await state.update_data(teacher_id=teacher.id, teacher_tg_id=teacher.tg_id,
                            teacher_name=teacher.full_name)
    try:
        await call.message.edit_text(
            f"✍️ <b>{teacher.full_name}</b> ga yubormoqchi bo'lgan xabaringizni yozing:"
        )
    except Exception:
        await call.message.answer(
            f"✍️ <b>{teacher.full_name}</b> ga yubormoqchi bo'lgan xabaringizni yozing:"
        )
    await state.set_state(AdminContactTeacherFSM.text)
    await call.answer()


@router.message(AdminContactTeacherFSM.text, F.from_user.id.in_(ADMINS))
async def admin_contact_teacher_text(message: Message, state: FSMContext):
    data = await state.get_data()
    teacher_tg_id = data.get("teacher_tg_id")
    teacher_name = data.get("teacher_name")
    admin = message.from_user

    text_to_teacher = (
        f"📨 <b>Admindan xabar</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"👤 {admin.full_name}\n"
        f"━━━━━━━━━━━━━━\n"
        f"💬 {message.text.strip()}\n"
        f"\n<i>Javob berish uchun shu xabarga reply qiling.</i>\n"
        f"🆔 ADMIN: <code>{admin.id}</code>"
    )

    try:
        await message.bot.send_message(teacher_tg_id, text_to_teacher)
        await message.answer(
            f"✅ Xabaringiz <b>{teacher_name}</b> ga yuborildi.",
            reply_markup=admin_menu()
        )
    except Exception:
        await message.answer(
            "❌ Ustozga yuborib bo'lmadi (botni bloklagan bo'lishi mumkin).",
            reply_markup=admin_menu()
        )

    await state.clear()