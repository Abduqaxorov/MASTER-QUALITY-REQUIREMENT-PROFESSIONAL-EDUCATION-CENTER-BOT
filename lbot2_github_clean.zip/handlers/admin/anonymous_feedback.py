"""Admin uchun anonim feedbacklarni ko'rishi (PDF)."""
import io
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, BufferedInputFile
from aiogram.fsm.context import FSMContext
from sqlalchemy import select, func
from config import ADMINS
from database.engine import async_session
from database.models import Teacher, AnonymousFeedback
from keyboards.reply import admin_menu
from keyboards.inline import feedback_teachers_kb
from keyboards.buttons import BTN_ANON_FEEDBACK
from utils.pdf import make_feedback_pdf

router = Router()


@router.message(F.text == BTN_ANON_FEEDBACK, F.from_user.id.in_(ADMINS))
async def feedback_start(message: Message, state: FSMContext):
    await state.clear()
    async with async_session() as session:
        result = await session.execute(
            select(Teacher, func.count(AnonymousFeedback.id))
            .join(AnonymousFeedback, Teacher.id == AnonymousFeedback.teacher_id)
            .group_by(Teacher.id)
            .having(func.count(AnonymousFeedback.id) > 0)
        )
        teachers_with_fb = result.all()

        total = await session.scalar(select(func.count(AnonymousFeedback.id))) or 0

    if total == 0:
        await message.answer("🕵️ Hozircha anonim feedback yo'q.", reply_markup=admin_menu())
        return

    await message.answer(
        f"🕵️ <b>Anonim feedbacklar</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"📊 Jami: <b>{total}</b> ta\n"
        f"\nO'qituvchini tanlang (faqat feedbacki borlari):",
        reply_markup=feedback_teachers_kb(teachers_with_fb)
    )


@router.callback_query(F.data.startswith("fbtch:"), F.from_user.id.in_(ADMINS))
async def feedback_teacher(call: CallbackQuery):
    teacher_id = int(call.data.split(":")[1])
    async with async_session() as session:
        teacher = await session.get(Teacher, teacher_id)
        feedbacks = (await session.scalars(
            select(AnonymousFeedback)
            .where(AnonymousFeedback.teacher_id == teacher_id)
            .order_by(AnonymousFeedback.created_at.desc())
        )).all()

    if not teacher or not feedbacks:
        await call.answer("Feedback yo'q", show_alert=True)
        return

    await call.answer("📄 Hisobot tayyorlanmoqda...")
    pdf_buffer = make_feedback_pdf(teacher.full_name, feedbacks)
    
    # fayl nomini xavfsiz qilamiz
    safe_name = "".join(c for c in teacher.full_name if c.isalnum() or c in " _-").strip()
    safe_name = safe_name.replace(" ", "_") or "ustoz"

    if pdf_buffer:
        file = BufferedInputFile(pdf_buffer.read(), filename=f"feedback_{safe_name}.pdf")
        await call.message.answer_document(
            file,
            caption=(
                f"🕵️ <b>{teacher.full_name}</b> uchun feedbacklar (PDF)\n"
                f"📊 Jami: {len(feedbacks)} ta"
            )
        )
    else:
        # Agar PDF bo'lmasa, TXT variantini yuboramiz
        txt_content = f"Anonim feedbacklar\nUstoz: {teacher.full_name}\nJami: {len(feedbacks)} ta\n"
        txt_content += "━━━━━━━━━━━━━━\n\n"
        for i, fb in enumerate(feedbacks, 1):
            created = fb.created_at.strftime("%Y-%m-%d %H:%M") if fb.created_at else ""
            txt_content += f"#{i} | {created}\n{fb.text}\n"
            txt_content += "----------------\n"
        
        txt_buffer = io.BytesIO(txt_content.encode("utf-8"))
        txt_buffer.seek(0)
        file = BufferedInputFile(txt_buffer.read(), filename=f"feedback_{safe_name}.txt")
        await call.message.answer_document(
            file,
            caption=(
                f"🕵️ <b>{teacher.full_name}</b> uchun feedbacklar (TXT)\n"
                f"⚠️ PDF yaratishda xato bo'ldi, matn shaklida yuborildi.\n"
                f"📊 Jami: {len(feedbacks)} ta"
            )
        )
