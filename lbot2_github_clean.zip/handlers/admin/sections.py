"""Admin panel bo'limlari (submenyu) handleri."""
from aiogram import Router, F
from aiogram.types import Message
from aiogram.fsm.context import FSMContext

from config import ADMINS
from keyboards.buttons import (
    BTN_SEC_GROUPS, BTN_SEC_FINANCE, BTN_SEC_REPORTS,
    BTN_SEC_TEACHERS, BTN_SEC_ANNOUNCE, BTN_SEC_TICKETS, BTN_BACK,
)
from keyboards.reply import (
    admin_menu, admin_groups_menu, admin_finance_menu, admin_reports_menu,
    admin_teachers_menu, admin_announce_menu, admin_tickets_menu,
)

router = Router()
router.message.filter(F.from_user.id.in_(ADMINS))


@router.message(F.text == BTN_SEC_GROUPS)
async def sec_groups(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "📁 <b>Guruhlar bo'limi</b>\nKerakli amalni tanlang:",
        reply_markup=admin_groups_menu())


@router.message(F.text == BTN_SEC_FINANCE)
async def sec_finance(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "💰 <b>Moliya bo'limi</b>\nKerakli amalni tanlang:",
        reply_markup=admin_finance_menu())


@router.message(F.text == BTN_SEC_REPORTS)
async def sec_reports(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "📈 <b>Hisobotlar bo'limi</b>\nKerakli amalni tanlang:",
        reply_markup=admin_reports_menu())


@router.message(F.text == BTN_SEC_TEACHERS)
async def sec_teachers(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "🧑‍🏫 <b>Ustozlar bo'limi</b>\nKerakli amalni tanlang:",
        reply_markup=admin_teachers_menu())


@router.message(F.text == BTN_SEC_ANNOUNCE)
async def sec_announce(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "📣 <b>E'lonlar bo'limi</b>\nKerakli amalni tanlang:",
        reply_markup=admin_announce_menu())


@router.message(F.text == BTN_SEC_TICKETS)
async def sec_tickets(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "📥 <b>Murojaatlar bo'limi</b>\nKerakli amalni tanlang:",
        reply_markup=admin_tickets_menu())


@router.message(F.text == BTN_BACK)
async def sec_back(message: Message, state: FSMContext):
    await state.clear()
    await message.answer("🏠 <b>Asosiy menyu</b>", reply_markup=admin_menu())
