from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from sqlalchemy import select, or_
from sqlalchemy.orm import selectinload

from config import ADMINS
from states.states import DebtFSM
from database.engine import async_session
from database.models import Student, StudentGroup, Group
from keyboards.reply import admin_menu
from keyboards.inline import students_select_kb, student_groups_select_kb
from keyboards.buttons import BTN_DEBT

router = Router()


@router.message(F.text == BTN_DEBT, F.from_user.id.in_(ADMINS))
async def debt_start(message: Message, state: FSMContext):
    await state.clear()
    await message.answer("O'quvchi ism yoki familiyasini kiriting:")
    await state.set_state(DebtFSM.search)


@router.message(DebtFSM.search)
async def debt_search(message: Message, state: FSMContext):
    q = message.text.strip()
    async with async_session() as session:
        students = (await session.scalars(
            select(Student).options(
                selectinload(Student.group_links).selectinload(StudentGroup.group))
            .where(or_(
                Student.name.ilike(f"%{q}%"), Student.last_name.ilike(f"%{q}%")))
            .limit(50)
        )).all()
    if not students:
        await message.answer("❌ Topilmadi. Qayta kiriting:")
        return
    await message.answer("Tanlang:", reply_markup=students_select_kb(students, "debt"))
    await state.set_state(DebtFSM.select)


@router.callback_query(DebtFSM.select, F.data.startswith("debt:"))
async def debt_pick(call: CallbackQuery, state: FSMContext):
    sid = int(call.data.split(":")[1])
    async with async_session() as session:
        links = (await session.scalars(
            select(StudentGroup).options(selectinload(StudentGroup.group))
            .where(StudentGroup.student_id == sid)
        )).all()

    if not links:
        await call.answer("❌ Bu o'quvchi hech qanday guruhda yo'q.", show_alert=True)
        return

    await state.update_data(student_id=sid)

    if len(links) == 1:
        await state.update_data(group_id=links[0].group_id)
        await call.message.edit_text(
            f"📁 Fan: <b>{links[0].group.name}</b>\nEski qarz summasini kiriting:")
        await state.set_state(DebtFSM.amount)
    else:
        groups = [l.group for l in links]
        await call.message.edit_text(
            "Qaysi fan uchun qarz yozamiz?",
            reply_markup=student_groups_select_kb(groups, "debtgrp"))
    await call.answer()


@router.callback_query(DebtFSM.select, F.data.startswith("debtgrp:"))
async def debt_group_pick(call: CallbackQuery, state: FSMContext):
    gid = int(call.data.split(":")[1])
    await state.update_data(group_id=gid)
    async with async_session() as session:
        g = await session.get(Group, gid)
    await call.message.edit_text(
        f"📁 Fan: <b>{g.name if g else '—'}</b>\nEski qarz summasini kiriting:")
    await state.set_state(DebtFSM.amount)
    await call.answer()


@router.message(DebtFSM.amount)
async def debt_amount(message: Message, state: FSMContext):
    try:
        amount = float(message.text.replace(" ", "").replace(",", ""))
    except (ValueError, AttributeError):
        await message.answer("❌ Faqat raqam kiriting:")
        return
    data = await state.get_data()
    sid = data.get("student_id")
    gid = data.get("group_id")
    if not sid or not gid:
        await message.answer("❌ Sessiya tugadi. «💸 Qarz yozish» dan qayta boshlang.",
                             reply_markup=admin_menu())
        await state.clear()
        return
    async with async_session() as session:
        link = await session.scalar(
            select(StudentGroup).where(
                StudentGroup.student_id == sid, StudentGroup.group_id == gid)
        )
        if not link:
            await message.answer("❌ Bog'liqlik topilmadi.", reply_markup=admin_menu())
            await state.clear()
            return

        link.balance -= amount
        await session.commit()

        student = await session.get(Student, sid)
        group = await session.get(Group, gid)
        nb = link.balance
        fn = f"{student.name} {student.last_name}"
    await message.answer(
        f"✅ <b>{fn}</b> ({group.name}) balansidan {amount:,.0f} so'm ayirildi.\n"
        f"💰 Yangi balans: {nb:,.0f} so'm", reply_markup=admin_menu())
    await state.clear()
