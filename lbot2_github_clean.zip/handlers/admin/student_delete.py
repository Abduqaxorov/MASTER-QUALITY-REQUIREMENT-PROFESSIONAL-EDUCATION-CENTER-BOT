"""Admin: o'quvchini ID orqali o'chirish (menyusiz, faqat buyruq)."""
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from config import ADMINS
from database.engine import async_session
from database.models import Student
from keyboards.inline import student_remove_confirm_kb

router = Router()


@router.message(F.text.startswith("/ochirish"), F.from_user.id.in_(ADMINS))
async def remove_by_id(message: Message):
    parts = message.text.split()
    if len(parts) != 2 or not parts[1].isdigit():
        await message.answer(
            "❌ Foydalanish: <code>/ochirish 15</code>\n"
            "15 — o'quvchining <b>student_id</b> si.\n"
            "ID larni «🆔 O'quvchi va Guruh ID lari (Excel)» dan olishingiz mumkin."
        )
        return
    sid = int(parts[1])
    async with async_session() as session:
        s = await session.get(Student, sid)
    if not s:
        await message.answer(f"❌ ID {sid} bo'yicha o'quvchi topilmadi.")
        return
    await message.answer(
        f"⚠️ <b>{s.name} {s.last_name}</b> (ID: {sid}) ni o'chirishni xohlaysizmi?\n"
        "Bu amalni ortga qaytarib bo'lmaydi.",
        reply_markup=student_remove_confirm_kb(sid),
    )


@router.callback_query(F.data.startswith("delok:"))
async def remove_confirm(call: CallbackQuery):
    if call.from_user.id not in ADMINS:
        await call.answer("Ruxsat yo'q!", show_alert=True)
        return
    sid = int(call.data.split(":")[1])
    async with async_session() as session:
        s = await session.get(Student, sid)
        if s:
            await session.delete(s)
            await session.commit()
    try:
        await call.message.edit_text("❌ O'quvchi o'chirildi.")
    except Exception:
        pass
    await call.answer("O'chirildi")


@router.callback_query(F.data.startswith("delno:"))
async def remove_cancel(call: CallbackQuery):
    try:
        await call.message.edit_text("✅ Bekor qilindi.")
    except Exception:
        pass
    await call.answer()
