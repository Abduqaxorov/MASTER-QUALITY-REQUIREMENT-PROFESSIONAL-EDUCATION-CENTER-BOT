from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from sqlalchemy import select, or_
from sqlalchemy.orm import selectinload

from config import ADMINS
from states.states import AdminFixLinkFSM
from database.engine import async_session
from database.models import Student, LinkRequest, StudentGroup
from keyboards.reply import admin_menu
from keyboards.inline import students_select_kb
from keyboards.buttons import BTN_FIX_LINK
from utils.linking import unlink_all, link_student, get_linked_students

router = Router()


# ───────────── Link so'rovini tasdiqlash / rad etish ─────────────

@router.callback_query(F.data.startswith("linkok:"), F.from_user.id.in_(ADMINS))
async def link_approve(call: CallbackQuery):
    req_id = int(call.data.split(":")[1])
    async with async_session() as session:
        req = await session.get(LinkRequest, req_id)
        if not req or req.status != "pending":
            await call.answer("⚠️ Bu so'rov allaqachon ko'rib chiqilgan.", show_alert=True)
            return
        s = await session.get(Student, req.student_id)
        req.status = "approved"
        await session.commit()
        tg_id = req.tg_id
        student_id = req.student_id
        sname = f"{s.name} {s.last_name}" if s else "o'quvchi"

    await link_student(tg_id, student_id)

    try:
        await call.message.edit_text(
            call.message.html_text + "\n\n✅ <b>TASDIQLANDI</b>"
        )
    except Exception:
        pass
    try:
        await call.bot.send_message(
            tg_id,
            f"✅ <b>Bog'lanish tasdiqlandi!</b>\n"
            f"🎓 Siz <b>{sname}</b> ga bog'landingiz.\n"
            "Endi menyudagi tugmalar siz uchun ishlaydi."
        )
    except Exception:
        pass
    await call.answer("Tasdiqlandi")


@router.callback_query(F.data.startswith("linkno:"), F.from_user.id.in_(ADMINS))
async def link_reject(call: CallbackQuery):
    req_id = int(call.data.split(":")[1])
    async with async_session() as session:
        req = await session.get(LinkRequest, req_id)
        if not req or req.status != "pending":
            await call.answer("⚠️ Allaqachon ko'rib chiqilgan.", show_alert=True)
            return
        req.status = "rejected"
        await session.commit()
        tg_id = req.tg_id

    try:
        await call.message.edit_text(
            call.message.html_text + "\n\n❌ <b>RAD ETILDI</b>"
        )
    except Exception:
        pass
    try:
        await call.bot.send_message(
            tg_id,
            "❌ <b>Bog'lanish so'rovingiz rad etildi.</b>\n"
            "Iltimos, «✉️ Admin bilan bog'lanish» tugmasi orqali admin bilan bog'laning."
        )
    except Exception:
        pass
    await call.answer("Rad etildi")


# ───────────── Qo'lda tuzatish (eski funksiya) ─────────────

@router.message(F.text == BTN_FIX_LINK, F.from_user.id.in_(ADMINS))
async def fix_start(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "🔧 Tuzatiladigan foydalanuvchining <b>Telegram ID</b> sini kiriting:\n"
        "(Murojaat xabarlarida 🆔 User: <code>123...</code> ko'rinishida bo'ladi)"
    )
    await state.set_state(AdminFixLinkFSM.user_id)


@router.message(AdminFixLinkFSM.user_id, F.from_user.id.in_(ADMINS))
async def fix_user_id(message: Message, state: FSMContext):
    raw = message.text.strip()
    if not raw.isdigit():
        await message.answer("❌ Faqat raqam (Telegram ID) kiriting:")
        return
    tg_id = int(raw)
    linked = await get_linked_students(tg_id)
    if linked:
        names = "\n".join(f"• {s.name} {s.last_name}" for s in linked)
        info = f"\n\nHozir bog'langan:\n{names}"
    else:
        info = "\n\nHozir hech kimga bog'lanmagan."
    await state.update_data(user_id=tg_id)
    await message.answer(
        f"🆔 <code>{tg_id}</code>{info}\n\n"
        "Yangi o'quvchi (ism/familiya) ni kiriting. "
        "Eski bog'lanish o'chiriladi va yangisi qo'yiladi:"
    )
    await state.set_state(AdminFixLinkFSM.search)


@router.message(AdminFixLinkFSM.search, F.from_user.id.in_(ADMINS))
async def fix_search(message: Message, state: FSMContext):
    q = message.text.strip()
    async with async_session() as session:
        students = (await session.scalars(
            select(Student).options(selectinload(Student.group_links).selectinload(StudentGroup.group))
            .where(or_(
                Student.name.ilike(f"%{q}%"), 
                Student.last_name.ilike(f"%{q}%")
            ))
            .limit(50)
        )).all()
    if not students:
        await message.answer("❌ Topilmadi. Qayta kiriting:")
        return
    await message.answer("Tanlang:", reply_markup=students_select_kb(students, "fixpick"))


@router.callback_query(AdminFixLinkFSM.search, F.data.startswith("fixpick:"),
                       F.from_user.id.in_(ADMINS))
async def fix_pick(call: CallbackQuery, state: FSMContext):
    sid = int(call.data.split(":")[1])
    data = await state.get_data()
    tg_id = data["user_id"]
    await unlink_all(tg_id)
    await link_student(tg_id, sid)
    async with async_session() as session:
        s = await session.get(Student, sid)
    try:
        await call.message.edit_reply_markup(reply_markup=None)
    except Exception:
        pass
    await call.message.answer(
        f"✅ <code>{tg_id}</code> endi <b>{s.name} {s.last_name}</b> ga bog'landi.",
        reply_markup=admin_menu(),
    )
    await state.clear()
    await call.answer()
