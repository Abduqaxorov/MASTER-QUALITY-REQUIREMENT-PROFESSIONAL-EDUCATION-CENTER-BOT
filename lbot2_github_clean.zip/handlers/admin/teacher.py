"""O'qituvchilarni boshqarish (admin)."""
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from sqlalchemy import select, delete
from config import ADMINS
from states.states import TeacherFSM, TeacherAssignFSM
from database.engine import async_session
from database.models import Teacher, Group, TeacherGroup
from keyboards.reply import admin_menu
from keyboards.inline import teachers_kb, groups_kb
from keyboards.buttons import BTN_TEACHER_ADD, BTN_TEACHER_ASSIGN

router = Router()

# ← backslash muammosini hal qilish uchun
DEFAULT_TEACHER_NAME = "o'qituvchi"


# ───────────── O'QITUVCHI QO'SHISH ─────────────
@router.message(F.text == BTN_TEACHER_ADD, F.from_user.id.in_(ADMINS))
async def teacher_add_start(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "👨‍🏫 <b>Yangi o'qituvchi qo'shish</b>\n"
        "━━━━━━━━━━━━━━\n"
        "Telegram ID sini kiriting (masalan: <code>123456789</code>):"
    )
    await state.set_state(TeacherFSM.tg_id)


@router.message(TeacherFSM.tg_id)
async def teacher_tg_id(message: Message, state: FSMContext):
    raw = message.text.strip()
    if not raw.isdigit():
        await message.answer("❌ Faqat raqam kiriting:")
        return
    tg_id = int(raw)

    async with async_session() as session:
        exists = await session.scalar(
            select(Teacher).where(Teacher.tg_id == tg_id)
        )
        if exists:
            await message.answer("⚠️ Bu ID allaqachon o'qituvchi sifatida qo'shilgan.")
            await state.clear()
            return

    await state.update_data(tg_id=tg_id)
    await message.answer("👤 To'liq ismini kiriting (Ism Familiya):")
    await state.set_state(TeacherFSM.full_name)


@router.message(TeacherFSM.full_name)
async def teacher_name(message: Message, state: FSMContext):
    name = message.text.strip()
    if len(name) < 3:
        await message.answer("❌ Ism juda qisqa. Qayta kiriting:")
        return
    await state.update_data(full_name=name)
    await message.answer("📞 Telefon raqamini kiriting (yo'q bo'lsa: <code>-</code>):")
    await state.set_state(TeacherFSM.phone)


@router.message(TeacherFSM.phone)
async def teacher_phone(message: Message, state: FSMContext):
    phone = message.text.strip()
    if phone == "-":
        phone = None
    data = await state.get_data()

    async with async_session() as session:
        session.add(Teacher(
            tg_id=data["tg_id"],
            full_name=data["full_name"],
            phone=phone,
        ))
        await session.commit()

    await message.answer(
        f"✅ <b>O'qituvchi qo'shildi!</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"👤 {data['full_name']}\n"
        f"🆔 <code>{data['tg_id']}</code>\n"
        f"📞 {phone or '—'}\n"
        f"\nEndi u /start bosib, o'qituvchi paneliga kirishi mumkin.",
        reply_markup=admin_menu()
    )
    await state.clear()


# ───────────── O'QITUVCHINI GURUHGA BIRIKTIRISH ─────────────
@router.message(F.text == BTN_TEACHER_ASSIGN, F.from_user.id.in_(ADMINS))
async def assign_start(message: Message, state: FSMContext):
    await state.clear()
    async with async_session() as session:
        groups = (await session.scalars(
            select(Group).order_by(Group.year, Group.name)
        )).all()
        if not groups:
            await message.answer("❌ Avval guruh yarating!", reply_markup=admin_menu())
            return
    await message.answer("📁 Qaysi guruhga biriktiramiz?", reply_markup=groups_kb(groups, "asgngrp"))
    await state.set_state(TeacherAssignFSM.group)


@router.callback_query(TeacherAssignFSM.group, F.data.startswith("asgngrp:"))
async def assign_group(call: CallbackQuery, state: FSMContext):
    group_id = int(call.data.split(":")[1])
    await state.update_data(group_id=group_id)

    async with async_session() as session:
        existing = await session.scalar(
            select(TeacherGroup).where(TeacherGroup.group_id == group_id)
        )
        teachers = (await session.scalars(
            select(Teacher).where(Teacher.is_active == True)
        )).all()

    if not teachers:
        await call.message.edit_text("❌ Avval o'qituvchi qo'shing!")
        await call.message.answer("Bosh menyu:", reply_markup=admin_menu())
        await state.clear()
        await call.answer()
        return

    if existing:
        async with async_session() as session:
            old_teacher = await session.get(Teacher, existing.teacher_id)

        # ← MUHIM: backslash yo'q
        old_name = old_teacher.full_name if old_teacher else DEFAULT_TEACHER_NAME

        await call.message.edit_text(
            f"⚠️ Bu guruhda allaqachon <b>{old_name}</b> bor.\n"
            f"Yangi o'qituvchini tanlang (eskisi almashtiriladi):",
            reply_markup=teachers_kb(teachers)
        )
    else:
        await call.message.edit_text(
            "👨‍🏫 Guruh uchun o'qituvchini tanlang:",
            reply_markup=teachers_kb(teachers)
        )

    await state.set_state(TeacherAssignFSM.teacher)
    await call.answer()


@router.callback_query(TeacherAssignFSM.teacher, F.data.startswith("tch:"))
async def assign_teacher(call: CallbackQuery, state: FSMContext):
    teacher_id = int(call.data.split(":")[1])
    data = await state.get_data()
    group_id = data["group_id"]

    async with async_session() as session:
        await session.execute(
            delete(TeacherGroup).where(TeacherGroup.group_id == group_id)
        )
        session.add(TeacherGroup(teacher_id=teacher_id, group_id=group_id))
        await session.commit()

        teacher = await session.get(Teacher, teacher_id)
        group = await session.get(Group, group_id)

    await call.message.edit_text(
        f"✅ <b>Biriktirildi!</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"📁 Guruh: <b>{group.name} [{group.year}]</b>\n"
        f"👨‍🏫 Ustoz: <b>{teacher.full_name}</b>"
    )
    await call.message.answer("Bosh menyu:", reply_markup=admin_menu())
    await state.clear()
    await call.answer()