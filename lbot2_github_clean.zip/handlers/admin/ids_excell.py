"""O'quvchi, guruh va o'qituvchi ID larini Excel ga eksport."""
import io
from aiogram import Router, F
from aiogram.types import Message, BufferedInputFile
from sqlalchemy import select
from sqlalchemy.orm import selectinload
import pandas as pd
from config import ADMINS
from database.engine import async_session
from database.models import Student, Group, Teacher, TeacherGroup, StudentGroup
from keyboards.reply import admin_menu
from keyboards.buttons import BTN_IDS_EXCEL

router = Router()


@router.message(F.text == BTN_IDS_EXCEL, F.from_user.id.in_(ADMINS))
async def ids_excel(message: Message):
    async with async_session() as session:
        # Barcha o'quvchi-guruh bog'liqliklarini olish
        links = (await session.scalars(
            select(StudentGroup).options(
                selectinload(StudentGroup.student),
                selectinload(StudentGroup.group)
            ).order_by(StudentGroup.group_id)
        )).all()

        groups = (await session.scalars(
            select(Group).order_by(Group.year, Group.name)
        )).all()
        teachers = (await session.scalars(
            select(Teacher).where(Teacher.is_active == True)
        )).all()
        tg_links = (await session.scalars(
            select(TeacherGroup).options(
                selectinload(TeacherGroup.teacher),
                selectinload(TeacherGroup.group)
            )
        )).all()

    # O'quvchilar
    s_rows = []
    # O'quvchilar necha guruhda ekanligini hisoblash
    student_group_counts = {}
    for link in links:
        student_group_counts[link.student_id] = student_group_counts.get(link.student_id, 0) + 1

    for link in links:
        s = link.student
        g = link.group
        count = student_group_counts.get(s.id, 1)
        multi_label = f" [Multi: {count}]" if count > 1 else ""

        s_rows.append({
            "student_id": s.id,
            "Ism": s.name + multi_label,
            "Familiya": s.last_name,
            "Telefon": s.tel or "",
            "group_id": g.id if g else "",
            "Guruh": g.name if g else "",
        })

    # Guruhlar
    g_rows = []
    for g in groups:
        g_rows.append({
            "group_id": g.id,
            "Guruh nomi": g.name,
            "Yil": g.year,
            "Oylik": g.monthly_price,
        })

    # O'qituvchilar
    t_rows = []
    for t in teachers:
        t_rows.append({
            "teacher_id": t.id,
            "Ism": t.full_name,
            "Telegram ID": t.tg_id,
            "Telefon": t.phone or "",
        })

    # Bog'lanishlar
    link_rows = []
    for link in tg_links:
        link_rows.append({
            "group_id": link.group.id,
            "Guruh": link.group.name,
            "teacher_id": link.teacher.id,
            "Ustoz": link.teacher.full_name,
        })

    # Excel yaratish (ko'p varaq)
    buffer = io.BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        pd.DataFrame(s_rows).to_excel(writer, sheet_name="O'quvchilar", index=False)
        pd.DataFrame(g_rows).to_excel(writer, sheet_name="Guruhlar", index=False)
        pd.DataFrame(t_rows).to_excel(writer, sheet_name="O'qituvchilar", index=False)
        pd.DataFrame(link_rows).to_excel(writer, sheet_name="Ustoz-Guruh", index=False)
    buffer.seek(0)

    file = BufferedInputFile(buffer.read(), filename="barcha_id_lar.xlsx")
    await message.answer_document(
        file,
        caption=(
            "🆔 <b>Barcha ID lar</b>\n"
            "━━━━━━━━━━━━━━\n"
            f"👥 O'quvchilar: {len(links)}\n"
            f"📁 Guruhlar: {len(groups)}\n"
            f"👨‍🏫 O'qituvchilar: {len(teachers)}\n"
            f"🔗 Bog'lanishlar: {len(tg_links)}\n"
            "\n4 ta varaq: O'quvchilar, Guruhlar, O'qituvchilar, Ustoz-Guruh"
        ),
        reply_markup=admin_menu()
    )