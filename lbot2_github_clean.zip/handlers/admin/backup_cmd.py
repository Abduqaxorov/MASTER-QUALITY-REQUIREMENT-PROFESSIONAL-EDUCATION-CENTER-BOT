"""Admin: /backup — istalgan paytda qo'lda backup olish."""
from datetime import datetime
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, BufferedInputFile
from config import ADMINS
from utils.backup import make_backup

router = Router()


@router.message(Command("backup"), F.from_user.id.in_(ADMINS))
async def manual_backup(message: Message):
    await message.answer("💾 Backup tayyorlanmoqda, kuting...")
    buffer = await make_backup()
    if not buffer:
        await message.answer(
            "❌ Backup olishda xato bo'ldi. Server logini tekshiring."
        )
        return
    stamp = datetime.now().strftime("%Y-%m-%d_%H-%M")
    file = BufferedInputFile(buffer.read(), filename=f"backup_{stamp}.sql")
    await message.answer_document(
        file,
        caption=f"💾 <b>Qo'lda olingan backup</b>\n🗓 {stamp}",
    )
