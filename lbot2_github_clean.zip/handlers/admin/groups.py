from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from sqlalchemy import select, func, delete

from config import ADMINS
from states.states import GroupFSM, GroupRenameFSM
from database.engine import async_session
from database.models import Group, StudentGroup
from keyboards.reply import admin_menu
from keyboards.buttons import BTN_NEW_GROUP, BTN_GROUP_ANALYSIS
from keyboards.inline import (
    group_analysis_kb, group_actions_kb, group_delete_confirm_kb,
)

router = Router()


# ───────────── Yangi guruh yaratish ─────────────

@router.message(F.text == BTN_NEW_GROUP, F.from_user.id.in_(ADMINS))
async def new_group(message: Message, state: FSMContext):
    await message.answer("Guruh nomini kiriting:")
    await state.set_state(GroupFSM.name)


@router.message(GroupFSM.name)
async def group_name(message: Message, state: FSMContext):
    await state.update_data(name=message.text.strip())
    await message.answer("O'quv yilini kiriting (masalan: 2025):")
    await state.set_state(GroupFSM.year)


@router.message(GroupFSM.year)
async def group_year(message: Message, state: FSMContext):
    try:
        year = int(message.text.strip())
        if not (2000 <= year <= 2100):
            raise ValueError
    except ValueError:
        await message.answer("❌ Yil noto'g'ri. Masalan: 2025")
        return
    await state.update_data(year=year)
    await message.answer("Oylik narxini kiriting (faqat raqam):")
    await state.set_state(GroupFSM.price)


@router.message(GroupFSM.price)
async def group_price(message: Message, state: FSMContext):
    try:
        price = float(message.text.replace(" ", "").replace(",", ""))
    except ValueError:
        await message.answer("❌ Narx noto'g'ri. Faqat raqam kiriting:")
        return
    data = await state.get_data()
    async with async_session() as session:
        session.add(Group(name=data["name"], year=data["year"], monthly_price=price))
        await session.commit()
    await message.answer(
        f"✅ Guruh yaratildi:\n📁 <b>{data['name']}</b>\n"
        f"🗓 Yil: <b>{data['year']}</b>\n💰 Oylik: {price:,.0f} so'm",
        reply_markup=admin_menu()
    )
    await state.clear()


# ───────────── Guruhlarni tahlil qilish ─────────────

async def _render_groups_list(target: Message):
    async with async_session() as session:
        groups = (await session.scalars(
            select(Group).order_by(Group.year, Group.name)
        )).all()
    if not groups:
        await target.answer("❌ Hozircha guruh yo'q.", reply_markup=admin_menu())
        return
    await target.answer(
        "📊 <b>Guruhlar tahlili</b>\nTahlil qilish uchun guruhni tanlang:",
        reply_markup=group_analysis_kb(groups),
    )


@router.message(F.text == BTN_GROUP_ANALYSIS, F.from_user.id.in_(ADMINS))
async def group_analysis_start(message: Message, state: FSMContext):
    await state.clear()
    await _render_groups_list(message)


async def _group_stats(group_id: int):
    async with async_session() as session:
        g = await session.get(Group, group_id)
        if not g:
            return None

        count = await session.scalar(
            select(func.count(StudentGroup.id)).where(StudentGroup.group_id == group_id)
        ) or 0
        total_balance = await session.scalar(
            select(func.coalesce(func.sum(StudentGroup.balance), 0.0))
            .where(StudentGroup.group_id == group_id)
        ) or 0.0
        debtors = await session.scalar(
            select(func.count(StudentGroup.id))
            .where(StudentGroup.group_id == group_id, StudentGroup.balance < 0)
        ) or 0
        avg_score = await session.scalar(
            select(func.coalesce(func.avg(StudentGroup.average_score), 0.0))
            .where(StudentGroup.group_id == group_id)
        ) or 0.0
    return g, count, total_balance, debtors, avg_score


async def _show_group_card(target: Message, gid: int, edit: bool):
    stats = await _group_stats(gid)
    if not stats:
        await target.answer("❌ Guruh topilmadi.")
        return
    g, count, total_balance, debtors, avg_score = stats
    text = (
        f"📁 <b>{g.name}</b> [{g.year}]\n"
        "━━━━━━━━━━━━━━\n"
        f"👥 O'quvchilar: <b>{count}</b>\n"
        f"💰 Oylik narx: <b>{g.monthly_price:,.0f}</b> so'm\n"
        f"📉 Qarzdorlar: <b>{debtors}</b>\n"
        f"💸 Jami balans: <b>{total_balance:,.0f}</b> so'm\n"
        f"🏆 O'rtacha ball: <b>{avg_score:.1f}%</b>"
    )
    can_delete = count == 0
    if not can_delete:
        text += "\n\nℹ️ O'chirish uchun guruhda o'quvchi qolmasligi kerak."
    kb = group_actions_kb(gid, can_delete)
    if edit:
        try:
            await target.edit_text(text, reply_markup=kb)
            return
        except Exception:
            pass
    await target.answer(text, reply_markup=kb)


@router.callback_query(F.data.startswith("ganalyze:"), F.from_user.id.in_(ADMINS))
async def group_analyze(call: CallbackQuery):
    gid = int(call.data.split(":")[1])
    await _show_group_card(call.message, gid, edit=True)
    await call.answer()


@router.callback_query(F.data == "gback", F.from_user.id.in_(ADMINS))
async def group_back(call: CallbackQuery):
    async with async_session() as session:
        groups = (await session.scalars(
            select(Group).order_by(Group.year, Group.name)
        )).all()
    try:
        await call.message.edit_text(
            "📊 <b>Guruhlar tahlili</b>\nTahlil qilish uchun guruhni tanlang:",
            reply_markup=group_analysis_kb(groups),
        )
    except Exception:
        pass
    await call.answer()


# ── O'chirish ──

@router.callback_query(F.data.startswith("gdelete:"), F.from_user.id.in_(ADMINS))
async def group_delete_ask(call: CallbackQuery):
    gid = int(call.data.split(":")[1])
    async with async_session() as session:
        count = await session.scalar(
            select(func.count(StudentGroup.id)).where(StudentGroup.group_id == gid)
        ) or 0
        g = await session.get(Group, gid)
    if not g:
        await call.answer("❌ Guruh topilmadi.", show_alert=True)
        return
    if count > 0:
        await call.answer("❌ Guruhda o'quvchilar bor, o'chirib bo'lmaydi.", show_alert=True)
        return
    try:
        await call.message.edit_text(
            f"⚠️ <b>{g.name}</b> [{g.year}] guruhini o'chirasizmi?",
            reply_markup=group_delete_confirm_kb(gid),
        )
    except Exception:
        pass
    await call.answer()


@router.callback_query(F.data.startswith("gdelok:"), F.from_user.id.in_(ADMINS))
async def group_delete_ok(call: CallbackQuery):
    gid = int(call.data.split(":")[1])
    async with async_session() as session:
        count = await session.scalar(
            select(func.count(StudentGroup.id)).where(StudentGroup.group_id == gid)
        ) or 0
        if count > 0:
            await call.answer("❌ Guruhda o'quvchilar bor.", show_alert=True)
            return
        await session.execute(delete(Group).where(Group.id == gid))
        await session.commit()
    try:
        await call.message.edit_text("✅ Guruh o'chirildi.")
    except Exception:
        pass
    await _render_groups_list(call.message)
    await call.answer("O'chirildi")


@router.callback_query(F.data.startswith("gdelno:"), F.from_user.id.in_(ADMINS))
async def group_delete_no(call: CallbackQuery):
    gid = int(call.data.split(":")[1])
    await _show_group_card(call.message, gid, edit=True)
    await call.answer()


# ── Nomini o'zgartirish ──

@router.callback_query(F.data.startswith("grename:"), F.from_user.id.in_(ADMINS))
async def group_rename_ask(call: CallbackQuery, state: FSMContext):
    gid = int(call.data.split(":")[1])
    await state.update_data(group_id=gid)
    await state.set_state(GroupRenameFSM.name)
    await call.message.answer("✏️ Yangi guruh nomini kiriting:")
    await call.answer()


@router.message(GroupRenameFSM.name, F.from_user.id.in_(ADMINS))
async def group_rename_save(message: Message, state: FSMContext):
    new_name = message.text.strip()
    if not new_name:
        await message.answer("❌ Nom bo'sh bo'lmasin. Qayta kiriting:")
        return
    data = await state.get_data()
    async with async_session() as session:
        g = await session.get(Group, data["group_id"])
        if not g:
            await message.answer("❌ Guruh topilmadi.", reply_markup=admin_menu())
            await state.clear()
            return
        g.name = new_name
        await session.commit()
    await message.answer(f"✅ Guruh nomi o'zgartirildi: <b>{new_name}</b>",
                         reply_markup=admin_menu())
    await state.clear()
    await _render_groups_list(message)
