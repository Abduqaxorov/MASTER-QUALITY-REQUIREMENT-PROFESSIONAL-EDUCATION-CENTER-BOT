from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from sqlalchemy import select, update
from sqlalchemy.orm import selectinload

from config import ADMINS
from states.states import PaymentFSM, ConfirmFSM
from database.engine import async_session
from database.models import Student, PaymentRequest, StudentGroup, Group
from keyboards.inline import (
    students_select_kb, pay_now_kb, payment_decision_kb, student_groups_select_kb,
)
from keyboards.buttons import BTN_PAY
from utils.helpers import safe_delete, safe_edit_caption
from utils.cards import cards_text_db
from utils.linking import get_linked_students

router = Router()


@router.message(F.text == BTN_PAY)
async def pay_start(message: Message, state: FSMContext):
    await state.clear()
    students = await get_linked_students(message.from_user.id)
    if not students:
        await message.answer(
            "👤 Avval «📉 Oylik to'lov va Qarzni tekshirish» tugmasi orqali "
            "o'zingizni bog'lang."
        )
        return
    if len(students) == 1:
        sid = students[0].id
        async with async_session() as session:
            links = (await session.scalars(
                select(StudentGroup).options(selectinload(StudentGroup.group))
                .where(StudentGroup.student_id == sid)
            )).all()
        if not links:
            await message.answer("❌ Hech qanday guruhga a'zo emassiz.")
            return
        await state.update_data(pay_student_id=sid)
        if len(links) == 1:
            await state.update_data(pay_group_id=links[0].group_id)
            await _show(message, students[0], links[0])
        else:
            groups = [l.group for l in links]
            await message.answer(
                f"👤 <b>{students[0].name} {students[0].last_name}</b>\n"
                "Qaysi fan uchun to'lov qilasiz?",
                reply_markup=student_groups_select_kb(groups, "paygrp"))
        await state.set_state(PaymentFSM.select)
        return
    await message.answer("To'lov kim uchun?",
                         reply_markup=students_select_kb(students, "paypick"))
    await state.set_state(PaymentFSM.select)


@router.callback_query(PaymentFSM.select, F.data.startswith("paypick:"))
async def pay_pick(call: CallbackQuery, state: FSMContext):
    sid = int(call.data.split(":")[1])
    async with async_session() as session:
        links = (await session.scalars(
            select(StudentGroup).options(selectinload(StudentGroup.group))
            .where(StudentGroup.student_id == sid)
        )).all()
        s = await session.get(Student, sid)

    if not links:
        await call.answer("❌ Hech qanday guruhga a'zo emassiz.", show_alert=True)
        return

    await state.update_data(pay_student_id=sid)
    await safe_delete(call.message)

    if len(links) == 1:
        await state.update_data(pay_group_id=links[0].group_id)
        await _show(call.message, s, links[0])
    else:
        groups = [l.group for l in links]
        await call.message.answer(
            f"👤 <b>{s.name} {s.last_name}</b>\nQaysi fan uchun to'lov qilasiz?",
            reply_markup=student_groups_select_kb(groups, "paygrp")
        )
    await call.answer()


@router.callback_query(PaymentFSM.select, F.data.startswith("paygrp:"))
async def pay_grp_pick(call: CallbackQuery, state: FSMContext):
    gid = int(call.data.split(":")[1])
    data = await state.get_data()
    sid = data.get("pay_student_id")
    if not sid:
        await call.answer("❌ Sessiya tugadi. Qaytadan boshlang.", show_alert=True)
        await state.clear()
        return

    async with async_session() as session:
        link = await session.scalar(
            select(StudentGroup).options(selectinload(StudentGroup.group))
            .where(StudentGroup.student_id == sid, StudentGroup.group_id == gid)
        )
        s = await session.get(Student, sid)

    if not link:
        await call.answer("❌ Bog'liqlik topilmadi.", show_alert=True)
        return

    await state.update_data(pay_group_id=gid)
    await safe_delete(call.message)
    await _show(call.message, s, link)
    await call.answer()


async def _show(message: Message, s: Student, link: StudentGroup):
    debt = (f"\n⚠️ Qarz: <b>{abs(link.balance):,.0f} so'm</b>"
            if link.balance < 0 else "\n✅ Qarzingiz yo'q.")
    await message.answer(
        f"👤 <b>{s.name} {s.last_name}</b>\n📁 Fan: <b>{link.group.name}</b>{debt}",
        reply_markup=pay_now_kb(s.id))


@router.callback_query(PaymentFSM.select, F.data.startswith("paynow:"))
async def pay_now(call: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    if "pay_group_id" not in data:
        sid = int(call.data.split(":")[1])
        async with async_session() as session:
            links = (await session.scalars(
                select(StudentGroup).where(StudentGroup.student_id == sid)
            )).all()
            if len(links) == 1:
                await state.update_data(pay_group_id=links[0].group_id)

    try:
        await call.message.edit_reply_markup(reply_markup=None)
    except Exception:
        pass

    text = await cards_text_db()
    await call.message.answer(
        text + "\n💸 Yuqoridagi kartaga to'lang, so'ng <b>chek (rasm)</b> yuboring:")
    await state.set_state(PaymentFSM.check)
    await call.answer()


@router.message(PaymentFSM.check, F.photo)
async def pay_check(message: Message, state: FSMContext):
    data = await state.get_data()
    sid = data.get("pay_student_id")
    gid = data.get("pay_group_id")
    if not sid or not gid:
        await message.answer("❌ Sessiya tugadi. «💳 To'lov qilish» dan qayta boshlang.")
        await state.clear()
        return

    async with async_session() as session:
        s = await session.get(Student, sid)
        g = await session.get(Group, gid)
        link = await session.scalar(
            select(StudentGroup).where(
                StudentGroup.student_id == sid, StudentGroup.group_id == gid)
        )

        req = PaymentRequest(student_id=s.id, group_id=gid,
                             user_id=message.from_user.id, status="pending")
        session.add(req)
        await session.commit()
        req_id = req.id
        cap = (f"💳 <b>Yangi to'lov cheki</b>\n👤 {s.name} {s.last_name}\n"
               f"📁 Fan: <b>{g.name}</b>\n"
               f"💰 Fan balansi: {(link.balance if link else 0):,.0f} so'm\n"
               f"🆔 TG: <code>{message.from_user.id}</code>")

    kb = payment_decision_kb(req_id)
    sent_ok = False
    for admin_id in ADMINS:
        try:
            await message.bot.send_photo(admin_id, photo=message.photo[-1].file_id,
                                         caption=cap, reply_markup=kb)
            sent_ok = True
        except Exception:
            pass
    if sent_ok:
        await message.answer("✅ Chek adminlarga yuborildi. Tasdiqlashni kuting.")
    else:
        await message.answer("⚠️ Chek yuborilmadi (admin topilmadi).")
    await state.clear()


@router.message(PaymentFSM.check)
async def pay_invalid(message: Message):
    await message.answer("❌ Iltimos, chekni <b>rasm</b> qilib yuboring.")


@router.callback_query(F.data.startswith("confirm:"))
async def confirm(call: CallbackQuery, state: FSMContext):
    if call.from_user.id not in ADMINS:
        await call.answer("Ruxsat yo'q!", show_alert=True)
        return
    req_id = int(call.data.split(":")[1])
    async with async_session() as session:
        req = await session.get(PaymentRequest, req_id)
        if not req or req.status != "pending":
            await call.answer("⚠️ Bu to'lov allaqachon ko'rib chiqilgan.", show_alert=True)
            return
    await state.set_state(ConfirmFSM.amount)
    await state.update_data(req_id=req_id)
    await call.message.answer("To'lov summasini kiriting (balansga qo'shiladi):")
    await call.answer()


@router.message(ConfirmFSM.amount, F.from_user.id.in_(ADMINS))
async def confirm_amount(message: Message, state: FSMContext):
    try:
        amount = float(message.text.replace(" ", "").replace(",", ""))
    except (ValueError, AttributeError):
        await message.answer("❌ Faqat raqam kiriting:")
        return
    data = await state.get_data()
    async with async_session() as session:
        req = await session.get(PaymentRequest, data["req_id"])
        if not req or req.status != "pending":
            await message.answer("⚠️ Bu to'lov allaqachon tasdiqlangan.")
            await state.clear()
            return

        await session.execute(
            update(StudentGroup)
            .where(StudentGroup.student_id == req.student_id,
                   StudentGroup.group_id == req.group_id)
            .values(balance=StudentGroup.balance + amount)
        )
        req.status = "confirmed"
        await session.commit()

        student = await session.get(Student, req.student_id)
        group = await session.get(Group, req.group_id)
        link = await session.scalar(
            select(StudentGroup).where(
                StudentGroup.student_id == req.student_id,
                StudentGroup.group_id == req.group_id)
        )

        nb = link.balance if link else 0.0
        fn = f"{student.name} {student.last_name}"
        gn = group.name if group else "—"
        uid = req.user_id

    status_line = ("⚠️ Sizda hali qarz mavjud." if nb < 0 else "✅ Qarzingiz yo'q. Rahmat! 🎉")
    try:
        await message.bot.send_message(
            uid,
            f"✅ <b>To'lovingiz tasdiqlandi:</b> {amount:,.0f} so'm\n"
            f"👤 {fn}\n"
            f"📁 Fan: <b>{gn}</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"💰 Yangi balans: {nb:,.0f} so'm\n{status_line}"
        )
    except Exception:
        pass
    await message.answer(f"✅ Tasdiqlandi. {fn} ({gn}) — balans: {nb:,.0f} so'm")
    await state.clear()


@router.callback_query(F.data.startswith("reject:"))
async def reject(call: CallbackQuery):
    if call.from_user.id not in ADMINS:
        await call.answer("Ruxsat yo'q!", show_alert=True)
        return
    req_id = int(call.data.split(":")[1])
    async with async_session() as session:
        req = await session.get(PaymentRequest, req_id)
        if not req or req.status != "pending":
            await call.answer("⚠️ Allaqachon ko'rib chiqilgan.", show_alert=True)
            return
        req.status = "rejected"
        await session.commit()
        uid = req.user_id
    try:
        await call.bot.send_message(uid, "❌ To'lovingiz rad etildi. Admin bilan bog'laning.")
    except Exception:
        pass
    await safe_edit_caption(call, "\n\n❌ <b>RAD ETILDI</b>")
    await call.answer("Rad etildi")
