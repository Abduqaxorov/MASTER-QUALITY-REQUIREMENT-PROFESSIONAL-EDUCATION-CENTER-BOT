from aiogram import Router, F
from aiogram.types import Message
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from database.engine import async_session
from database.models import StudentLink, StudentGroup, TeacherSchedule
from keyboards.buttons import BTN_MY_SCHEDULE
from keyboards.reply import user_menu

router = Router()

DAY_NAMES_UZ = {
    "Monday": "Dushanba", "Tuesday": "Seshanba", "Wednesday": "Chorshanba",
    "Thursday": "Payshanba", "Friday": "Juma", "Saturday": "Shanba", "Sunday": "Yakshanba",
}

DAY_ORDER = {
    "Monday": 1, "Tuesday": 2, "Wednesday": 3, "Thursday": 4,
    "Friday": 5, "Saturday": 6, "Sunday": 7,
}


@router.message(F.text == BTN_MY_SCHEDULE)
async def my_schedule(message: Message):
    tg_id = message.from_user.id

    async with async_session() as session:
        links = (await session.scalars(
            select(StudentLink).where(StudentLink.tg_id == tg_id)
        )).all()

    if not links:
        await message.answer(
            "⚠️ Avval «📉 Oylik to'lov va Qarzni tekshirish» orqali o'zingizni bog'lang.",
            reply_markup=user_menu()
        )
        return

    student_ids = [l.student_id for l in links]

    # O'quvchilarning barcha guruhlarini StudentGroup orqali olamiz
    async with async_session() as session:
        group_ids = set((await session.scalars(
            select(StudentGroup.group_id).where(StudentGroup.student_id.in_(student_ids))
        )).all())

    if not group_ids:
        await message.answer("📅 Hozircha dars vaqti belgilanmagan.",
                             reply_markup=user_menu())
        return

    async with async_session() as session:
        schedules = (await session.scalars(
            select(TeacherSchedule)
            .options(selectinload(TeacherSchedule.group))
            .where(TeacherSchedule.group_id.in_(group_ids))
        )).all()

    if not schedules:
        await message.answer("📅 Hozircha dars vaqti belgilanmagan.",
                             reply_markup=user_menu())
        return

    schedules = sorted(
        schedules,
        key=lambda s: (DAY_ORDER.get(s.day_of_week, 99), s.start_time or "")
    )

    text = "📅 <b>Sizning dars vaqtingiz:</b>\n━━━━━━━━━━━━━━\n"
    current_day = None
    for s in schedules:
        day_uz = DAY_NAMES_UZ.get(s.day_of_week, s.day_of_week)
        if day_uz != current_day:
            current_day = day_uz
            text += f"\n📆 <b>{day_uz}</b>\n"
        gname = s.group.name if s.group else "—"
        text += f"  ⏰ {s.start_time} - {s.end_time} | {gname}\n"

    await message.answer(text, reply_markup=user_menu())
