"""User → Admin murojaati (faqat navbatga tushadi, darhol yuborilmaydi)."""
from aiogram import Router, F
from aiogram.types import (
    Message, ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
)
from aiogram.fsm.context import FSMContext
from sqlalchemy import select
from config import ADMINS
from states.states import TicketFSM, TeacherTicketFSM
from keyboards.reply import user_menu, admin_menu, teacher_menu
from keyboards.buttons import BTN_CONTACT_ADMIN
from utils.tickets import get_next_ticket_number, get_user_queue_position
from database.engine import async_session
from database.models import ContactTicket, Teacher

router = Router()

BTN_SKIP = "⏭️ O'tkazib yuborish"
BTN_CANCEL = "❌ Bekor qilish"


def _extra_kb() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text=BTN_SKIP)], [KeyboardButton(text=BTN_CANCEL)]],
        resize_keyboard=True,
    )


async def _is_teacher(tg_id: int) -> bool:
    async with async_session() as session:
        t = await session.scalar(
            select(Teacher).where(Teacher.tg_id == tg_id, Teacher.is_active == True)
        )
        return t is not None


@router.message(F.text == BTN_CONTACT_ADMIN)
async def contact_start(message: Message, state: FSMContext):
    await state.clear()

    # Admin bo'lsa — o'z panelida qoladi
    if message.from_user.id in ADMINS:
        await message.answer("ℹ️ Siz adminsiz 🙂", reply_markup=admin_menu())
        return

    # Ustoz bo'lsa (eski klaviaturadan bosgan bo'lishi mumkin) —
    # USTOZ oqimiga yo'naltiramiz, user paneliga chiqarmaymiz!
    if await _is_teacher(message.from_user.id):
        pos = await get_user_queue_position(message.from_user.id, "teacher")
        if pos:
            await message.answer(
                "⏳ <b>Siz allaqachon murojaat yuborgansiz!</b>\n"
                "Admin ko'rib chiqqandan keyin javob beradi.",
                reply_markup=teacher_menu()
            )
            return
        await message.answer(
            "✍️ Adminga yubormoqchi bo'lgan xabaringizni yozing:",
            reply_markup=ReplyKeyboardRemove()
        )
        await state.set_state(TeacherTicketFSM.text)
        return

    pos = await get_user_queue_position(message.from_user.id, "user")
    if pos:
        await message.answer(
            f"⏳ <b>Siz allaqachon murojaat yuborgansiz!</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"📋 Sizning tartib raqamingiz: <b>#{pos}</b>\n"
            f"Admin ko'rib chiqqandan keyin sizga javob beradi.\n"
            f"Iltimos, kuting."
        )
        return

    await message.answer(
        "✍️ Adminga yubormoqchi bo'lgan xabaringizni yozing:",
        reply_markup=ReplyKeyboardRemove()
    )
    await state.set_state(TicketFSM.text)


@router.message(TicketFSM.text, F.text)
async def contact_text(message: Message, state: FSMContext):
    await state.update_data(text=message.text.strip())
    await message.answer(
        "📎 Xabaringizga rasm/fayl qo'shasizmi?\n"
        "Qo'shmoqchi bo'lsangiz yuboring, aks holda «O'tkazib yuborish».",
        reply_markup=_extra_kb()
    )
    await state.set_state(TicketFSM.ask_extra)


@router.message(TicketFSM.ask_extra, F.text == BTN_SKIP)
async def contact_skip(message: Message, state: FSMContext):
    data = await state.get_data()
    await _create_ticket(message, text=data.get("text", ""))
    await state.clear()


@router.message(TicketFSM.ask_extra, F.text == BTN_CANCEL)
async def contact_cancel(message: Message, state: FSMContext):
    await message.answer("🚫 Bekor qilindi.", reply_markup=user_menu())
    await state.clear()


@router.message(TicketFSM.ask_extra, F.photo | F.document)
async def contact_extra(message: Message, state: FSMContext):
    data = await state.get_data()
    await _create_ticket(message, text=data.get("text", ""))
    await state.clear()


@router.message(TicketFSM.ask_extra)
async def contact_extra_invalid(message: Message):
    await message.answer(
        "❌ Iltimos, rasm/fayl yuboring yoki «O'tkazib yuborish» tugmasini bosing.",
        reply_markup=_extra_kb()
    )


async def _create_ticket(message: Message, text: str):
    """Ticket yaratadi — FAQAT navbatga qo'yiladi (admin darhol xabar olmaydi)."""
    u = message.from_user
    async with async_session() as session:
        ticket_number = await get_next_ticket_number()
        ticket = ContactTicket(
            ticket_number=ticket_number,
            from_user_id=u.id,
            from_role="user",
            from_name=u.full_name,
            text=text,
            status="pending",
        )
        session.add(ticket)
        await session.commit()

    await message.answer(
        f"✅ Murojaatingiz navbatga qo'shildi.\n"
        f"📋 <b>Sizning tartib raqamingiz: #{ticket_number}</b>\n"
        f"Admin navbat bo'yicha ko'rib chiqadi.",
        reply_markup=user_menu()
    )
