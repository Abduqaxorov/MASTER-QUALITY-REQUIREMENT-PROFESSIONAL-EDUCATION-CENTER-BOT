"""User → Anonim feedback (bir nechta ustoz bo'lsa — tanlash chiqadi)."""
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, ReplyKeyboardRemove
from aiogram.fsm.context import FSMContext
from sqlalchemy import select
from states.states import AnonFeedbackFSM
from database.engine import async_session
from database.models import (
    Teacher, TeacherGroup, StudentLink, StudentGroup, AnonymousFeedback,
)
from keyboards.reply import user_menu
from keyboards.inline import teachers_kb
from keyboards.buttons import BTN_ANON_FEEDBACK_USER

router = Router()


async def _get_my_teachers(tg_id: int) -> list[Teacher]:
    """Userning barcha fanlaridagi barcha faol ustozlarini qaytaradi (takrorsiz)."""
    async with async_session() as session:
        links = (await session.scalars(
            select(StudentLink).where(StudentLink.tg_id == tg_id)
        )).all()
        if not links:
            return []
        student_ids = [l.student_id for l in links]

        gids = (await session.scalars(
            select(StudentGroup.group_id).where(StudentGroup.student_id.in_(student_ids))
        )).all()
        if not gids:
            return []

        teacher_ids = (await session.scalars(
            select(TeacherGroup.teacher_id).where(TeacherGroup.group_id.in_(gids))
        )).all()
        if not teacher_ids:
            return []

        teachers = (await session.scalars(
            select(Teacher).where(
                Teacher.id.in_(set(teacher_ids)), Teacher.is_active == True)
            .order_by(Teacher.full_name)
        )).all()
        return list(teachers)


async def _ask_feedback(target, state: FSMContext, teacher: Teacher, edit: bool = False):
    # Ustozning bitta guruhini feedback yozuvi uchun olamiz (ixtiyoriy maydon)
    async with async_session() as session:
        tg = await session.scalar(
            select(TeacherGroup).where(TeacherGroup.teacher_id == teacher.id)
        )
    await state.update_data(teacher_id=teacher.id,
                            group_id=tg.group_id if tg else None,
                            teacher_name=teacher.full_name)
    text = (
        f"🕵️ <b>Anonim feedback</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"Bu xabar to'liq anonim — kim yozgani ko'rinmaydi.\n"
        f"👨‍🏫 Ustoz: <b>{teacher.full_name}</b>\n"
        f"\n✍️ Fikr-mulohazangizni yozing:"
    )
    if edit:
        try:
            await target.edit_text(text)
        except Exception:
            await target.answer(text)
    else:
        await target.answer(text, reply_markup=ReplyKeyboardRemove())
    await state.set_state(AnonFeedbackFSM.text)


@router.message(F.text == BTN_ANON_FEEDBACK_USER)
async def feedback_start(message: Message, state: FSMContext):
    await state.clear()
    async with async_session() as session:
        links = (await session.scalars(
            select(StudentLink).where(StudentLink.tg_id == message.from_user.id)
        )).all()

    if not links:
        await message.answer(
            "⚠️ Avval «📉 Oylik to'lov va Qarzni tekshirish» orqali o'zingizni bog'lang.",
            reply_markup=user_menu()
        )
        return

    teachers = await _get_my_teachers(message.from_user.id)
    if not teachers:
        await message.answer(
            "⚠️ Sizning guruhlaringiz uchun o'qituvchi biriktirilmagan.",
            reply_markup=user_menu()
        )
        return

    if len(teachers) == 1:
        await _ask_feedback(message, state, teachers[0])
        return

    await message.answer(
        "👨‍🏫 Sizda bir nechta ustoz bor.\nQaysi ustoz haqida feedback yozasiz?",
        reply_markup=teachers_kb(teachers, prefix="fbpick")
    )


@router.callback_query(F.data.startswith("fbpick:"))
async def feedback_pick(call: CallbackQuery, state: FSMContext):
    teacher_id = int(call.data.split(":")[1])
    async with async_session() as session:
        t = await session.get(Teacher, teacher_id)
    if not t or not t.is_active:
        await call.answer("❌ Ustoz topilmadi.", show_alert=True)
        return
    await _ask_feedback(call.message, state, t, edit=True)
    await call.answer()


@router.message(AnonFeedbackFSM.text, F.text)
async def feedback_text(message: Message, state: FSMContext):
    data = await state.get_data()
    if not data.get("teacher_id"):
        await message.answer("❌ Sessiya tugadi. Qaytadan boshlang.",
                             reply_markup=user_menu())
        await state.clear()
        return

    async with async_session() as session:
        session.add(AnonymousFeedback(
            group_id=data.get("group_id"),
            teacher_id=data["teacher_id"],
            from_user_id=message.from_user.id,
            text=message.text.strip(),
        ))
        await session.commit()

    await message.answer(
        f"✅ <b>Feedbackingiz qabul qilindi!</b>\n"
        f"👨‍🏫 Ustoz: {data['teacher_name']}\n"
        f"🔒 Xabaringiz to'liq anonim saqlandi.",
        reply_markup=user_menu()
    )
    await state.clear()


@router.message(AnonFeedbackFSM.text)
async def feedback_invalid(message: Message):
    await message.answer("❌ Iltimos, fikringizni matn ko'rinishida yozing.")
