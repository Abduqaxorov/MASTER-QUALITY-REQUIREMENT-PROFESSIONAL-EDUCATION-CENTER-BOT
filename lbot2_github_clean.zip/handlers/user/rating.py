from aiogram import Router, F
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from sqlalchemy import select, func
from sqlalchemy.orm import selectinload

from database.engine import async_session
from database.models import Student, Attendance, StudentGroup
from keyboards.buttons import BTN_RATING, BTN_HISTORY
from utils.linking import get_linked_students

router = Router()

_NOT_LINKED = ("👤 Avval «📉 Oylik to'lov va Qarzni tekshirish» tugmasi orqali "
               "o'zingizni bog'lang.")


@router.message(F.text == BTN_RATING)
async def rating_start(message: Message, state: FSMContext):
    await state.clear()
    students = await get_linked_students(message.from_user.id)
    if not students:
        await message.answer(_NOT_LINKED)
        return
    for s in students:
        await _rating(message, s.id)


async def _rating(message: Message, sid: int):
    async with async_session() as session:
        # O'quvchining guruhlardagi bog'liqliklarini olish
        links = (await session.scalars(
            select(StudentGroup)
            .options(selectinload(StudentGroup.group), selectinload(StudentGroup.student))
            .where(StudentGroup.student_id == sid)
        )).all()

        if not links:
            return

        for link in links:
            g = link.group
            s = link.student
            
            # Guruhdagi barcha o'quvchilarni olish va reytingni hisoblash
            all_in_group = (await session.scalars(
                select(StudentGroup)
                .where(StudentGroup.group_id == g.id)
                .order_by(StudentGroup.average_score.desc())
            )).all()
            
            # O'rinni aniqlash
            rank = 1
            for i, other in enumerate(all_in_group):
                if other.student_id == sid:
                    rank = i + 1
                    break
            
            avg_score = link.average_score
            if avg_score >= 86:
                comment = "🚀 <b>Zo'r natija! Siz guruhda yetakchisiz.</b>"
            elif 70 <= avg_score <= 85:
                comment = "✅ <b>Yaxshi natija! To'xtab qolmang.</b>"
            elif avg_score < 60:
                comment = "⚠️ <b>Natijalaringiz past. Ko'proq o'qishingiz kerak!</b>"
            else:
                comment = "📊 <b>Harakatda davom eting!</b>"

            absents = await session.scalar(
                select(func.count(Attendance.id)).where(
                    Attendance.student_id == sid, 
                    Attendance.group_id == g.id,
                    Attendance.present == 0
                )
            ) or 0
            
            await message.answer(
                f"🏆 <b>{s.name} {s.last_name}</b>\n"
                f"📁 Fan: <b>{g.name}</b>\n"
                f"━━━━━━━━━━━━━━\n"
                f"📊 Guruhdagi o'rningiz: <b>{rank}-o'rin</b> (jami {len(all_in_group)} ta)\n"
                f"📈 O'rtacha natija: <b>{avg_score:.1f}%</b>\n"
                f"🚫 Kelmagan kunlari: <b>{absents}</b> ta\n\n"
                f"{comment}"
            )


@router.message(F.text == BTN_HISTORY)
async def history_start(message: Message, state: FSMContext):
    await state.clear()
    students = await get_linked_students(message.from_user.id)
    if not students:
        await message.answer(_NOT_LINKED)
        return
    for s in students:
        await _history(message, s.id)


async def _history(message: Message, sid: int):
    async with async_session() as session:
        s = await session.scalar(select(Student).options(
            selectinload(Student.test_results)).where(Student.id == sid))
    if not s or not s.test_results:
        await message.answer("📅 Test natijalari yo'q.")
        return
    res = sorted(s.test_results, key=lambda r: r.created_at, reverse=True)
    lines = [f"📅 <b>Testlar tarixi</b> — {s.name} {s.last_name}\n"]
    for r in res:
        lines.append(f"🗓 {r.created_at.strftime('%Y-%m-%d')} — {r.score:.0f}%")
    await message.answer("\n".join(lines))
