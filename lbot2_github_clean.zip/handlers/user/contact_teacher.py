"""User → O'qituvchi bilan bog'lanish (bir nechta ustoz bo'lsa — tanlash chiqadi)."""
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, ReplyKeyboardRemove
from aiogram.fsm.context import FSMContext
from sqlalchemy import select
from states.states import ContactTeacherFSM
from database.engine import async_session
from database.models import (
    Teacher, TeacherGroup, StudentLink, StudentGroup, ContactTicket,
)
from keyboards.reply import user_menu
from keyboards.inline import teachers_kb
from keyboards.buttons import BTN_CONTACT_TEACHER
from utils.tickets import get_next_ticket_number

router = Router()

# Ustoz reply qilib javob berishi uchun teg (teacher/reply.py shuni qidiradi)
TAG_STUDENT = "🆔 O'QUVCHI:"


async def _get_my_teachers(tg_id: int) -> list[Teacher]:
    """Userning barcha fanlaridagi barcha faol ustozlarini qaytaradi (takrorsiz)."""
    async with async_session() as session:
        links = (await session.scalars(
            select(StudentLink).where(StudentLink.tg_id == tg_id)
        )).all()
        if not links:
            return []
        student_ids = [l.student_id for l in links]

        gids = (await session.scalars(
            select(StudentGroup.group_id).where(StudentGroup.student_id.in_(student_ids))
        )).all()
        if not gids:
            return []

        teacher_ids = (await session.scalars(
            select(TeacherGroup.teacher_id).where(TeacherGroup.group_id.in_(gids))
        )).all()
        if not teacher_ids:
            return []

        teachers = (await session.scalars(
            select(Teacher).where(
                Teacher.id.in_(set(teacher_ids)), Teacher.is_active == True)
            .order_by(Teacher.full_name)
        )).all()
        return list(teachers)


@router.message(F.text == BTN_CONTACT_TEACHER)
async def contact_teacher_start(message: Message, state: FSMContext):
    await state.clear()
    async with async_session() as session:
        links = (await session.scalars(
            select(StudentLink).where(StudentLink.tg_id == message.from_user.id)
        )).all()

    if not links:
        await message.answer(
            "⚠️ Avval «📉 Oylik to'lov va Qarzni tekshirish» orqali o'zingizni bog'lang."
        )
        return

    teachers = await _get_my_teachers(message.from_user.id)
    if not teachers:
        await message.answer(
            "⚠️ Sizning guruhlaringiz uchun o'qituvchi biriktirilmagan."
        )
        return

    if len(teachers) == 1:
        t = teachers[0]
        await state.update_data(teacher_id=t.id, teacher_tg_id=t.tg_id,
                                teacher_name=t.full_name)
        await message.answer(
            f"👨‍🏫 <b>{t.full_name}</b> bilan bog'lanmoqchisiz.\n"
            f"✍️ Xabaringizni yozing:",
            reply_markup=ReplyKeyboardRemove()
        )
        await state.set_state(ContactTeacherFSM.text)
        return

    # Bir nechta ustoz — tanlash
    await message.answer(
        "👨‍🏫 Sizda bir nechta ustoz bor.\nQaysi ustozga yozmoqchisiz?",
        reply_markup=teachers_kb(teachers, prefix="ctch")
    )


@router.callback_query(F.data.startswith("ctch:"))
async def contact_teacher_pick(call: CallbackQuery, state: FSMContext):
    teacher_id = int(call.data.split(":")[1])
    async with async_session() as session:
        t = await session.get(Teacher, teacher_id)
    if not t or not t.is_active:
        await call.answer("❌ Ustoz topilmadi.", show_alert=True)
        return
    await state.update_data(teacher_id=t.id, teacher_tg_id=t.tg_id,
                            teacher_name=t.full_name)
    try:
        await call.message.edit_text(
            f"👨‍🏫 <b>{t.full_name}</b> bilan bog'lanmoqchisiz.\n"
            f"✍️ Xabaringizni yozing:"
        )
    except Exception:
        await call.message.answer(
            f"👨‍🏫 <b>{t.full_name}</b> ga xabaringizni yozing:")
    await state.set_state(ContactTeacherFSM.text)
    await call.answer()


@router.message(ContactTeacherFSM.text, F.text)
async def contact_teacher_text(message: Message, state: FSMContext):
    data = await state.get_data()
    teacher_tg_id = data.get("teacher_tg_id")
    teacher_name = data.get("teacher_name")
    u = message.from_user

    if not teacher_tg_id:
        await message.answer("❌ Sessiya tugadi. Qaytadan boshlang.",
                             reply_markup=user_menu())
        await state.clear()
        return

    async with async_session() as session:
        ticket_number = await get_next_ticket_number()
        # status="direct" — ADMIN NAVBATIGA TUSHMAYDI
        ticket = ContactTicket(
            ticket_number=ticket_number,
            from_user_id=u.id,
            from_role="user",
            from_name=u.full_name,
            target_user_id=teacher_tg_id,
            target_role="teacher",
            target_name=teacher_name,
            text=message.text.strip(),
            status="direct",
        )
        session.add(ticket)
        await session.commit()

    try:
        await message.bot.send_message(
            teacher_tg_id,
            f"📨 <b>Yangi xabar (#{ticket_number})</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"👨‍🎓 O'quvchi/ota-ona: {u.full_name}\n"
            f"{TAG_STUDENT} <code>{u.id}</code>\n"
            f"━━━━━━━━━━━━━━\n"
            f"💬 {message.text.strip()}\n"
            f"\n<i>Javob berish uchun shu xabarga reply qiling.</i>"
        )
    except Exception:
        await message.answer(
            "⚠️ Ustozga hozircha yuborib bo'lmadi.\n"
            "Sabab: ustoz botni hali ishga tushirmagan bo'lishi mumkin.\n"
            "Iltimos, keyinroq urinib ko'ring yoki admin bilan bog'laning.",
            reply_markup=user_menu()
        )
        await state.clear()
        return

    await message.answer(
        f"✅ Xabaringiz <b>{teacher_name}</b> ga yuborildi.\n"
        f"📋 Murojaat raqami: <b>#{ticket_number}</b>",
        reply_markup=user_menu()
    )
    await state.clear()
