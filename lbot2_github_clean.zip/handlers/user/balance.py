import re

from aiogram import Router, F
from aiogram.types import (
    Message, CallbackQuery, ReplyKeyboardMarkup, KeyboardButton
)
from aiogram.fsm.context import FSMContext
from sqlalchemy import select, or_
from sqlalchemy.orm import selectinload
from config import ADMINS
from states.states import LinkFSM
from database.engine import async_session
from database.models import Student, LinkRequest, StudentGroup
from keyboards.reply import user_menu
from keyboards.inline import students_select_kb, link_decision_kb
from keyboards.buttons import BTN_CHECK_BALANCE
from utils.linking import get_linked_students, link_student
from utils.tickets import get_next_ticket_number

router = Router()

BTN_SEND_PHONE = "📞 Raqamni yuborish"
BTN_CANCEL_LINK = "❌ Bekor qilish"


def _phone_kb() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=BTN_SEND_PHONE, request_contact=True)],
            [KeyboardButton(text=BTN_CANCEL_LINK)],
        ],
        resize_keyboard=True,
    )


def _normalize_phone(phone: str) -> str:
    """Raqamdan faqat oxirgi 9 ta raqamni oladi (O'zbekiston formati).
    '+998 90 123-45-67', '901234567', '998901234567' — hammasi bir xil bo'ladi."""
    digits = re.sub(r"\D", "", phone or "")
    return digits[-9:] if len(digits) >= 9 else digits


def _phones_match(phone1: str, phone2: str) -> bool:
    p1, p2 = _normalize_phone(phone1), _normalize_phone(phone2)
    return bool(p1) and len(p1) == 9 and p1 == p2


@router.message(F.text == BTN_CHECK_BALANCE)
async def check_start(message: Message, state: FSMContext):
    await state.clear()
    linked = await get_linked_students(message.from_user.id)
    if linked:
        for s in linked:
            await _show(message, s)
        return
    await message.answer(
        "👤 Avval o'zingizni (yoki farzandingizni) tanlang.\n"
        "Ism yoki familiyani kiriting:"
    )
    await state.set_state(LinkFSM.search)


async def _show(message: Message, s: Student):
    async with async_session() as session:
        links = (await session.scalars(
            select(StudentGroup)
            .options(selectinload(StudentGroup.group))
            .where(StudentGroup.student_id == s.id)
        )).all()

    if not links:
        await message.answer(
            f"👤 <b>{s.name} {s.last_name}</b>\n"
            "❌ Hozircha hech qanday guruhga a'zo emassiz.")
        return

    text = (f"👤 <b>{s.name} {s.last_name}</b>\n"
            f"📊 <b>Foydalanuvchi balansi:</b>\n━━━━━━━━━━━━━━\n")
    for link in links:
        g = link.group
        if link.balance < 0:
            status = f"⚠️ Qarz: <b>{abs(link.balance):,.0f} so'm</b>"
        else:
            status = "✅ Qarzingiz yo'q."
        text += f"📁 {g.name} [{g.year}]:\n   {status}\n\n"

    text += "━━━━━━━━━━━━━━\nIltimos, to'lovni o'z vaqtida amalga oshiring. 💳"
    await message.answer(text)


@router.message(LinkFSM.search)
async def link_search(message: Message, state: FSMContext):
    q = message.text.strip()
    async with async_session() as session:
        students = (await session.scalars(
            select(Student)
            .options(selectinload(Student.group_links).selectinload(StudentGroup.group))
            .where(or_(
                Student.name.ilike(f"%{q}%"),
                Student.last_name.ilike(f"%{q}%")
            ))
            .limit(50)
        )).all()
    if not students:
        await message.answer("❌ Topilmadi. Qayta kiriting:")
        return
    await message.answer(
        f"🔍 {len(students)} ta topildi. O'zingizni tanlang:",
        reply_markup=students_select_kb(students, "linkpick"),
    )


@router.callback_query(LinkFSM.search, F.data.startswith("linkpick:"))
async def link_pick(call: CallbackQuery, state: FSMContext):
    sid = int(call.data.split(":")[1])
    async with async_session() as session:
        s = await session.get(Student, sid)
    if not s:
        await call.answer("Topilmadi.", show_alert=True)
        return
    await state.update_data(student_id=sid, student_name=f"{s.name} {s.last_name}")
    try:
        await call.message.edit_reply_markup(reply_markup=None)
    except Exception:
        pass
    await call.message.answer(
        f"✅ Tanlandi: <b>{s.name} {s.last_name}</b>\n"
        "📞 Endi telefon raqamingizni yuboring (tasdiqlash uchun).\n"
        "Pastdagi «📞 Raqamni yuborish» tugmasini bosing:",
        reply_markup=_phone_kb(),
    )
    await state.set_state(LinkFSM.phone)
    await call.answer()


@router.message(LinkFSM.phone, F.text == BTN_CANCEL_LINK)
async def link_cancel(message: Message, state: FSMContext):
    await message.answer("🚫 Bekor qilindi.", reply_markup=user_menu())
    await state.clear()


@router.message(LinkFSM.phone, F.contact)
async def link_phone(message: Message, state: FSMContext):
    data = await state.get_data()
    sid = data.get("student_id")
    sname = data.get("student_name", "—")
    phone = message.contact.phone_number
    u = message.from_user
    if not sid:
        await message.answer("❌ Sessiya tugadi. Qaytadan boshlang.", reply_markup=user_menu())
        await state.clear()
        return

    # XAVFSIZLIK: faqat o'zining kontaktini qabul qilamiz
    # (Telegram request_contact orqali kelgan raqam haqiqiy va soxtalab bo'lmaydi,
    # lekin user boshqa odamning kontaktini ham yuborishi mumkin — shuni tekshiramiz)
    if message.contact.user_id != u.id:
        await message.answer(
            "❌ Iltimos, «📞 Raqamni yuborish» tugmasi orqali <b>o'zingizning</b> "
            "raqamingizni yuboring.",
            reply_markup=_phone_kb(),
        )
        return

    async with async_session() as session:
        student = await session.get(Student, sid)

    # ═══════════ AVTOMATIK TEKSHIRUV ═══════════
    if student and student.tel and _phones_match(phone, student.tel):
        # Raqam bazadagi bilan mos — DARHOL avtomatik bog'laymiz
        await link_student(u.id, sid)

        ticket_number = await get_next_ticket_number()
        async with async_session() as session:
            session.add(LinkRequest(
                tg_id=u.id, student_id=sid,
                full_name=u.full_name, username=u.username,
                phone=phone, status="approved",
                ticket_number=ticket_number,
            ))
            await session.commit()

        await message.answer(
            f"✅ <b>Muvaffaqiyatli bog'landingiz!</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"🎓 Siz <b>{sname}</b> ga bog'landingiz.\n"
            f"📞 Raqamingiz bazadagi ma'lumot bilan mos keldi — "
            f"admin tasdig'i talab qilinmadi.\n"
            f"\nEndi menyudagi barcha tugmalar siz uchun ishlaydi. 👇",
            reply_markup=user_menu()
        )

        # Adminlarga faqat ma'lumot uchun (tugmasiz, tasdiqlash shart emas)
        uname = f"@{u.username}" if u.username else "—"
        info = (
            f"ℹ️ <b>Avtomatik bog'lanish #{ticket_number}</b>\n"
            f"━━━━━━━━━━━━━━\n"
            f"👤 {u.full_name} ({uname})\n"
            f"📞 <code>{phone}</code>\n"
            f"🎓 → <b>{sname}</b>\n"
            f"✅ Raqam mos keldi, avtomatik tasdiqlandi."
        )
        for admin_id in ADMINS:
            try:
                await message.bot.send_message(admin_id, info)
            except Exception:
                pass

        await state.clear()
        return

    # ═══════════ MOS KELMADI — ESKI YO'L (admin tasdig'i) ═══════════
    ticket_number = await get_next_ticket_number()

    async with async_session() as session:
        req = LinkRequest(
            tg_id=u.id, student_id=sid,
            full_name=u.full_name, username=u.username,
            phone=phone, status="pending",
            ticket_number=ticket_number,
        )
        session.add(req)
        await session.commit()
        req_id = req.id

    uname = f"@{u.username}" if u.username else "—"
    reason = ("📵 Bazada raqam kiritilmagan"
              if not (student and student.tel)
              else f"⚠️ Raqam mos kelmadi (bazada: <code>{student.tel}</code>)")
    text = (
        f"🔗 <b>Yangi bog'lanish so'rovi #{ticket_number}</b>\n"
        f"━━━━━━━━━━━━━━\n"
        f"👤 So'rovchi: {u.full_name} ({uname})\n"
        f"📞 Raqam: <code>{phone}</code>\n"
        f"🆔 USER: <code>{u.id}</code>\n"
        f"🎓 Bog'lanmoqchi: <b>{sname}</b>\n"
        f"{reason}\n"
        f"━━━━━━━━━━━━━━\n"
        f"Tasdiqlang, rad eting yoki <i>reply qilib xabar yozing</i>:"
    )
    sent_ok = False
    for admin_id in ADMINS:
        try:
            await message.bot.send_message(admin_id, text, reply_markup=link_decision_kb(req_id))
            sent_ok = True
        except Exception:
            pass

    if sent_ok:
        await message.answer(
            f"📞 Raqamingiz bazadagi ma'lumot bilan mos kelmadi.\n"
            f"So'rovingiz adminga yuborildi.\n"
            f"📋 <b>Sizning tartib raqamingiz: #{ticket_number}</b>\n"
            f"Admin tekshirib, tasdiqlaydi. ⏳",
            reply_markup=user_menu()
        )
    else:
        await message.answer("⚠️ So'rov yuborilmadi.", reply_markup=user_menu())
    await state.clear()


@router.message(LinkFSM.phone)
async def link_phone_invalid(message: Message):
    await message.answer(
        "❌ Iltimos, «📞 Raqamni yuborish» tugmasini bosing (qo'lda yozmang).",
        reply_markup=_phone_kb(),
    )
