"""O'qituvchi paneli: mening guruhlarim (group_id + o'quvchilar soni)."""
from aiogram import Router, F
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from sqlalchemy import select, func
from database.engine import async_session
from database.models import Teacher, TeacherGroup, Group, StudentGroup
from keyboards.reply import teacher_menu
from keyboards.buttons import BTN_T_STUDENTS

router = Router()


@router.message(F.text == BTN_T_STUDENTS)
async def my_groups(message: Message, state: FSMContext):
    await state.clear()
    async with async_session() as session:
        teacher = await session.scalar(
            select(Teacher).where(
                Teacher.tg_id == message.from_user.id, Teacher.is_active == True)
        )
        if not teacher:
            await message.answer("⚠️ Bu bo'lim faqat o'qituvchilar uchun.")
            return

        rows = (await session.execute(
            select(Group, func.count(StudentGroup.id))
            .join(TeacherGroup, TeacherGroup.group_id == Group.id)
            .outerjoin(StudentGroup, StudentGroup.group_id == Group.id)
            .where(TeacherGroup.teacher_id == teacher.id)
            .group_by(Group.id)
            .order_by(Group.year, Group.name)
        )).all()

    if not rows:
        await message.answer("⚠️ Sizga hech qanday guruh biriktirilmagan.",
                             reply_markup=teacher_menu())
        return

    total_students = sum(cnt for _, cnt in rows)
    text = "👥 <b>Mening guruhlarim</b>\n━━━━━━━━━━━━━━\n"
    for g, cnt in rows:
        text += (f"\n📁 <b>{g.name}</b> [{g.year}]\n"
                 f"   🆔 group_id: <code>{g.id}</code>\n"
                 f"   👥 O'quvchilar: <b>{cnt}</b> ta\n")
    text += (f"\n━━━━━━━━━━━━━━\n"
             f"📊 Jami: <b>{len(rows)}</b> guruh, <b>{total_students}</b> o'quvchi")
    await message.answer(text, reply_markup=teacher_menu())
