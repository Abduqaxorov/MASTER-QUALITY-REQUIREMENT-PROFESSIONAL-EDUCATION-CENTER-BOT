"""O'qituvchi reply qilib javob beradi: o'quvchiga YOKI adminga."""
from aiogram import Router, F
from aiogram.types import Message
from aiogram.filters import StateFilter
from sqlalchemy import select
from database.engine import async_session
from database.models import Teacher

router = Router()

TAG_STUDENT = "🆔 O'QUVCHI:"   # user/contact_teacher.py bilan bir xil
TAG_ADMIN = "🆔 ADMIN:"        # admin/teacher_contact.py bilan bir xil


async def _is_teacher(tg_id: int) -> bool:
    async with async_session() as session:
        t = await session.scalar(
            select(Teacher).where(Teacher.tg_id == tg_id, Teacher.is_active == True)
        )
        return t is not None


@router.message(
    StateFilter(None),
    F.reply_to_message,
    (F.reply_to_message.text.contains(TAG_STUDENT) |
     F.reply_to_message.caption.contains(TAG_STUDENT) |
     F.reply_to_message.text.contains(TAG_ADMIN) |
     F.reply_to_message.caption.contains(TAG_ADMIN)),
)
async def teacher_reply(message: Message):
    """Ustoz teg'li xabarga reply qilsa — javob egasiga boradi."""
    if not await _is_teacher(message.from_user.id):
        return

    replied = message.reply_to_message
    text = replied.text or replied.caption or ""

    tag = TAG_STUDENT if TAG_STUDENT in text else TAG_ADMIN
    try:
        after = text.split(tag, 1)[1].strip()
        target_id = int(after.split()[0])
    except (IndexError, ValueError):
        return

    who = "o'quvchiga" if tag == TAG_STUDENT else "adminga"
    header = ("📬 <b>Ustozdan javob:</b>" if tag == TAG_STUDENT
              else f"📬 <b>Ustozdan javob</b> ({message.from_user.full_name}):")

    try:
        await message.bot.send_message(target_id, f"{header}\n━━━━━━━━━━━━━━")
        await message.copy_to(target_id)
        await message.answer(f"✅ Javobingiz {who} yuborildi.")
    except Exception:
        await message.answer("❌ Yuborib bo'lmadi (qabul qiluvchi botni bloklagan bo'lishi mumkin).")
