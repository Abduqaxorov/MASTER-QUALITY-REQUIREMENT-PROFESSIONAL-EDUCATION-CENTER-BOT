import re
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from states.states import TeacherScheduleFSM
from database.engine import async_session
from database.models import Teacher, TeacherGroup, Group, TeacherSchedule
from keyboards.reply import teacher_menu
from keyboards.inline import schedule_days_kb, teacher_schedules_kb, groups_kb
from keyboards.buttons import BTN_T_SCHEDULE

router = Router()

DAY_NAMES = {
    "Monday": "Dushanba", "Tuesday": "Seshanba", "Wednesday": "Chorshanba",
    "Thursday": "Payshanba", "Friday": "Juma", "Saturday": "Shanba", "Sunday": "Yakshanba",
}


async def _get_teacher(tg_id: int):
    async with async_session() as session:
        return await session.scalar(
            select(Teacher).where(Teacher.tg_id == tg_id, Teacher.is_active == True)
        )


async def _get_teacher_groups(teacher_id: int) -> list:
    async with async_session() as session:
        links = (await session.scalars(
            select(TeacherGroup).where(TeacherGroup.teacher_id == teacher_id)
        )).all()
        groups = []
        for link in links:
            g = await session.get(Group, link.group_id)
            if g:
                groups.append(g)
        return groups


async def _load_schedules(teacher_id: int):
    """Dars vaqtlarini group bilan birga yuklaydi (lazy-load xatosini oldini oladi)."""
    async with async_session() as session:
        schedules = (await session.scalars(
            select(TeacherSchedule)
            .options(selectinload(TeacherSchedule.group))
            .where(TeacherSchedule.teacher_id == teacher_id)
            .order_by(TeacherSchedule.day_of_week, TeacherSchedule.start_time)
        )).all()
        return list(schedules)


async def _show_schedule_list(target: Message, teacher_id: int, edit: bool = False):
    """Ustozning barcha darslarini ko'rsatadi (bo'sh bo'lsa — kun tanlash)."""
    schedules = await _load_schedules(teacher_id)
    if not schedules:
        text = ("📅 <b>Dars jadvalingiz bo'sh.</b>\n"
                "Yangi dars qo'shish uchun hafta kunini tanlang:")
        kb = schedule_days_kb()
    else:
        text = "📅 <b>Mavjud darslaringiz:</b>\nO'zgartirish/o'chirish uchun ustiga bosing:"
        kb = teacher_schedules_kb(schedules)
    if edit:
        try:
            await target.edit_text(text, reply_markup=kb)
            return
        except Exception:
            pass
    await target.answer(text, reply_markup=kb)


# ───────────── Asosiy menyu ─────────────

@router.message(F.text == BTN_T_SCHEDULE)
async def schedule_menu(message: Message, state: FSMContext):
    await state.clear()
    teacher = await _get_teacher(message.from_user.id)
    if not teacher:
        await message.answer("❌ O'qituvchi topilmadi.", reply_markup=teacher_menu())
        return
    await _show_schedule_list(message, teacher.id)


# ───────────── Yangi dars qo'shish ─────────────

@router.callback_query(F.data == "sadd")
async def schedule_add_new(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.message.edit_text(
        "📅 Yangi dars qo'shish uchun hafta kunini tanlang:",
        reply_markup=schedule_days_kb())
    await state.set_state(TeacherScheduleFSM.group)
    await call.answer()


@router.callback_query(F.data.startswith("sday:"))
async def schedule_day_selected(call: CallbackQuery, state: FSMContext):
    day = call.data.split(":")[1]
    await state.update_data(day=day, _mode="new")
    teacher = await _get_teacher(call.from_user.id)
    if not teacher:
        await call.answer("❌ O'qituvchi topilmadi.", show_alert=True)
        return
    groups = await _get_teacher_groups(teacher.id)
    if not groups:
        await call.answer("⚠️ Sizga hech qanday guruh biriktirilmagan!", show_alert=True)
        return
    await call.message.edit_text(
        f"📅 <b>{DAY_NAMES.get(day, day)}</b> kuni qaysi guruh uchun dars vaqti belgilaysiz?",
        reply_markup=groups_kb(groups, "schedgrp")
    )
    await state.set_state(TeacherScheduleFSM.group)
    await call.answer()


@router.callback_query(TeacherScheduleFSM.group, F.data.startswith("schedgrp:"))
async def schedule_group_selected(call: CallbackQuery, state: FSMContext):
    group_id = int(call.data.split(":")[1])
    await state.update_data(group_id=group_id)
    await call.message.edit_text("⏰ Dars boshlanish vaqtini kiriting (masalan: 14:00):")
    await state.set_state(TeacherScheduleFSM.start_time)
    await call.answer()


# ───────────── Darsni tanlash (o'zgartirish/o'chirish) ─────────────

@router.callback_query(F.data.startswith("sdeld:"))
async def schedule_selected(call: CallbackQuery):
    schedule_id = int(call.data.split(":")[1])
    async with async_session() as session:
        sch = await session.scalar(
            select(TeacherSchedule)
            .options(selectinload(TeacherSchedule.group))
            .where(TeacherSchedule.id == schedule_id)
        )
    if not sch:
        await call.answer("❌ Dars topilmadi.", show_alert=True)
        return
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="⏰ Vaqtini o'zgartirish",
                              callback_data=f"schedit:{schedule_id}")],
        [InlineKeyboardButton(text="🗑 O'chirish",
                              callback_data=f"schdel:{schedule_id}")],
        [InlineKeyboardButton(text="🔙 Orqaga", callback_data="schback")],
    ])
    await call.message.edit_text(
        f"📅 <b>{DAY_NAMES.get(sch.day_of_week, sch.day_of_week)}</b>\n"
        f"⏰ {sch.start_time} - {sch.end_time}\n"
        f"📁 Guruh: {sch.group.name if sch.group else '—'}\n\n"
        "Nima qilamiz?",
        reply_markup=kb
    )
    await call.answer()


@router.callback_query(F.data == "schback")
async def schedule_back(call: CallbackQuery, state: FSMContext):
    await state.clear()
    teacher = await _get_teacher(call.from_user.id)
    if teacher:
        await _show_schedule_list(call.message, teacher.id, edit=True)
    await call.answer()


@router.callback_query(F.data.startswith("schedit:"))
async def schedule_edit_start(call: CallbackQuery, state: FSMContext):
    schedule_id = int(call.data.split(":")[1])
    await state.update_data(edit_schedule_id=schedule_id, _mode="edit")
    await call.message.edit_text("⏰ Yangi boshlanish vaqtini kiriting (masalan: 14:00):")
    await state.set_state(TeacherScheduleFSM.start_time)
    await call.answer()


@router.callback_query(F.data.startswith("schdel:"))
async def schedule_delete(call: CallbackQuery, state: FSMContext):
    schedule_id = int(call.data.split(":")[1])
    async with async_session() as session:
        sch = await session.get(TeacherSchedule, schedule_id)
        if sch:
            await session.delete(sch)
            await session.commit()
    await call.answer("O'chirildi")
    teacher = await _get_teacher(call.from_user.id)
    if teacher:
        await _show_schedule_list(call.message, teacher.id, edit=True)


# ───────────── Vaqt kiritish (yangi VA o'zgartirish uchun umumiy) ─────────────

@router.message(TeacherScheduleFSM.start_time)
async def schedule_start_time(message: Message, state: FSMContext):
    time_str = message.text.strip()
    if not re.match(r"^\d{2}:\d{2}$", time_str):
        await message.answer("❌ Vaqt noto'g'ri formatda. Masalan: 14:00")
        return
    await state.update_data(start_time=time_str)
    await message.answer("⏰ Dars tugash vaqtini kiriting (masalan: 15:30):")
    await state.set_state(TeacherScheduleFSM.end_time)


@router.message(TeacherScheduleFSM.end_time)
async def schedule_end_time(message: Message, state: FSMContext):
    time_str = message.text.strip()
    if not re.match(r"^\d{2}:\d{2}$", time_str):
        await message.answer("❌ Vaqt noto'g'ri formatda. Masalan: 15:30")
        return
    data = await state.get_data()
    start = data["start_time"]
    end = time_str
    if start >= end:
        await message.answer("❌ Tugash vaqti boshlanish vaqtidan keyin bo'lishi kerak!")
        return

    teacher = await _get_teacher(message.from_user.id)
    if not teacher:
        await message.answer("❌ O'qituvchi topilmadi.", reply_markup=teacher_menu())
        await state.clear()
        return

    if data.get("_mode") == "edit":
        # Mavjud darsni yangilaymiz
        sid = data.get("edit_schedule_id")
        async with async_session() as session:
            sch = await session.get(TeacherSchedule, sid)
            if sch:
                sch.start_time = start
                sch.end_time = end
                await session.commit()
        await message.answer(
            f"✅ <b>Dars vaqti yangilandi!</b>\n⏰ {start} - {end}",
            reply_markup=teacher_menu())
    else:
        # Yangi dars qo'shamiz
        async with async_session() as session:
            session.add(TeacherSchedule(
                teacher_id=teacher.id,
                group_id=data["group_id"],
                day_of_week=data["day"],
                start_time=start,
                end_time=end
            ))
            await session.commit()
        await message.answer(
            f"✅ <b>Dars vaqti saqlandi!</b>\n"
            f"📅 {DAY_NAMES.get(data['day'], data['day'])}\n⏰ {start} - {end}\n"
            "Yana dars qo'shishingiz mumkin 👇",
            reply_markup=teacher_menu())

    await state.clear()
    await _show_schedule_list(message, teacher.id)
