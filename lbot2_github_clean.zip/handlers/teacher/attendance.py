import asyncio
from datetime import datetime, date
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from states.states import AttendanceFSM
from database.engine import async_session
from database.models import Group, Attendance, Teacher, TeacherGroup, StudentGroup, Student
from keyboards.reply import teacher_menu
from keyboards.inline import (
    attendance_mode_kb, attendance_marking_kb, attendance_confirm_kb, groups_kb,
)
from keyboards.buttons import BTN_T_ATTENDANCE
from utils.helpers import download_excel, safe_int
from utils.linking import get_student_tg_ids

router = Router()


async def _get_teacher_group_ids(tg_id: int) -> set:
    async with async_session() as session:
        teacher = await session.scalar(
            select(Teacher).where(Teacher.tg_id == tg_id)
        )
        if not teacher:
            return set()
        links = (await session.scalars(
            select(TeacherGroup).where(TeacherGroup.teacher_id == teacher.id)
        )).all()
        return {link.group_id for link in links}


async def _notify_absent_parents(bot, absent_students: list[dict], gid: int, day: date):
    """Kelmagan o'quvchilarning ota-onalariga xabar yuboradi.
    absent_students: [{"id":..., "name":..., "last_name":...}, ...]"""
    async with async_session() as session:
        g = await session.get(Group, gid)
    gname = g.name if g else "—"

    notified = 0
    for s in absent_students:
        tg_ids = await get_student_tg_ids(s["id"])
        for tg in tg_ids:
            try:
                await bot.send_message(
                    tg,
                    f"🔔 <b>Davomat xabari</b>\n"
                    f"━━━━━━━━━━━━━━\n"
                    f"👤 <b>{s['name']} {s['last_name']}</b>\n"
                    f"📁 Guruh: {gname}\n"
                    f"📅 Sana: {day.isoformat()}\n"
                    f"❌ <b>Bugun darsga kelmadi.</b>\n"
                    f"\nSavollar bo'lsa «👨‍🏫 Ustoz bilan bog'lanish» orqali yozing."
                )
                notified += 1
            except Exception:
                pass
            await asyncio.sleep(0.05)
    return notified


@router.message(F.text == BTN_T_ATTENDANCE)
async def att_start(message: Message, state: FSMContext):
    await state.clear()
    valid_group_ids = await _get_teacher_group_ids(message.from_user.id)
    if not valid_group_ids:
        await message.answer("❌ Sizga hech qanday guruh biriktirilmagan.",
                             reply_markup=teacher_menu())
        return
    async with async_session() as session:
        groups = (await session.scalars(
            select(Group).where(Group.id.in_(valid_group_ids))
            .order_by(Group.year, Group.name)
        )).all()
    if not groups:
        await message.answer("❌ Guruh topilmadi.", reply_markup=teacher_menu())
        return
    await message.answer("Guruhni tanlang:", reply_markup=groups_kb(groups, "tattgrp"))
    await state.set_state(AttendanceFSM.group)


@router.callback_query(AttendanceFSM.group, F.data.startswith("tattgrp:"))
async def att_group(call: CallbackQuery, state: FSMContext):
    group_id = int(call.data.split(":")[1])
    await state.update_data(group_id=group_id)
    try:
        await call.message.edit_text(
            "Davomat usulini tanlang:", reply_markup=attendance_mode_kb())
    except Exception:
        await call.message.answer(
            "Davomat usulini tanlang:", reply_markup=attendance_mode_kb())
    await state.set_state(AttendanceFSM.mode)
    await call.answer()


@router.callback_query(AttendanceFSM.mode, F.data == "att_mode:one")
async def att_mode_one(call: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    gid = data["group_id"]
    async with async_session() as session:
        links = (await session.scalars(
            select(StudentGroup)
            .options(selectinload(StudentGroup.student))
            .where(StudentGroup.group_id == gid)
        )).all()
        students = [l.student for l in links]

    if not students:
        await call.message.edit_text("❌ Bu guruhda o'quvchi yo'q.")
        await call.message.answer("Bosh menyu:", reply_markup=teacher_menu())
        await state.clear()
        await call.answer()
        return
    await state.update_data(absent_ids=[])
    students_min = [{"id": s.id, "name": s.name, "last_name": s.last_name} for s in students]
    await state.update_data(students=students_min)
    await call.message.edit_text(
        "👥 <b>Davomat — kelmaganlarni belgilang</b>\n"
        "━━━━━━━━━━━━━━\n"
        "✅ = keldi, ❌ = kelmadi.\n"
        "Kelmagan o'quvchi ustiga bosing, so'ng «💾 Saqlash».",
        reply_markup=attendance_marking_kb(students, set()),
    )
    await state.set_state(AttendanceFSM.marking)
    await call.answer()


def _objs(students_min):
    class _S:
        def __init__(self, d):
            self.id = d["id"]; self.name = d["name"]; self.last_name = d["last_name"]
    return [_S(d) for d in students_min]


@router.callback_query(AttendanceFSM.marking, F.data.startswith("att_toggle:"))
async def att_toggle(call: CallbackQuery, state: FSMContext):
    sid = int(call.data.split(":")[1])
    data = await state.get_data()
    absent = set(data.get("absent_ids", []))
    if sid in absent:
        absent.discard(sid)
    else:
        absent.add(sid)
    await state.update_data(absent_ids=list(absent))
    students = _objs(data["students"])
    try:
        await call.message.edit_reply_markup(
            reply_markup=attendance_marking_kb(students, absent))
    except Exception:
        pass
    await call.answer()


@router.callback_query(AttendanceFSM.marking, F.data == "att_save")
async def att_save_ask(call: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    absent = data.get("absent_ids", [])
    total = len(data["students"])
    came = total - len(absent)
    await call.message.edit_text(
        "❓ <b>Davomatni saqlaymizmi?</b>\n"
        "━━━━━━━━━━━━━━\n"
        f"✅ Kelgan: <b>{came}</b>\n"
        f"❌ Kelmagan: <b>{len(absent)}</b>\n"
        f"📅 Sana: <b>{date.today().isoformat()}</b>\n"
        f"\nℹ️ Kelmaganlarning ota-onasiga avtomatik xabar boradi.",
        reply_markup=attendance_confirm_kb(),
    )
    await state.set_state(AttendanceFSM.confirm)
    await call.answer()


@router.callback_query(AttendanceFSM.marking, F.data == "att_cancel")
async def att_cancel(call: CallbackQuery, state: FSMContext):
    try:
        await call.message.edit_text("🚫 Davomat bekor qilindi.")
    except Exception:
        pass
    await call.message.answer("Bosh menyu:", reply_markup=teacher_menu())
    await state.clear()
    await call.answer()


@router.callback_query(AttendanceFSM.confirm, F.data == "att_confirm_yes")
async def att_confirm_yes(call: CallbackQuery, state: FSMContext):
    data = await state.get_data()
    absent = set(data.get("absent_ids", []))
    students = data["students"]
    gid = data["group_id"]
    today = date.today()
    async with async_session() as session:
        for s in students:
            sid = s["id"]
            present = 0 if sid in absent else 1
            existing = await session.scalar(
                select(Attendance).where(
                    Attendance.student_id == sid,
                    Attendance.group_id == gid,
                    Attendance.day == today
                )
            )
            if existing:
                existing.present = present
            else:
                session.add(Attendance(student_id=sid, group_id=gid, day=today, present=present))
        await session.commit()
    try:
        await call.message.edit_text(
            "✅ <b>Davomat saqlandi.</b>\n"
            f"📅 Sana: {today.isoformat()}\n"
            f"❌ Kelmaganlar: {len(absent)} ta"
        )
    except Exception:
        pass
    await call.message.answer("Bosh menyu:", reply_markup=teacher_menu())
    await state.clear()
    await call.answer()

    # ── Kelmaganlarning ota-onalariga xabar ──
    absent_students = [s for s in students if s["id"] in absent]
    if absent_students:
        notified = await _notify_absent_parents(call.bot, absent_students, gid, today)
        await call.message.answer(
            f"📤 Ota-onalarga xabar yuborildi: <b>{notified}</b> ta.")


@router.callback_query(AttendanceFSM.confirm, F.data == "att_confirm_no")
async def att_confirm_no(call: CallbackQuery, state: FSMContext):
    try:
        await call.message.edit_text("🚫 Bekor qilindi. Davomat saqlanmadi.")
    except Exception:
        pass
    await call.message.answer("Bosh menyu:", reply_markup=teacher_menu())
    await state.clear()
    await call.answer()


@router.callback_query(AttendanceFSM.mode, F.data == "att_mode:excel")
async def att_mode_excel(call: CallbackQuery, state: FSMContext):
    try:
        await call.message.edit_text(
            "📥 Davomat .xlsx faylini yuboring.\n"
            "Ustunlar: <code>sana, student_id, group, ism, familya</code>\n"
            "• <b>sana</b> — YYYY-MM-DD (masalan 2025-06-15)\n"
            "• <b>status</b> ustuni bo'lsa: 1=keldi, 0=kelmadi. "
            "Bo'lmasa, faylda bo'lganlar kelgan hisoblanadi."
        )
    except Exception:
        await call.message.answer("📥 Davomat .xlsx faylini yuboring.")
    await state.set_state(AttendanceFSM.file)
    await call.answer()


@router.message(AttendanceFSM.file, F.document)
async def att_excel_load(message: Message, state: FSMContext):
    data = await state.get_data()
    df, err = await download_excel(message)
    if err:
        await message.answer(err)
        return
    df.columns = [str(c).strip().lower() for c in df.columns]
    if not {"sana", "student_id"}.issubset(set(df.columns)):
        await message.answer(
            "❌ Ustunlar kerak: sana, student_id "
            "(group, ism, familya, status — ixtiyoriy)."
        )
        await state.clear()
        return
    has_status = "status" in df.columns
    today = date.today()
    absent_today_ids = []
    async with async_session() as session:
        valid_ids = set((await session.scalars(
            select(StudentGroup.student_id).where(StudentGroup.group_id == data["group_id"])
        )).all())
        added, skipped = 0, 0
        gid = data["group_id"]
        for _, row in df.iterrows():
            sid = safe_int(row.get("student_id"))
            if sid is None or sid not in valid_ids:
                skipped += 1
                continue
            raw_day = str(row.get("sana", "")).strip()[:10]
            try:
                day = datetime.strptime(raw_day, "%Y-%m-%d").date()
            except ValueError:
                skipped += 1
                continue
            present = 1
            if has_status:
                st = safe_int(row.get("status"))
                present = 1 if (st is None or st == 1) else 0
            existing = await session.scalar(
                select(Attendance).where(
                    Attendance.student_id == sid,
                    Attendance.group_id == gid,
                    Attendance.day == day
                )
            )
            if existing:
                existing.present = present
            else:
                session.add(Attendance(student_id=sid, group_id=gid, day=day, present=present))
            if present == 0 and day == today:
                absent_today_ids.append(sid)
            added += 1
        await session.commit()

    await message.answer(
        f"✅ Davomat yuklandi: {added} ta\n⚠️ O'tkazib yuborildi: {skipped} ta",
        reply_markup=teacher_menu(),
    )
    await state.clear()

    # ── Bugungi kelmaganlarning ota-onalariga xabar ──
    if absent_today_ids:
        async with async_session() as session:
            students = (await session.scalars(
                select(Student).where(Student.id.in_(absent_today_ids))
            )).all()
        absent_students = [
            {"id": s.id, "name": s.name, "last_name": s.last_name} for s in students
        ]
        notified = await _notify_absent_parents(
            message.bot, absent_students, data["group_id"], today)
        if notified:
            await message.answer(
                f"📤 Ota-onalarga xabar yuborildi: <b>{notified}</b> ta.")


@router.message(AttendanceFSM.file)
async def att_excel_invalid(message: Message):
    await message.answer("❌ Iltimos, .xlsx faylni yuboring.")
