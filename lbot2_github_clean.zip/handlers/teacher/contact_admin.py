"""O'qituvchi → Admin murojaati (navbatsiz, darhol yuboriladi)."""
from aiogram import Router, F
from aiogram.types import Message, ReplyKeyboardRemove
from aiogram.fsm.context import FSMContext
from sqlalchemy import select
from database.engine import async_session
from database.models import Teacher, ContactTicket
from keyboards.reply import teacher_menu
from keyboards.buttons import BTN_T_CONTACT_ADMIN
from utils.tickets import get_next_ticket_number, get_user_queue_position
from states.states import TeacherTicketFSM

router = Router()


async def _is_teacher(tg_id: int) -> bool:
    async with async_session() as session:
        t = await session.scalar(
            select(Teacher).where(Teacher.tg_id == tg_id, Teacher.is_active == True)
        )
        return t is not None


@router.message(F.text == BTN_T_CONTACT_ADMIN)
async def teacher_contact_admin(message: Message, state: FSMContext):
    if not await _is_teacher(message.from_user.id):
        await message.answer("⚠️ Bu bo'lim faqat o'qituvchilar uchun.")
        return
    await state.clear()
    pos = await get_user_queue_position(message.from_user.id, "teacher")
    if pos:
        await message.answer(
            "⏳ <b>Siz allaqachon murojaat yuborgansiz!</b>\n"
            "Admin ko'rib chiqqandan keyin javob beradi.",
            reply_markup=teacher_menu()
        )
        return
    await message.answer(
        "✍️ Adminga yubormoqchi bo'lgan xabaringizni yozing:",
        reply_markup=ReplyKeyboardRemove()
    )
    await state.set_state(TeacherTicketFSM.text)


@router.message(TeacherTicketFSM.text, F.text)
async def teacher_contact_text(message: Message, state: FSMContext):
    if not await _is_teacher(message.from_user.id):
        await state.clear()
        return
    u = message.from_user

    async with async_session() as session:
        ticket_number = await get_next_ticket_number()
        # status="active" — NAVBATGA TUSHMAYDI, lekin tasdiqlash tugmalari ishlaydi
        ticket = ContactTicket(
            ticket_number=ticket_number,
            from_user_id=u.id,
            from_role="teacher",
            from_name=u.full_name,
            text=message.text.strip(),
            status="active",
        )
        session.add(ticket)
        await session.commit()
        ticket_id = ticket.id

    await message.answer(
        f"✅ Murojaatingiz adminga <b>darhol</b> yuborildi.\n"
        f"📋 Murojaat raqami: <b>#{ticket_number}</b>",
        reply_markup=teacher_menu()
    )

    # Adminlarga DARROV ko'rsatamiz
    from handlers.admin.tickets import notify_admins_new_ticket
    async with async_session() as session:
        saved = await session.get(ContactTicket, ticket_id)
    try:
        await notify_admins_new_ticket(message.bot, saved)
    except Exception:
        pass

    await state.clear()
