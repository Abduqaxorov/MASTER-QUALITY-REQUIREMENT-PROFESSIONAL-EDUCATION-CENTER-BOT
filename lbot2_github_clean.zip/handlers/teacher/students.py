"""O'qituvchi: o'quvchi qo'shish (bittalab) va ro'yxat (Excel, id bilan)."""
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, BufferedInputFile
from aiogram.fsm.context import FSMContext
from sqlalchemy import select
from sqlalchemy.orm import selectinload

from states.states import StudentFSM
from database.engine import async_session
from database.models import Student, Group, Teacher, TeacherGroup, StudentGroup
from keyboards.inline import groups_kb, student_exists_kb
from keyboards.reply import teacher_menu
from keyboards.buttons import BTN_T_ADD_STUDENT, BTN_T_STUDENT_LIST
from utils.helpers import safe_delete, make_excel

router = Router()


async def _get_teacher_group_ids(tg_id: int) -> set:
    async with async_session() as session:
        teacher = await session.scalar(
            select(Teacher).where(Teacher.tg_id == tg_id, Teacher.is_active == True)
        )
        if not teacher:
            return set()
        links = (await session.scalars(
            select(TeacherGroup).where(TeacherGroup.teacher_id == teacher.id)
        )).all()
        return {link.group_id for link in links}


async def _get_teacher_groups(tg_id: int) -> list:
    ids = await _get_teacher_group_ids(tg_id)
    if not ids:
        return []
    async with async_session() as session:
        groups = (await session.scalars(
            select(Group).where(Group.id.in_(ids)).order_by(Group.year, Group.name)
        )).all()
    return list(groups)


# ───────────── O'quvchi qo'shish (bittalab) ─────────────

@router.message(F.text == BTN_T_ADD_STUDENT)
async def add_student(message: Message, state: FSMContext):
    await state.clear()
    groups = await _get_teacher_groups(message.from_user.id)
    if not groups:
        await message.answer("❌ Sizga hech qanday guruh biriktirilmagan.",
                             reply_markup=teacher_menu())
        return
    await message.answer("O'quvchi ismini kiriting:")
    await state.set_state(StudentFSM.name)


@router.message(StudentFSM.name)
async def st_name(message: Message, state: FSMContext):
    await state.update_data(name=message.text.strip())
    await message.answer("Familiyasini kiriting:")
    await state.set_state(StudentFSM.last_name)


@router.message(StudentFSM.last_name)
async def st_last(message: Message, state: FSMContext):
    await state.update_data(last_name=message.text.strip())
    await message.answer("Telefon raqamini kiriting:")
    await state.set_state(StudentFSM.tel)


@router.message(StudentFSM.tel)
async def st_tel(message: Message, state: FSMContext):
    await state.update_data(tel=message.text.strip())
    data = await state.get_data()

    # Ism va familiya bo'yicha qidirish
    async with async_session() as session:
        existing_student = await session.scalar(
            select(Student).where(
                Student.name == data["name"],
                Student.last_name == data["last_name"]
            )
        )

    groups = await _get_teacher_groups(message.from_user.id)
    if not groups:
        await message.answer("❌ Sizga hech qanday guruh biriktirilmagan!",
                             reply_markup=teacher_menu())
        await state.clear()
        return

    if existing_student:
        await state.update_data(existing_id=existing_student.id)
        await message.answer(
            f"⚠️ <b>{existing_student.name} {existing_student.last_name}</b> allaqachon tizimda mavjud.\n"
            "Uni o'zingizning guruhingizga qo'shishni xohlaysizmi?",
            reply_markup=groups_kb(groups, "taddst_exist")
        )
    else:
        await message.answer("Guruhni tanlang:", reply_markup=groups_kb(groups, "taddst"))
    await state.set_state(StudentFSM.group_id)


@router.callback_query(StudentFSM.group_id, F.data.startswith("taddst:"))
async def st_group(call: CallbackQuery, state: FSMContext):
    group_id = int(call.data.split(":")[1])
    valid_ids = await _get_teacher_group_ids(call.from_user.id)
    if group_id not in valid_ids:
        await call.answer("❌ Bu guruh sizniki emas.", show_alert=True)
        return

    data = await state.get_data()
    async with async_session() as session:
        new_student = Student(
            name=data["name"],
            last_name=data["last_name"],
            tel=data["tel"]
        )
        session.add(new_student)
        await session.flush()  # ID olish uchun

        # O'quvchini guruhga bog'lash
        session.add(StudentGroup(student_id=new_student.id, group_id=group_id, balance=0.0))
        await session.commit()
        new_id = new_student.id

    await safe_delete(call.message)
    await call.message.answer(
        f"✅ Yangi o'quvchi qo'shildi.\n🆔 <b>student_id: {new_id}</b>",
        reply_markup=teacher_menu())
    await state.clear()
    await call.answer()


@router.callback_query(StudentFSM.group_id, F.data.startswith("taddst_exist:"))
async def st_group_exist(call: CallbackQuery, state: FSMContext):
    group_id = int(call.data.split(":")[1])
    data = await state.get_data()
    student_id = data["existing_id"]

    async with async_session() as session:
        # Tekshirish: bu o'quvchi bu guruhda bormi?
        already_in = await session.scalar(
            select(StudentGroup).where(
                StudentGroup.student_id == student_id,
                StudentGroup.group_id == group_id
            )
        )
        if already_in:
            await call.answer("❌ Bu o'quvchi allaqachon bu guruhda bor.", show_alert=True)
            return

        session.add(StudentGroup(student_id=student_id, group_id=group_id, balance=0.0))
        await session.commit()

    await safe_delete(call.message)
    await call.message.answer(
        f"✅ Mavjud o'quvchi guruhga qo'shildi.\n🆔 <b>student_id: {student_id}</b>",
        reply_markup=teacher_menu())
    await state.clear()
    await call.answer()


# ───────────── O'quvchilar ro'yxati (Excel, ID bilan) ─────────────

@router.message(F.text == BTN_T_STUDENT_LIST)
async def list_students(message: Message, state: FSMContext):
    await state.clear()
    valid_group_ids = await _get_teacher_group_ids(message.from_user.id)
    if not valid_group_ids:
        await message.answer("❌ Sizga hech qanday guruh biriktirilmagan.",
                             reply_markup=teacher_menu())
        return

    async with async_session() as session:
        # O'qituvchining guruhlaridagi barcha o'quvchi-guruh bog'liqliklarini olish
        links = (await session.scalars(
            select(StudentGroup)
            .options(selectinload(StudentGroup.student), selectinload(StudentGroup.group))
            .where(StudentGroup.group_id.in_(valid_group_ids))
            .order_by(StudentGroup.group_id)
        )).all()

    if not links:
        await message.answer("Hozircha o'quvchilar yo'q.", reply_markup=teacher_menu())
        return

    # Excel — student_id BIRINCHI ustun
    rows = []
    for link in links:
        s = link.student
        g = link.group
        rows.append({
            "student_id": s.id,
            "Ism": s.name,
            "Familiya": s.last_name,
            "Telefon": s.tel or "",
            "Guruh": g.name if g else "",
            "group_id": g.id if g else "",
            "Yil": g.year if g else "",
            "Balans (so'm)": round(link.balance or 0),
            "O'rtacha (%)": round(link.average_score or 0, 1),
        })

    buffer = make_excel(rows, sheet_name="O'quvchilar")
    file = BufferedInputFile(buffer.read(), filename="mening_oquvchilarim.xlsx")

    # Telegramda ham qisqa ro'yxat (id bilan) — birinchi 40 tasi
    preview = "📋 <b>Mening o'quvchilarim (ID bilan)</b>\n━━━━━━━━━━━━━━\n"
    current_group = None
    shown = 0
    for link in links:
        s = link.student
        if shown >= 40:
            preview += f"\n... va yana {len(links) - 40} ta (to'liqi Excel'da)"
            break
        if link.group_id != current_group:
            current_group = link.group_id
            gname = link.group.name if link.group else "—"
            gyear = link.group.year if link.group else ""
            preview += f"\n📁 <b>{gname} [{gyear}]</b>\n"
        preview += f"  🆔 <code>{s.id}</code> — {s.name} {s.last_name}\n"
        shown += 1

    await message.answer(preview)
    await message.answer_document(
        file,
        caption=(
            "📊 <b>To'liq ro'yxat (Excel)</b>\n"
            f"👥 Jami: {len(links)} ta\n"
            "1-ustun <b>student_id</b> — test va davomat yuklashda shundan foydalaning."
        ),
        reply_markup=teacher_menu(),
    )