import asyncio
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from sqlalchemy import select, func

from states.states import TestFSM
from database.engine import async_session
from database.models import Student, TestResult, Teacher, TeacherGroup, StudentGroup, Group
from keyboards.inline import groups_kb
from keyboards.reply import teacher_menu
from keyboards.buttons import BTN_T_TESTS
from utils.helpers import download_excel, safe_int, safe_float
from utils.linking import get_student_tg_ids

router = Router()


async def _get_teacher_group_ids(tg_id: int) -> set:
    async with async_session() as session:
        teacher = await session.scalar(
            select(Teacher).where(Teacher.tg_id == tg_id, Teacher.is_active == True)
        )
        if not teacher:
            return set()
        links = (await session.scalars(
            select(TeacherGroup).where(TeacherGroup.teacher_id == teacher.id)
        )).all()
        return {link.group_id for link in links}


@router.message(F.text == BTN_T_TESTS)
async def test_start(message: Message, state: FSMContext):
    await state.clear()
    valid_group_ids = await _get_teacher_group_ids(message.from_user.id)
    if not valid_group_ids:
        await message.answer("❌ Sizga hech qanday guruh biriktirilmagan.",
                             reply_markup=teacher_menu())
        return

    async with async_session() as session:
        groups = (await session.scalars(
            select(Group).where(Group.id.in_(valid_group_ids)).order_by(Group.year, Group.name)
        )).all()

    await message.answer("Guruhni tanlang:", reply_markup=groups_kb(groups, "ttstgrp"))
    await state.set_state(TestFSM.group)


@router.callback_query(TestFSM.group, F.data.startswith("ttstgrp:"))
async def test_group(call: CallbackQuery, state: FSMContext):
    group_id = int(call.data.split(":")[1])
    await state.update_data(group_id=group_id)
    await call.message.edit_text("📊 Test qaysi <b>o'quv yili</b> uchun? (masalan: 2025):")
    await state.set_state(TestFSM.year)
    await call.answer()


@router.message(TestFSM.year, F.text)
async def ask_file(message: Message, state: FSMContext):
    raw = message.text.strip()
    if not raw.isdigit():
        await message.answer("❌ Yil noto'g'ri. Faqat raqam kiriting. Masalan: 2025")
        return
    year = int(raw)
    await state.update_data(year=year)
    await message.answer("📊 Faylni yuboring.\nUstunlar: <code>student_id, score</code>")
    await state.set_state(TestFSM.file)


@router.message(TestFSM.file, F.document)
async def load_test(message: Message, state: FSMContext):
    data = await state.get_data()
    year = data["year"]
    gid = data["group_id"]
    df, err = await download_excel(message)
    if err:
        await message.answer(err)
        return
    df.columns = [str(c).strip().lower() for c in df.columns]
    if not {"student_id", "score"}.issubset(set(df.columns)):
        await message.answer("❌ Ustunlar: student_id, score bo'lishi kerak.")
        await state.clear()
        return

    added_results: list[tuple[int, float]] = []  # (student_id, score)

    async with async_session() as session:
        valid_ids = set((await session.scalars(
            select(StudentGroup.student_id).where(StudentGroup.group_id == gid)
        )).all())

        added, skipped, affected = 0, 0, set()
        for _, row in df.iterrows():
            sid, score = safe_int(row["student_id"]), safe_float(row["score"])
            if sid is None or score is None:
                skipped += 1
                continue
            if sid not in valid_ids:
                skipped += 1
                continue
            session.add(TestResult(student_id=sid, group_id=gid, score=score))
            affected.add(sid)
            added_results.append((sid, score))
            added += 1
        await session.flush()

        for sid in affected:
            avg = await session.scalar(
                select(func.avg(TestResult.score))
                .where(TestResult.student_id == sid, TestResult.group_id == gid)
            )
            link = await session.scalar(
                select(StudentGroup).where(
                    StudentGroup.student_id == sid, StudentGroup.group_id == gid)
            )
            if link:
                link.average_score = round(avg or 0.0, 2)
        await session.commit()

    await message.answer(
        f"✅ {year}-yil: {added} ta natija yuklandi.\n"
        f"⚠️ Sizniki bo'lmagan/xato: {skipped}",
        reply_markup=teacher_menu())
    await state.clear()

    # ── O'quvchi/ota-onalarga natijalarni yuborish ──
    if added_results:
        async with async_session() as session:
            g = await session.get(Group, gid)
            sids = list({sid for sid, _ in added_results})
            students = (await session.scalars(
                select(Student).where(Student.id.in_(sids))
            )).all()
        gname = g.name if g else "—"
        name_map = {s.id: f"{s.name} {s.last_name}" for s in students}

        notified = 0
        for sid, score in added_results:
            tg_ids = await get_student_tg_ids(sid)
            for tg in tg_ids:
                try:
                    if score >= 86:
                        emoji, note = "🚀", "Ajoyib natija!"
                    elif score >= 70:
                        emoji, note = "✅", "Yaxshi natija!"
                    elif score >= 60:
                        emoji, note = "📊", "Harakatda davom eting!"
                    else:
                        emoji, note = "⚠️", "Ko'proq mashq qilish kerak."
                    await message.bot.send_message(
                        tg,
                        f"📊 <b>Yangi test natijasi</b>\n"
                        f"━━━━━━━━━━━━━━\n"
                        f"👤 {name_map.get(sid, '—')}\n"
                        f"📁 Fan: {gname}\n"
                        f"{emoji} Natija: <b>{score:.0f}%</b>\n"
                        f"\n{note}"
                    )
                    notified += 1
                except Exception:
                    pass
                await asyncio.sleep(0.05)

        if notified:
            await message.answer(
                f"📤 Natijalar o'quvchi/ota-onalarga yuborildi: <b>{notified}</b> ta.")


@router.message(TestFSM.file)
async def test_invalid(message: Message):
    await message.answer("❌ Iltimos, .xlsx faylni yuboring.")
