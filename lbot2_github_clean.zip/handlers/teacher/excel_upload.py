from aiogram import Router, F
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from sqlalchemy import select
from config import ADMINS
from states.states import ExcelFSM
from database.engine import async_session
from database.models import Student, Group, Teacher, TeacherGroup, StudentGroup
from keyboards.reply import teacher_menu
from keyboards.buttons import BTN_T_EXCEL_UPLOAD
from utils.helpers import download_excel, safe_int

router = Router()


async def _get_teacher_group_ids(tg_id: int) -> set:
    async with async_session() as session:
        teacher = await session.scalar(
            select(Teacher).where(Teacher.tg_id == tg_id)
        )
        if not teacher:
            return set()
        links = (await session.scalars(
            select(TeacherGroup).where(TeacherGroup.teacher_id == teacher.id)
        )).all()
        return {link.group_id for link in links}


@router.message(F.text == BTN_T_EXCEL_UPLOAD)
async def ask_excel(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "📥 .xlsx faylni yuboring.\n"
        "Ustunlar: <code>name, last_name, tel, group_id</code>\n"
        "ℹ️ Faqat sizning guruhlaringizdagi group_id larni yozing."
    )
    await state.set_state(ExcelFSM.file)


@router.message(ExcelFSM.file, F.document)
async def load_excel(message: Message, state: FSMContext):
    df, err = await download_excel(message)
    if err:
        await message.answer(err)
        return
    df.columns = [str(c).strip().lower() for c in df.columns]
    required = {"name", "last_name", "tel", "group_id"}
    if not required.issubset(set(df.columns)):
        await message.answer(f"❌ Ustunlar yetishmaydi. Kerak: {', '.join(required)}")
        await state.clear()
        return
    valid_group_ids = await _get_teacher_group_ids(message.from_user.id)
    added, skipped = 0, 0
    bad_rows = []
    async with async_session() as session:
        for idx, row in enumerate(df.itertuples(index=False), start=2):
            row_dict = row._asdict() if hasattr(row, "_asdict") else dict(zip(df.columns, row))
            name = str(row_dict.get("name", "")).strip()
            last = str(row_dict.get("last_name", "")).strip()
            gid = safe_int(row_dict.get("group_id"))
            who = f"{name} {last}".strip() or f"{idx}-qator"
            if not name or not last:
                skipped += 1
                bad_rows.append(f"{idx}-qator: ism yoki familiya to'ldirilmagan")
                continue
            if gid is None or gid not in valid_group_ids:
                skipped += 1
                bad_rows.append(f"❌ {who}: guruh ID {gid} sizning guruhlaringizda yo'q")
                continue
            tel = str(row_dict.get("tel", "")).strip()
            student = Student(name=name, last_name=last, tel=tel)
            session.add(student)
            try:
                await session.flush()
                # Bog'lanish yaratish
                link = StudentGroup(student_id=student.id, group_id=gid, balance=0.0)
                session.add(link)
                await session.flush()
                added += 1
            except Exception:
                await session.rollback()
                skipped += 1
                bad_rows.append(f"❌ {who}: bazaga yozib bo'lmadi")
        await session.commit()
    text = f"✅ Qo'shildi: <b>{added}</b> ta o'quvchi\n⚠️ O'tkazib yuborildi: <b>{skipped}</b> ta"
    if bad_rows:
        shown = bad_rows[:20]
        text += "\n<b>⚠️ Xatolik bor o'quvchilar:</b>\n" + "\n".join(shown)
        if len(bad_rows) > 20:
            text += f"\n... va yana {len(bad_rows) - 20} ta"
    await message.answer(text, reply_markup=teacher_menu())
    await state.clear()


@router.message(ExcelFSM.file)
async def excel_invalid(message: Message):
    await message.answer("❌ Iltimos, .xlsx faylni yuboring.")