from aiogram import Router
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from aiogram.filters import StateFilter
from sqlalchemy import select

from config import ADMINS
from database.engine import async_session
from database.models import Teacher
from keyboards.reply import admin_menu, user_menu, teacher_menu

router = Router()


async def _get_role(tg_id: int) -> str:
    if tg_id in ADMINS:
        return "admin"
    async with async_session() as session:
        teacher = await session.scalar(
            select(Teacher).where(Teacher.tg_id == tg_id, Teacher.is_active == True)
        )
        if teacher:
            return "teacher"
    return "user"


@router.message(StateFilter(None))
async def fallback(message: Message, state: FSMContext):
    role = await _get_role(message.from_user.id)
    if role == "admin":
        menu = admin_menu()
    elif role == "teacher":
        menu = teacher_menu()
    else:
        menu = user_menu()

    text = (
        "🤖 <b>Tushunmadim 😊</b>\n"
        "━━━━━━━━━━━━━━\n"
        "Iltimos, matn yozish o'rniga quyidagi\n"
        "<b>menyu tugmalaridan</b> birini tanlang 👇"
    )
    await message.answer(text, reply_markup=menu)
