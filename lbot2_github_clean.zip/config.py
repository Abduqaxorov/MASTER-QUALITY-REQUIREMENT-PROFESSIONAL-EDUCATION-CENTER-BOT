import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
ADMINS = [int(x) for x in os.getenv("ADMINS", "").split(",") if x.strip()]
GROUP_IDS = [int(x) for x in os.getenv("GROUP_IDS", "").split(",") if x.strip()]

# ─────────── PostgreSQL (default) ───────────
# .env misoli:
# DATABASE_URL=postgresql://user:password@localhost:5432/crm_lms
_raw_db = os.getenv("DATABASE_URL", "postgresql+asyncpg://postgres:postgres@localhost:5432/crm_lms")

if _raw_db.startswith("postgres://"):
    _raw_db = _raw_db.replace("postgres://", "postgresql+asyncpg://", 1)
elif _raw_db.startswith("postgresql://"):
    _raw_db = _raw_db.replace("postgresql://", "postgresql+asyncpg://", 1)

DATABASE_URL = _raw_db
IS_SQLITE = DATABASE_URL.startswith("sqlite")

if not BOT_TOKEN:
    raise RuntimeError("❌ BOT_TOKEN topilmadi. .env faylni tekshiring.")


def cards_text() -> str:
    return "💳 <b>To'lov uchun karta ma'lumotlari hozircha kiritilmagan.</b>"
