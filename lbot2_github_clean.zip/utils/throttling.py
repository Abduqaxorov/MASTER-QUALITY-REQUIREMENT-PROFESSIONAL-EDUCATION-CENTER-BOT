from cachetools import TTLCache
from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery


class ThrottlingMiddleware(BaseMiddleware):
    """Bir user juda tez xabar yuborsa, ortiqchasini tashlab yuboradi.
    TTLCache ishlatadi: eski yozuvlar avtomatik o'chadi (memory leak yo'q)."""

    def __init__(self, rate: float = 0.5):
        self.rate = rate
        # 100000 usergacha saqlaydi, har yozuv 60s dan keyin o'chadi
        self._last = TTLCache(maxsize=100_000, ttl=60)
        super().__init__()

    async def __call__(self, handler, event, data):
        user = data.get("event_from_user")
        if user is None:
            return await handler(event, data)

        import time
        now = time.monotonic()
        last = self._last.get(user.id, 0.0)
        if now - last < self.rate:
            if isinstance(event, CallbackQuery):
                try:
                    await event.answer()
                except Exception:
                    pass
            return  # handler chaqirilmaydi

        self._last[user.id] = now
        return await handler(event, data)
