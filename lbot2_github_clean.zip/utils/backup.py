"""Ma'lumotlar bazasini SQL fayl ko'rinishida backup qilish (to'liq async)."""
import io
import logging
from datetime import datetime, date

from sqlalchemy import MetaData, select

from database.engine import engine

logger = logging.getLogger(__name__)


def _esc(value) -> str:
    """SQL qiymatini xavfsiz matnga aylantiradi."""
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, (datetime, date)):
        return f"'{value.isoformat()}'"
    s = str(value).replace("'", "''")
    return f"'{s}'"


async def make_backup() -> io.BytesIO | None:
    """Barcha jadvallarni o'qib, SQL INSERT lar ko'rinishidagi .sql fayl yasaydi.
    BytesIO qaytaradi (Telegram'ga yuborish uchun). Xato bo'lsa None.
    To'liq async — asyncpg bilan ishlaydi, psycopg2 kerak emas."""
    try:
        meta = MetaData()
        buffer = io.StringIO()
        buffer.write(f"-- CRM Bot backup\n-- {datetime.now().isoformat()}\n\n")

        async with engine.connect() as conn:
            # Jadval strukturasini o'qish (sync API'ni async ichida ishlatamiz)
            await conn.run_sync(meta.reflect)

            for table in meta.sorted_tables:
                result = await conn.execute(select(table))
                rows = result.fetchall()
                if not rows:
                    continue
                cols = [c.name for c in table.columns]
                buffer.write(f"-- {table.name} ({len(rows)} qator)\n")
                for row in rows:
                    values = ", ".join(_esc(v) for v in row)
                    buffer.write(
                        f"INSERT INTO {table.name} "
                        f"({', '.join(cols)}) VALUES ({values});\n"
                    )
                buffer.write("\n")

        data = buffer.getvalue().encode("utf-8")
        out = io.BytesIO(data)
        out.seek(0)
        logger.info("✅ Backup tayyor (%d bayt).", len(data))
        return out
    except Exception as e:
        logger.error("❌ Backup xatosi: %s", e)
        return None
