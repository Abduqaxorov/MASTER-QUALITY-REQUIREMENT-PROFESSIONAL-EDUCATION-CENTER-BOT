from typing import Any, Dict, Optional
from aiogram.fsm.storage.base import BaseStorage, StorageKey, StateType
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker
from database.models import Base
from sqlalchemy import Column, BigInteger, String, JSON


# FSM uchun model (faqat shu fayl ichida ishlatiladi)
class FSMData(Base):
    __tablename__ = "aiogram_fsm_data"
    user_id = Column(BigInteger, primary_key=True)
    chat_id = Column(BigInteger, primary_key=True)
    state = Column(String(255), nullable=True)
    data = Column(JSON, default=dict)  # MUHIM: mutable default emas


class CustomPostgresStorage(BaseStorage):
    def __init__(self, session_pool: async_sessionmaker[AsyncSession]):
        self.session_pool = session_pool

    async def set_state(self, key: StorageKey, state: StateType = None) -> None:
        async with self.session_pool() as session:
            stmt = select(FSMData).where(
                FSMData.user_id == key.user_id, FSMData.chat_id == key.chat_id)
            result = await session.execute(stmt)
            obj = result.scalar_one_or_none()

            if state is None:
                state_str = None
            elif hasattr(state, "state"):
                state_str = state.state
            else:
                state_str = str(state)

            if obj:
                obj.state = state_str
            else:
                session.add(FSMData(user_id=key.user_id, chat_id=key.chat_id,
                                    state=state_str, data={}))
            await session.commit()

    async def get_state(self, key: StorageKey) -> Optional[str]:
        async with self.session_pool() as session:
            stmt = select(FSMData.state).where(
                FSMData.user_id == key.user_id, FSMData.chat_id == key.chat_id)
            result = await session.execute(stmt)
            return result.scalar_one_or_none()

    async def set_data(self, key: StorageKey, data: Dict[str, Any]) -> None:
        async with self.session_pool() as session:
            stmt = select(FSMData).where(
                FSMData.user_id == key.user_id, FSMData.chat_id == key.chat_id)
            result = await session.execute(stmt)
            obj = result.scalar_one_or_none()
            if obj:
                obj.data = data
            else:
                session.add(FSMData(user_id=key.user_id, chat_id=key.chat_id, data=data))
            await session.commit()

    async def get_data(self, key: StorageKey) -> Dict[str, Any]:
        async with self.session_pool() as session:
            stmt = select(FSMData.data).where(
                FSMData.user_id == key.user_id, FSMData.chat_id == key.chat_id)
            result = await session.execute(stmt)
            return result.scalar_one_or_none() or {}

    async def close(self) -> None:
        pass
