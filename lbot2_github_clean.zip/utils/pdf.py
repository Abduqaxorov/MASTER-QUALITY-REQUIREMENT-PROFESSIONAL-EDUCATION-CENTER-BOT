"""Feedbacklarni PDF ga aylantirish (o'zbek matnini qo'llab-quvvatlaydi)."""
import io
import os
import logging
import urllib.request

from fpdf import FPDF

logger = logging.getLogger(__name__)

ASSETS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets")
FONT_PATH = os.path.join(ASSETS_DIR, "DejaVuSans.ttf")

FONT_URLS = [
    "https://raw.githubusercontent.com/dejavu-fonts/dejavu-fonts/version_2_37/ttf/DejaVuSans.ttf",
    "https://cdn.jsdelivr.net/gh/dejavu-fonts/dejavu-fonts@version_2_37/ttf/DejaVuSans.ttf",
    "https://github.com/dejavu-fonts/dejavu-fonts/raw/version_2_37/ttf/DejaVuSans.ttf",
]

# Bir qatorga sig'maydigan uzun so'zlarni majburan bo'lish chegarasi.
# 30 — eng xavfsiz qiymat: 11pt shriftda kenglikka bemalol sig'adi.
MAX_WORD_LEN = 30


def _ensure_font() -> str | None:
    if os.path.exists(FONT_PATH) and os.path.getsize(FONT_PATH) > 10000:
        return FONT_PATH
    os.makedirs(ASSETS_DIR, exist_ok=True)
    for url in FONT_URLS:
        try:
            logger.info("⬇️ Shrift yuklanmoqda: %s", url)
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = resp.read()
            if len(data) > 10000:
                with open(FONT_PATH, "wb") as f:
                    f.write(data)
                logger.info("✅ Shrift yuklandi (%d bayt).", len(data))
                return FONT_PATH
        except Exception as e:
            logger.warning("Shrift yuklab bo'lmadi (%s): %s", url, e)
    logger.error("❌ Shrift yuklanmadi. Helvetica ishlatiladi.")
    return None


def _sanitize(text: str) -> str:
    """\r, tab va boshqa muammoli belgilarni tozalaydi."""
    if not text:
        return ""
    return (text.replace("\r\n", "\n").replace("\r", "\n")
                .replace("\t", "    ").replace("\u00a0", " "))


def _break_long_words(text: str, limit: int = MAX_WORD_LEN) -> str:
    """Uzun (bo'shliqsiz) so'zlarni bo'laklarga bo'ladi —
    aks holda fpdf ularni sig'dira olmay qirqib qo'yadi."""
    out_lines = []
    for line in text.split("\n"):
        words = []
        for word in line.split(" "):
            while len(word) > limit:
                words.append(word[:limit])
                word = word[limit:]
            words.append(word)
        out_lines.append(" ".join(words))
    return "\n".join(out_lines)


def _clean_unicode(text: str) -> str:
    """Emoji va BMP tashqarisidagi belgilarni olib tashlaydi."""
    return "".join(ch for ch in text if ord(ch) <= 0xFFFF)


def _clean_latin(text: str) -> str:
    """Shrift yo'q bo'lsa: faqat latin-1 belgilar."""
    out = []
    for ch in text:
        try:
            ch.encode("latin-1")
            out.append(ch)
        except UnicodeEncodeError:
            repl = {"‘": "'", "’": "'", "“": '"', "”": '"', "–": "-", "—": "-"}
            out.append(repl.get(ch, "?"))
    return "".join(out)


def make_feedback_pdf(teacher_name: str, feedbacks: list) -> io.BytesIO | None:
    """Bitta ustozning barcha feedbacklaridan PDF yasaydi."""
    font_path = _ensure_font()
    use_unicode = font_path is not None
    base_clean = _clean_unicode if use_unicode else _clean_latin

    def prep(text: str) -> str:
        return base_clean(_break_long_words(_sanitize(text or "")))

    try:
        pdf = FPDF(format="A4")
        pdf.set_auto_page_break(auto=True, margin=15)
        pdf.set_margins(15, 15, 15)
        pdf.add_page()

        if use_unicode:
            pdf.add_font("DejaVu", "", font_path)
            pdf.add_font("DejaVu", "B", font_path)
            base = "DejaVu"
        else:
            base = "Helvetica"

        # width=0 — chap chetdan o'ng chetgacha to'liq kenglik
        pdf.set_font(base, "B", 16)
        pdf.multi_cell(0, 10, prep("Anonim feedbacklar"), align="C")
        pdf.ln(2)

        pdf.set_font(base, "", 12)
        pdf.multi_cell(0, 8, prep(f"Ustoz: {teacher_name}"))
        pdf.multi_cell(0, 8, prep(f"Jami: {len(feedbacks)} ta"))
        pdf.ln(3)

        pdf.set_draw_color(150, 150, 150)
        pdf.line(pdf.l_margin, pdf.get_y(), pdf.w - pdf.r_margin, pdf.get_y())
        pdf.ln(4)

        for i, fb in enumerate(feedbacks, 1):
            # Har bir feedback alohida himoyalangan —
            # bittasi xato bersa, qolganlari baribir chiqadi
            try:
                created = ""
                if getattr(fb, "created_at", None):
                    created = fb.created_at.strftime("%Y-%m-%d %H:%M")

                pdf.set_font(base, "B", 11)
                pdf.multi_cell(0, 7, prep(f"#{i}  |  {created}"))

                pdf.set_font(base, "", 11)
                body = prep(fb.text) or "(matn yo'q)"
                pdf.multi_cell(0, 7, body)
                pdf.ln(2)

                pdf.set_draw_color(210, 210, 210)
                pdf.line(pdf.l_margin, pdf.get_y(), pdf.w - pdf.r_margin, pdf.get_y())
                pdf.ln(3)
            except Exception as fe:
                logger.warning("Feedback #%d PDFga sig'madi: %s", i, fe)
                try:
                    pdf.set_font(base, "", 11)
                    pdf.multi_cell(0, 7, f"#{i} (bu feedbackni chiqarib bo'lmadi)")
                    pdf.ln(2)
                except Exception:
                    pass

        raw = pdf.output()
        out = io.BytesIO(bytes(raw))
        out.seek(0)
        return out
    except Exception as e:
        logger.error("❌ PDF yasashda xato: %s", e)
        return None
