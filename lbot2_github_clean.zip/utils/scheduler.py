import asyncio
from datetime import datetime
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from aiogram.types import BufferedInputFile
from config import ADMINS
from database.engine import async_session
from database.models import (
    StudentGroup, MonthlyBilling, Student, Group, StudentLink,
)
from keyboards.inline import monthly_confirm_kb
from utils.backup import make_backup


async def _ask_monthly_confirmation(bot):
    period = datetime.now().strftime("%Y-%m")
    async with async_session() as session:
        links = (await session.scalars(
            select(StudentGroup).options(selectinload(StudentGroup.group))
        )).all()
        rows = (await session.scalars(
            select(MonthlyBilling).where(MonthlyBilling.period == period)
        )).all()
    count = len(links)
    total = sum(l.group.monthly_price for l in links if l.group)
    times = len(rows)
    warn = f"\n⚠️ Bu oy allaqachon {times} marta qilingan!\n" if times > 0 else ""
    text = (
        "🗓 <b>Oylik hisob-kitob vaqti keldi!</b>\n"
        "━━━━━━━━━━━━━━\n"
        f"📅 Oy: <b>{period}</b>\n"
        f"👥 O'quvchi-guruh bog'liqliklari: <b>{count}</b>\n"
        f"💸 Yoziladigan: <b>{total:,.0f}</b> so'm\n"
        f"{warn}\n"
        "Hammaga oylik to'lov yozilsinmi?"
    )
    for admin_id in ADMINS:
        try:
            await bot.send_message(admin_id, text, reply_markup=monthly_confirm_kb())
        except Exception:
            pass


async def _daily_backup(bot):
    """Backup oladi va adminlarga Telegram orqali .sql fayl yuboradi."""
    buffer = await make_backup()
    if not buffer:
        for admin_id in ADMINS:
            try:
                await bot.send_message(admin_id, "❌ Kunlik backup olishda xato bo'ldi!")
            except Exception:
                pass
        return
    stamp = datetime.now().strftime("%Y-%m-%d_%H-%M")
    for admin_id in ADMINS:
        try:
            buffer.seek(0)
            file = BufferedInputFile(buffer.read(), filename=f"backup_{stamp}.sql")
            await bot.send_document(
                admin_id, file,
                caption=f"💾 <b>Kunlik backup</b>\n🗓 {stamp}",
            )
        except Exception:
            pass


async def _debt_reminders(bot):
    """Qarzi bor o'quvchilarning ota-onalariga avtomatik eslatma yuboradi."""
    async with async_session() as session:
        rows = (await session.execute(
            select(StudentLink.tg_id, Student.name, Student.last_name,
                   Group.name, StudentGroup.balance)
            .join(Student, Student.id == StudentLink.student_id)
            .join(StudentGroup, StudentGroup.student_id == Student.id)
            .join(Group, Group.id == StudentGroup.group_id)
            .where(StudentGroup.balance < 0)
        )).all()

    if not rows:
        return

    # Bitta userga bitta jamlangan xabar (bir nechta farzand/fan bo'lsa ham)
    by_user: dict[int, list] = {}
    for tg_id, name, last, gname, bal in rows:
        by_user.setdefault(tg_id, []).append((name, last, gname, bal))

    sent = 0
    for tg_id, debts in by_user.items():
        lines = ["🔔 <b>To'lov eslatmasi</b>\n━━━━━━━━━━━━━━"]
        total = 0.0
        for name, last, gname, bal in debts:
            lines.append(f"👤 {name} {last}\n📁 {gname}: <b>{abs(bal):,.0f} so'm</b> qarz")
            total += abs(bal)
        lines.append("━━━━━━━━━━━━━━")
        lines.append(f"💸 Jami: <b>{total:,.0f} so'm</b>")
        lines.append("\nIltimos, to'lovni o'z vaqtida amalga oshiring. 💳\n"
                     "«💳 To'lov qilish» tugmasi orqali chek yuborishingiz mumkin.")
        try:
            await bot.send_message(tg_id, "\n".join(lines))
            sent += 1
        except Exception:
            pass
        await asyncio.sleep(0.05)

    # Adminlarga hisobot
    for admin_id in ADMINS:
        try:
            await bot.send_message(
                admin_id,
                f"🔔 Qarz eslatmalari yuborildi: <b>{sent}</b> ta userga.")
        except Exception:
            pass


def setup_scheduler(bot) -> AsyncIOScheduler:
    scheduler = AsyncIOScheduler(timezone="Asia/Tashkent")
    scheduler.add_job(
        _ask_monthly_confirmation,
        trigger=CronTrigger(day=1, hour=9, minute=0),
        id="monthly_ask",
        replace_existing=True,
        kwargs={"bot": bot},
    )
    scheduler.add_job(
        _daily_backup,
        trigger=CronTrigger(hour=22, minute=0),
        id="daily_backup",
        replace_existing=True,
        kwargs={"bot": bot},
    )
    # Har oyning 5-sanasi, soat 10:00 da qarz eslatmasi
    scheduler.add_job(
        _debt_reminders,
        trigger=CronTrigger(day=5, hour=10, minute=0),
        id="debt_reminders",
        replace_existing=True,
        kwargs={"bot": bot},
    )
    return scheduler
