"""Ticket (murojaat) tartib raqamlari uchun yordamchi funksiyalar."""
from sqlalchemy import select, func, text
from database.engine import async_session
from database.models import ContactTicket


async def get_next_ticket_number() -> int:
    """Keyingi ticket raqamini qaytaradi.
    PostgreSQL sequence orqali — ATOMAR: bir vaqtda nechta so'rov
    kelsa ham har biriga takrorlanmas raqam beriladi."""
    async with async_session() as session:
        n = await session.scalar(text("SELECT nextval('ticket_number_seq')"))
        return int(n)


async def get_user_queue_position(from_user_id: int, from_role: str) -> int | None:
    """Userning navbatdagi o'rnini qaytaradi."""
    async with async_session() as session:
        own = await session.scalar(
            select(ContactTicket.ticket_number).where(
                ContactTicket.from_user_id == from_user_id,
                ContactTicket.from_role == from_role,
                ContactTicket.status.in_(["pending", "active"]),
            )
        )
        if own:
            before = await session.scalar(
                select(func.count(ContactTicket.id)).where(
                    ContactTicket.status == "pending",
                    ContactTicket.ticket_number < own,
                )
            ) or 0
            return before + 1
        return None
