from sqlalchemy import select, delete
from sqlalchemy.orm import selectinload

from database.engine import async_session
from database.models import Student, StudentLink, StudentGroup


async def get_linked_students(tg_id: int) -> list[Student]:
    async with async_session() as session:
        sids = (await session.scalars(
            select(StudentLink.student_id).where(StudentLink.tg_id == tg_id)
        )).all()
        if not sids:
            return []
        students = (await session.scalars(
            select(Student).options(
                selectinload(Student.group_links).selectinload(StudentGroup.group))
            .where(Student.id.in_(sids)).order_by(Student.name)
        )).all()
        return list(students)


async def get_student_tg_ids(student_id: int) -> list[int]:
    """O'quvchiga bog'langan barcha Telegram userlarni (ota-ona/o'zi) qaytaradi."""
    async with async_session() as session:
        return list((await session.scalars(
            select(StudentLink.tg_id).where(StudentLink.student_id == student_id)
        )).all())


async def link_student(tg_id: int, student_id: int) -> None:
    async with async_session() as session:
        exists = await session.scalar(
            select(StudentLink).where(
                StudentLink.tg_id == tg_id,
                StudentLink.student_id == student_id,
            )
        )
        if not exists:
            session.add(StudentLink(tg_id=tg_id, student_id=student_id))
            await session.commit()


async def unlink_all(tg_id: int) -> None:
    async with async_session() as session:
        await session.execute(delete(StudentLink).where(StudentLink.tg_id == tg_id))
        await session.commit()
